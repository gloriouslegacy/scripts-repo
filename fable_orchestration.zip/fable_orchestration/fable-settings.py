#!/usr/bin/env python3
"""
fable-settings.py — settings.json 스위치 (전체 적용 / 프로젝트별 끄기)

env.sh / env.ps1 의 `fable global …`, `fable project …` 가 호출한다.
JSON 편집을 한 곳에 모아 macOS·Linux·Windows 에서 같은 동작을 보장한다.

  global on      ~/.claude/settings.json 의 env 에 서브에이전트 모델 변수 2개 기록
                 → 터미널·IDE 확장·데스크톱 앱 어디서 실행해도 Opus 5.5 전환 적용
  global off     위 변수 2개 제거 (셸 래퍼만 남음)
  project off    <현재 폴더>/.claude/settings.json 의 env 에 FABLE_GATE_OFF=1 기록
                 → 이 프로젝트에서는 게이트가 전부 허용
  project on     FABLE_GATE_OFF 제거
  status         전체/프로젝트 상태 출력

옵션
  --local        project 명령을 settings.local.json 에 적용 (git 에 커밋되지 않음)
  --model ID     global on 에 쓸 모델 (기본 claude-opus-5-5)
  --dir PATH     project 명령의 대상 폴더 (기본 현재 폴더)
"""
import argparse
import json
import os
import sys

DEFAULT_MODEL = "claude-opus-5-5"
GLOBAL_KEYS = ("CLAUDE_CODE_SUBAGENT_MODEL", "ANTHROPIC_DEFAULT_SONNET_MODEL")
PROJECT_KEY = "FABLE_GATE_OFF"


def load(path):
    if not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8-sig") as f:
        text = f.read().strip()
    data = json.loads(text) if text else {}
    if not isinstance(data, dict):
        print(f"경고: {path} 최상위가 JSON 객체가 아니라 빈 설정으로 취급합니다", file=sys.stderr)
        return {}
    return data


def save(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        bak = path + ".bak"
        with open(path, "rb") as src, open(bak, "wb") as dst:
            dst.write(src.read())
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def set_env(path, updates, remove=()):
    data = load(path)
    env = data.get("env")
    if not isinstance(env, dict):
        env = {}
    env.update(updates)
    for k in remove:
        env.pop(k, None)
    if env:
        data["env"] = env
    else:
        data.pop("env", None)
    save(path, data)


def global_path():
    return os.path.join(os.path.expanduser("~"), ".claude", "settings.json")


def project_path(d, local):
    name = "settings.local.json" if local else "settings.json"
    return os.path.join(os.path.abspath(d), ".claude", name)


def status(d):
    g = load(global_path()).get("env", {}) or {}
    gm = g.get("CLAUDE_CODE_SUBAGENT_MODEL")
    print(f"global     : {'ON  (' + gm + ')' if gm else 'off (셸 래퍼만 적용)'}")
    for local in (False, True):
        p = project_path(d, local)
        e = load(p).get("env", {}) or {}
        if PROJECT_KEY in e:
            print(f"project    : 게이트 OFF ({os.path.relpath(p, d)})")
            break
    else:
        print("project    : 게이트 on")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scope", choices=["global", "project", "status"])
    ap.add_argument("action", nargs="?", choices=["on", "off"])
    ap.add_argument("--local", action="store_true")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--dir", default=os.getcwd())
    a = ap.parse_args()

    if a.scope == "status":
        status(a.dir)
        return
    if not a.action:
        ap.error(f"{a.scope} 에는 on|off 가 필요합니다")

    if a.scope == "global":
        p = global_path()
        if a.action == "on":
            set_env(p, {k: a.model for k in GLOBAL_KEYS})
            print(f"global ON : {p} 에 서브에이전트 모델={a.model} 기록 (새 세션부터, IDE·앱 포함)")
        else:
            set_env(p, {}, remove=GLOBAL_KEYS)
            print(f"global off: {p} 에서 모델 변수 제거 (셸 래퍼만 적용)")
    else:
        p = project_path(a.dir, a.local)
        if a.action == "off":
            set_env(p, {PROJECT_KEY: "1"})
            print(f"project OFF: {p} 에 {PROJECT_KEY}=1 기록 — 이 프로젝트에서 게이트 비활성 (새 세션부터)")
        else:
            for lp in (project_path(a.dir, False), project_path(a.dir, True)):
                if os.path.exists(lp) and PROJECT_KEY in (load(lp).get("env") or {}):
                    set_env(lp, {}, remove=(PROJECT_KEY,))
                    print(f"project on : {lp} 에서 {PROJECT_KEY} 제거")
            print("project on : 게이트 활성 (새 세션부터)")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"오류: {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)

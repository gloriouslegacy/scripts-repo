# Fable 5.1 오케스트레이션 적용 가이드 (Max 요금제용)

> 기준일 2026-10-04 · 메인 Fable 5.1 / 구현 Opus 5.5 / 유틸 Haiku 4.5
> 원본: successwiki.io "Fable 5 오케스트레이션 가이드"를 검토해 보완한 버전
>
> **플랫폼별 설치 문서**: 이 문서의 3·6·8절은 Linux(및 WSL) 기준입니다.
> macOS는 `macos/APPLY-GUIDE-macOS.md`, Windows PowerShell은 `windows/APPLY-GUIDE-Windows.md`를 따르세요.
> 0·4·5·7·9절(변경점, effort, 운영 모드, 효과 측정, 한계)은 모든 플랫폼 공통입니다.

---

## 0. 원본 대비 바뀐 점

| 항목 | 원본 | 이 버전 | 이유 |
|---|---|---|---|
| 서브에이전트 판별 | `agent_id or agent_type` | `agent_id`만 사용 | `agent_type`은 `claude --agent X` 메인 세션에도 들어와 게이트가 뚫림 |
| Sonnet 재매핑 | `claude-opus-4-8` | `claude-opus-5-5` | Opus 5.5(9/22 출시)가 더 빠르고 저렴 |
| 서브에이전트 기본 모델 | 없음 (Sonnet 재매핑에만 의존) | `CLAUDE_CODE_SUBAGENT_MODEL=claude-opus-5-5` 추가 | `general-purpose` 등 model 미지정 서브에이전트는 **메인 모델(Fable 5.1)을 물려받음**. 이 변수가 없으면 위임해도 Fable이 실행해 절감 효과가 사라짐 |
| deep-reasoner | Opus 5, effort max | Opus 5.5, effort high | Opus 5.5 medium이 Opus 5 high 수준, max는 한도 소모가 큼 |
| 파일 전체 재작성 | 제한 없음 | 기존 코드 파일(50줄 초과) `Write` 차단, **모든 에이전트** | Fable 5.1의 파일 전체 재작성 경향 대응 |
| Bash 차단 | 리다이렉트 일괄 차단 | 코드 파일 대상일 때만 차단 + `tee`/`python -c`/`node -e`/`git apply`/`patch`/`cp`/`mv` 추가 | `2>&1`, `>/dev/null`, 로그 저장 허용 / 우회 경로 보강 |
| 오류 처리 | 조용한 fail-open | fail-open + `gate.log` 기록 | 게이트가 꺼진 걸 알 수 있게 |
| 지시문 | 역할 분담만 | Fable 5.1 공식 문구 3종(초안 이중 작성 금지, 부분 수정, 범위 확장 금지) 추가 | 출력 토큰 절감 |

---

## 1. 최종 구조

```
~/.claude/
├── .fable-state                  # "on" / "off"
├── CLAUDE.md                     # @import 한 줄 추가
├── settings.json                 # PreToolUse 훅 등록
├── agents/
│   ├── deep-reasoner.md -> ../fable/agents/deep-reasoner.md
│   └── runner.md        -> ../fable/agents/runner.md
└── fable/
    ├── fable.md                  # 오케스트레이션 지시문 (제공 파일)
    ├── empty.md                  # off 상태용 빈 파일
    ├── active.md -> fable.md | empty.md
    ├── env.sh                    # claude 래퍼 + fable 명령
    ├── agents/
    │   ├── deep-reasoner.md
    │   └── runner.md
    ├── hooks/
    │   ├── orchestration-gate.py # 게이트 (제공 파일)
    │   └── fable-settings.py     # global/project 스위치 (제공 파일)
    ├── state/                    # 턴별 카운터 (자동 생성)
    └── gate.log                  # 차단·경고·오류 로그 (자동 생성)
```

연결 지점은 **4곳**뿐입니다: `CLAUDE.md` 1줄, `settings.json` 훅 1개, `agents/` 심볼릭 링크 2개, 셸 rc 1줄.

---

## 2. 사전 확인

```bash
claude --version        # 2.1.196 이상이어야 prompt_id 기반 턴 한도가 동작
python3 --version       # 3.8 이상
```

Claude Code 안에서 `/model`을 열어 **Fable 5.1과 Opus 5.5의 정확한 모델 ID**를 확인하세요. 아래 예시는 `claude-opus-5-5` 기준이며, 다르면 해당 값으로 바꿉니다.

---

## 3. 설치

### 3-1. 디렉터리와 제공 파일 배치

```bash
mkdir -p ~/.claude/fable/{agents,hooks,state} ~/.claude/agents
cp fable.md               ~/.claude/fable/fable.md
cp orchestration-gate.py  ~/.claude/fable/hooks/orchestration-gate.py
cp fable-settings.py      ~/.claude/fable/hooks/fable-settings.py
chmod +x ~/.claude/fable/hooks/orchestration-gate.py
: > ~/.claude/fable/empty.md
echo off > ~/.claude/.fable-state
ln -sfn ~/.claude/fable/empty.md ~/.claude/fable/active.md
```

### 3-2. 서브에이전트 정의

`~/.claude/fable/agents/deep-reasoner.md`

```markdown
---
name: deep-reasoner
description: 어려운 설계 판단, 원인 불명 버그 분석, 트레이드오프 검토가 필요할 때 사용. 구현은 하지 않고 결론과 근거만 반환.
model: claude-opus-5-5
effort: high
tools: Read, Grep, Glob, Bash
---
너는 분석 전담이다. 코드를 수정하지 말고 다음 형식으로만 답한다:
1) 결론 2) 근거 3~5줄 3) 대안과 각각의 리스크 4) 다음 행동 제안.
```

`~/.claude/fable/agents/runner.md`

```markdown
---
name: runner
description: 명령 실행, 테스트 실행, 빌드, 로그·출력 확인, 파일 탐색 같은 단순 작업에 사용.
model: claude-haiku-4-5-20251001
effort: low
tools: Bash, Read, Grep, Glob
---
요청받은 명령만 실행하고, 결과를 요약해서 돌려준다.
성공/실패, 핵심 에러 메시지(최대 20줄), 관련 파일 경로만 포함한다. 파일을 수정하지 않는다.
```

> Haiku 4.5가 `effort`를 지원하지 않으면 이 값은 무시됩니다. 넣어 둬도 문제는 없습니다.

링크로 연결합니다.

```bash
ln -sfn ~/.claude/fable/agents/deep-reasoner.md ~/.claude/agents/deep-reasoner.md
ln -sfn ~/.claude/fable/agents/runner.md        ~/.claude/agents/runner.md
```

### 3-3. `env.sh` (래퍼 + `fable` 명령)

`~/.claude/fable/env.sh` (`macos/env.sh`와 같은 파일입니다. Linux/WSL에서도 그대로 쓰면 됩니다.)

```bash

FABLE_HOME="$HOME/.claude/fable"
FABLE_STATE="$HOME/.claude/.fable-state"
FABLE_EXEC_MODEL="claude-opus-5-5"   # 구현 서브에이전트(general-purpose 등)가 쓸 모델
FABLE_MIN_CC="2.1.196"               # prompt_id 지원 최소 버전

_fable_run() {
  if [ "$(cat "$FABLE_STATE" 2>/dev/null)" = "on" ]; then
    # CLAUDE_CODE_SUBAGENT_MODEL: model 을 지정하지 않은 서브에이전트(general-purpose 포함)의 모델.
    #   없으면 메인(Fable 5.1)을 그대로 물려받아 위임 효과가 사라짐. deep-reasoner/runner 처럼
    #   frontmatter 에 model 이 있는 에이전트는 영향 없음.
    CLAUDE_CODE_SUBAGENT_MODEL="$FABLE_EXEC_MODEL" \
    ANTHROPIC_DEFAULT_SONNET_MODEL="$FABLE_EXEC_MODEL" "$@"
  else
    "$@"
  fi
}
claude() { _fable_run command claude "$@"; }

_fable_ok() { if [ "$1" = 0 ]; then echo "[ok] $2"; else echo "[!!] $2"; fi; }

fable() {
  case "$1" in
    on)
      echo on > "$FABLE_STATE"
      ln -sfn "$FABLE_HOME/fable.md" "$FABLE_HOME/active.md"
      echo "fable: ON (다음 세션부터 적용)";;
    off)
      echo off > "$FABLE_STATE"
      ln -sfn "$FABLE_HOME/empty.md" "$FABLE_HOME/active.md"
      echo "fable: OFF (다음 세션부터 적용)";;
    status)
      echo "state      : $(cat "$FABLE_STATE" 2>/dev/null || echo missing)"
      echo "active.md  : $(readlink "$FABLE_HOME/active.md")"
      grep -q 'fable/active.md' "$HOME/.claude/CLAUDE.md" 2>/dev/null;       _fable_ok $? "CLAUDE.md import"
      grep -q 'orchestration-gate.py' "$HOME/.claude/settings.json" 2>/dev/null; _fable_ok $? "settings.json hook"
      [ -e "$HOME/.claude/agents/deep-reasoner.md" ] && [ -e "$HOME/.claude/agents/runner.md" ]; _fable_ok $? "agents 링크"
      python3 -c 'import sys; sys.exit(sys.version_info < (3, 8))' 2>/dev/null; _fable_ok $? "python3 3.8+"
      v=$(command claude --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)
      # macOS 기본 sort 는 버전마다 -V 지원이 달라 python 으로 비교
      python3 -c 'import sys; a=[int(x) for x in sys.argv[1].split(".")]; b=[int(x) for x in sys.argv[2].split(".")]; sys.exit(a < b)' "${v:-0.0.0}" "$FABLE_MIN_CC" 2>/dev/null
      _fable_ok $? "claude ${v:-?} (${FABLE_MIN_CC} 이상 필요)"
      python3 "$FABLE_HOME/hooks/fable-settings.py" status 2>/dev/null
      if [ -f "$FABLE_HOME/gate.log" ]; then
        echo "gate.log   : DENY $(grep -c '"DENY"' "$FABLE_HOME/gate.log") / WARN $(grep -c '"WARN"' "$FABLE_HOME/gate.log") / ERROR $(grep -c '"ERROR"' "$FABLE_HOME/gate.log")"
      fi;;
    log)  tail -n "${2:-20}" "$FABLE_HOME/gate.log";;
    global)   # 전체 적용 스위치: ~/.claude/settings.json env 에 모델 변수 기록/제거 (IDE·앱 포함)
      python3 "$FABLE_HOME/hooks/fable-settings.py" global "${2:-}" --model "$FABLE_EXEC_MODEL";;
    project)  # 프로젝트별 게이트 스위치: ./.claude/settings.json (--local 이면 settings.local.json)
      python3 "$FABLE_HOME/hooks/fable-settings.py" project "${2:-}" "${@:3}";;
    *)    echo "usage: fable on|off|status|log [n] | global on|off | project on|off [--local]";;
  esac
}
```

셸 rc(`~/.zshrc` 또는 `~/.bashrc`)에 한 줄 추가합니다.

```bash
[ -f "$HOME/.claude/fable/env.sh" ] && source "$HOME/.claude/fable/env.sh"
```

### 3-4. `CLAUDE.md` import

`~/.claude/CLAUDE.md` 맨 아래에 추가합니다(경로는 본인 홈으로).

```
@/Users/<you>/.claude/fable/active.md
```

### 3-5. `settings.json` 훅 등록

`~/.claude/settings.json`의 `hooks`에 병합합니다. 기존 PreToolUse 훅이 있으면 배열에 항목만 추가하세요.

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit|NotebookEdit|Bash",
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.claude/fable/hooks/orchestration-gate.py\"",
            "timeout": 10
          }
        ]
      }
    ]
  }
}
```

### 3-6. IDE 확장·데스크톱 앱에도 모델 전환 적용 (`fable global on`)

셸 래퍼는 터미널에서 띄운 `claude`에만 적용됩니다. VS Code·JetBrains 확장, Claude 데스크톱 앱 Code 탭에서도 서브에이전트를 Opus 5.5로 돌리려면 다음을 실행합니다.

```bash
fable global on     # ~/.claude/settings.json 의 env 에 기록 (새 세션부터)
fable global off    # 제거
```

결과적으로 `settings.json`에 아래가 들어갑니다. 단, 이 경우 `fable off`여도 서브에이전트 모델은 유지됩니다(기본 모드에서는 메인도 Opus 5.5라 손해는 없음).

```json
{
  "env": {
    "CLAUDE_CODE_SUBAGENT_MODEL": "claude-opus-5-5",
    "ANTHROPIC_DEFAULT_SONNET_MODEL": "claude-opus-5-5"
  }
}
```

---

## 스위치 세 가지 (적용 범위)

| 명령 | 바꾸는 것 | 적용 범위 | 효과 |
|---|---|---|---|
| `fable on` / `off` | `.fable-state`, `active.md` | 모든 프로젝트, 모든 실행 경로 | 지시문 + 게이트 + 서브에이전트 켜고 끔. 모델 전환은 **터미널에서 띄운 `claude`에만** |
| `fable global on` / `off` | `~/.claude/settings.json`의 `env` | 모든 프로젝트, **IDE 확장·데스크톱 앱 포함** | 서브에이전트 모델을 Opus 5.5로 고정. `fable off`여도 유지됨 |
| `fable project off` / `on` | `<프로젝트>/.claude/settings.json`의 `env` (`--local`이면 `settings.local.json`) | **그 프로젝트만** | 게이트만 비활성. 지시문과 서브에이전트는 그대로 |

- IDE나 데스크톱 앱을 주로 쓰면 `fable on` 뒤에 `fable global on`을 한 번 더 실행하세요. 둘 다 새 세션부터 적용됩니다.
- `fable project off --local`은 git에 커밋되지 않는 `settings.local.json`에 기록하므로 공용 저장소에서 쓰기 좋습니다.
- `fable status`에 `global`과 `project` 상태가 함께 표시됩니다.
- 게이트는 `FABLE_GATE_OFF`를 환경변수로 받지 못해도 현재 폴더에서 위로 올라가며 `.claude/settings.local.json`, `.claude/settings.json`을 직접 읽으므로, 하위 폴더에서 세션을 열어도 적용됩니다.

---

## 4. 메인 모델과 effort 설정

1. `fable on` 실행 후 **새 세션**을 엽니다.
2. `/model`에서 **Fable 5.1**을 선택하고 effort를 **medium**으로 둡니다.
3. 운영 원칙
   - 평소: **medium** (공식 가이드: Fable 5 수준 품질, 더 적은 비용)
   - 설계 판단이 무거운 턴: 일시적으로 **high**
   - **xhigh / max 사용 금지**: 생각 단계 초안 이중 작성, 5시간 윈도우 급소진의 주원인
   - **low 비권장**: 검색·조회 도구 호출이 줄어 지휘자 역할에 부적합

---

## 5. 운영 모드 (권장)

| 모드 | 명령 | 메인 | Fable 사용 | 언제 |
|---|---|---|---|---|
| 기본 | `fable off` | Opus 5.5 | 필요할 때 직접 `/model` 전환 | 일상 개발 대부분 |
| 지휘자 | `fable on` | Fable 5.1 (medium) | 계획·분배·종합 | 여러 모듈에 걸친 큰 작업, 설계 단계 |

Max 요금제에서 Fable 5.1은 **공유 주간 한도의 최대 50%** 까지만 쓸 수 있습니다. 평소에는 꺼 두고 큰 작업에만 켜는 편이 한도 관리에 유리합니다.

세션 위생도 함께 지킵니다.

- 작업 단위가 바뀌면 `/clear`
- 긴 작업 중 맥락이 커지면 `/compact`

---

## 6. 동작 검증 (설치 직후 1회)

`fable on` 후 새 세션에서 아래를 순서대로 요청해 보세요.

| # | 요청 | 기대 결과 |
|---|---|---|
| 1 | "a.py, b.py 두 파일에 주석 한 줄씩 추가해줘" | 메인이 직접 수정 (허용) |
| 2 | 같은 턴에서 "c.py도" | 3번째 파일 차단 → 서브에이전트 위임 메시지 |
| 3 | "README.md 수정해줘" | 허용 (문서는 무제한) |
| 4 | 50줄 넘는 기존 .py를 통째로 다시 쓰게 유도 | `Write` 차단 → Edit 사용 안내 |
| 5 | "sed -i로 a.py 고쳐줘" | 차단 |
| 6 | "npm test 2>&1 \| tail 실행" | 허용 |
| 7 | 서브에이전트에게 파일 3개 이상 수정 위임 | 서브에이전트는 제한 없이 수정 (단, 4번 규칙은 적용) |

확인:

```bash
fable status
fable log 20
```

---

## 7. 효과 측정 (1주)

1. 적용 전 하루: 평소처럼 작업하며 `/usage`로 5시간 윈도우 소진 속도와 Fable 비중을 기록
2. 적용 후 같은 유형의 작업으로 비교
3. 조정 레버
   - 소진이 여전히 빠름 → 메인 effort medium 유지 확인, 병렬 서브에이전트 수 축소, `/compact` 빈도 증가
   - 위임이 너무 잦아 느림 → `FABLE_GATE_LIMIT=3`
   - 작은 파일 재작성 차단이 과함 → `FABLE_REWRITE_LINES=100`

환경변수는 훅 명령에 붙이거나, 특정 프로젝트에만 적용하려면 그 프로젝트의 `.claude/settings.json` `env`에 넣습니다. 게이트를 아예 끄려면 `fable project off`를 쓰세요.

```json
"command": "FABLE_GATE_LIMIT=3 FABLE_REWRITE_LINES=100 python3 \"$HOME/.claude/fable/hooks/orchestration-gate.py\""
```

---

## 8. 끄기와 제거

- 일시 중지: `fable off` (게이트·지시문 모두 비활성, 다음 세션부터)
- 프로젝트 하나만 제외: 그 프로젝트에서 `fable project off`
- 완전 제거: `fable global off` 로 settings.json 의 env 를 정리한 뒤 연결 지점 4곳 삭제, 폴더 삭제

```bash
fable global off
# 1) CLAUDE.md 의 @.../fable/active.md 줄 삭제
# 2) settings.json 의 orchestration-gate.py 훅 항목 삭제
# 3) 링크 삭제
rm ~/.claude/agents/deep-reasoner.md ~/.claude/agents/runner.md
# 4) 셸 rc 의 source env.sh 줄 삭제
rm -rf ~/.claude/fable ~/.claude/.fable-state
```

---

## 9. 알려진 한계

- **서브에이전트 모델 확인 필수**: `fable on` 세션에서 서브에이전트가 실제로 Opus 5.5로 도는지 `/agents` 또는 서브에이전트 출력의 모델 표시로 한 번 확인하세요. `CLAUDE_CODE_SUBAGENT_MODEL`이 전달되지 않는 경로(IDE 확장 등)에서는 `general-purpose`가 Fable 5.1로 실행됩니다. 그 경우 `settings.json`의 `env`에 넣으세요(3-6절).

- **fail-open**: 게이트 오류·타임아웃 시 도구 호출은 통과합니다. 대신 `gate.log`에 `ERROR`로 남으니 `fable status`에서 주기적으로 확인하세요.
- **prompt_id 없음**: Claude Code 2.1.196 미만이면 턴 한도가 적용되지 않고 `WARN`만 기록됩니다.
- **Bash 탐지는 완전하지 않음**: 주요 우회 경로는 막지만, 스크립트 파일을 만들어 실행하는 식의 간접 경로까지 모두 막을 수는 없습니다. 지시문과 게이트가 함께 작동하는 구조입니다.
- **`cp`/`mv` 차단 범위**: 메인이 코드 파일을 대상으로 복사·이동하는 것도 막힙니다. 필요하면 `runner`에 맡기세요.
- **수치 출처**: Fable 5.1의 출력 22% 증가, 전체 재작성 44% 같은 수치는 외부 블로그 측정값입니다. 실제 효과는 7번 절차로 직접 측정하세요.

---

## 참고

- Prompting Claude Fable 5.1 — https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-fable-5-1
- Hooks reference — https://code.claude.com/docs/en/hooks
- Two Meters: Fable 5.1 on Max — https://paddo.dev/blog/fable-5-1-two-meters/
- Fable 5.1 Usage Limits (Pro/Max) — https://www.aifreeapi.com/en/posts/claude-fable-pro-max-weekly-limits
- Claude Opus 5.5 — https://www.requesty.ai/blog/claude-opus-5-5-explained

# Fable 5.1 오케스트레이션 적용 가이드 — Windows (PowerShell)

> 기준일 2026-10-04 · 메인 Fable 5.1 / 구현 Opus 5.5 / 유틸 Haiku 4.5
> 원본 대비 변경점, effort 운영, 효과 측정, 알려진 한계는 공통 가이드 `APPLY-GUIDE.md`의 0·4·5·7·9절을 참고하세요. 이 문서는 Windows 설치·운영 절차만 다룹니다.
> WSL 안에서 Claude Code를 쓴다면 이 문서가 아니라 공통 가이드(Linux)를 따르세요.

---

## 1. 준비물

| 항목 | 확인 명령 (PowerShell) | 없을 때 |
|---|---|---|
| Claude Code 2.1.196+ | `claude --version` | `claude update` |
| Python 3.8+ | `py -3 --version` | `winget install Python.Python.3.12` |
| Git for Windows (권장) | `git --version` | `winget install Git.Git` |
| 스크립트 실행 허용 | `Get-ExecutionPolicy -Scope CurrentUser` | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |

배포 파일:

```
fable\
├── fable.md
├── orchestration-gate.py
├── fable-settings.py
└── windows\
    ├── env.ps1
    └── APPLY-GUIDE-Windows.md   ← 이 문서
```

### macOS·Linux 버전과 다른 점

| 항목 | macOS/Linux | Windows |
|---|---|---|
| ON/OFF 스위치 | 심볼릭 링크 | **파일 복사** (개발자 모드·관리자 권한 불필요) |
| 에이전트 연결 | 심볼릭 링크 | **파일 복사** |
| 셸 연결 | `~/.zshrc` | `$PROFILE` |
| 훅 실행 | `python3 "$HOME/..."` | `command: "py"` + `args` (셸을 거치지 않아 Git Bash·PowerShell 어느 쪽이든 동일) |
| 차단 대상 셸 툴 | Bash | Bash **+ PowerShell 툴** (`Set-Content`, `Out-File`, `Copy-Item`, `[IO.File]::Write*` 등) |
| 파일명 대소문자 | Linux 구분 / macOS 무시 | 무시 (`App.py` = `app.py`) |
| 한글 인코딩 | — | 게이트가 입출력을 UTF-8/ASCII로 고정해 cp949 콘솔에서도 안전 |

---

## 2. 설치

배포 파일이 있는 `fable` 폴더에서 PowerShell을 열고 순서대로 실행합니다.

### 2-1. 파일 배치

```powershell
$C = Join-Path $HOME '.claude'
$F = Join-Path $C 'fable'
New-Item -ItemType Directory -Force -Path "$F\agents", "$F\hooks", "$F\state", "$C\agents" | Out-Null

Copy-Item .\fable.md                "$F\fable.md" -Force
Copy-Item .\orchestration-gate.py   "$F\hooks\orchestration-gate.py" -Force
Copy-Item .\fable-settings.py       "$F\hooks\fable-settings.py" -Force
Copy-Item .\windows\env.ps1         "$F\env.ps1" -Force

# UTF-8(BOM 없음) 쓰기 도우미
function Write-Utf8($Path, $Text) { [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding $false)) }

Write-Utf8 "$F\empty.md"  ''
Write-Utf8 "$F\active.md" ''
Set-Content -Path "$C\.fable-state" -Value 'off' -NoNewline -Encoding ascii
```

### 2-2. 서브에이전트 정의

```powershell
Write-Utf8 "$F\agents\deep-reasoner.md" @'
---
name: deep-reasoner
description: 어려운 설계 판단, 원인 불명 버그 분석, 트레이드오프 검토가 필요할 때 사용. 구현은 하지 않고 결론과 근거만 반환.
model: claude-opus-5-5
effort: high
tools: Read, Grep, Glob, Bash
---
너는 분석 전담이다. 코드를 수정하지 말고 다음 형식으로만 답한다:
1) 결론 2) 근거 3~5줄 3) 대안과 각각의 리스크 4) 다음 행동 제안.
'@

Write-Utf8 "$F\agents\runner.md" @'
---
name: runner
description: 명령 실행, 테스트 실행, 빌드, 로그·출력 확인, 파일 탐색 같은 단순 작업에 사용.
model: claude-haiku-4-5-20251001
effort: low
tools: Bash, Read, Grep, Glob
---
요청받은 명령만 실행하고, 결과를 요약해서 돌려준다.
성공/실패, 핵심 에러 메시지(최대 20줄), 관련 파일 경로만 포함한다. 파일을 수정하지 않는다.
'@

Copy-Item "$F\agents\deep-reasoner.md" "$C\agents\deep-reasoner.md" -Force
Copy-Item "$F\agents\runner.md"        "$C\agents\runner.md" -Force
```

> - 모델 ID는 Claude Code에서 `/model`로 확인하고 다르면 바꾸세요.
> - Git Bash 없이 PowerShell 툴만 쓰는 환경이면 `runner`의 `tools`에 `PowerShell`을 추가하세요.
> - 에이전트 파일은 복사본입니다. `$F\agents\`의 원본을 고친 뒤에는 위 `Copy-Item` 두 줄을 다시 실행하세요.

### 2-3. 프로필 연결 (`$PROFILE`)

```powershell
if (-not (Test-Path $PROFILE)) { New-Item -ItemType File -Force -Path $PROFILE | Out-Null }
if (-not (Select-String -Path $PROFILE -Pattern 'fable\env.ps1' -SimpleMatch -Quiet)) {
  Add-Content -Path $PROFILE -Value "`n. `"`$HOME\.claude\fable\env.ps1`""
}
. $PROFILE
```

> Windows PowerShell 5.1과 PowerShell 7은 `$PROFILE` 경로가 다릅니다. 둘 다 쓰면 각각에서 한 번씩 실행하세요.

### 2-4. `CLAUDE.md` import

```powershell
$M = "$C\CLAUDE.md"
if (-not ((Test-Path $M) -and (Select-String -Path $M -Pattern 'fable/active.md' -SimpleMatch -Quiet))) {
  Add-Content -Path $M -Value "`n@~/.claude/fable/active.md" -Encoding utf8
}
```

> import가 인식되지 않으면 절대경로(슬래시 사용)로 바꿉니다: `@C:/Users/<사용자>/.claude/fable/active.md`

### 2-5. `settings.json` 훅 등록

기존 설정을 보존한 채 자동으로 병합합니다.

```powershell
$S = "$C\settings.json"
$gate = ("$F\hooks\orchestration-gate.py") -replace '\\', '/'
$cfg = if (Test-Path $S) { Get-Content $S -Raw -Encoding utf8 | ConvertFrom-Json } else { [pscustomobject]@{} }

if (-not $cfg.PSObject.Properties['hooks']) { $cfg | Add-Member hooks ([pscustomobject]@{}) }
if (-not $cfg.hooks.PSObject.Properties['PreToolUse']) { $cfg.hooks | Add-Member PreToolUse @() }

$entry = [pscustomobject]@{
  matcher = 'Write|Edit|MultiEdit|NotebookEdit|Bash|PowerShell'
  hooks   = @([pscustomobject]@{ type = 'command'; command = 'py'; args = @('-3', $gate); timeout = 10 })
}
$cfg.hooks.PreToolUse = @($cfg.hooks.PreToolUse | Where-Object { ($_ | ConvertTo-Json -Depth 10) -notmatch 'orchestration-gate' }) + $entry

Copy-Item $S "$S.bak" -ErrorAction SilentlyContinue
Write-Utf8 $S ($cfg | ConvertTo-Json -Depth 20)
```

결과는 다음 형태가 됩니다.

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit|NotebookEdit|Bash|PowerShell",
        "hooks": [
          {
            "type": "command",
            "command": "py",
            "args": ["-3", "C:/Users/<사용자>/.claude/fable/hooks/orchestration-gate.py"],
            "timeout": 10
          }
        ]
      }
    ]
  }
}
```

> `py` 런처가 없으면 `command`를 `python`으로 바꾸고 `args`에서 `-3`을 지웁니다.

### 2-6. 확인

새 PowerShell 창에서:

```powershell
fable status
```

모든 항목이 `[ok]`이면 설치 완료입니다.

---

## 3. Windows에서 주의할 점

### 3-1. 시작 메뉴·IDE에서 실행한 Claude Code에는 래퍼가 적용되지 않음

`$PROFILE`의 `claude` 래퍼(Sonnet → Opus 5.5 재매핑)는 **PowerShell에서 실행한 `claude`** 에만 적용됩니다. 아래 경우에는 적용되지 않습니다.

- VS Code·JetBrains 확장
- Claude 데스크톱 앱의 Code 탭
- cmd.exe, Git Bash에서 실행한 `claude`

게이트와 지시문은 어느 경로에서든 동작하고, 영향을 받는 것은 모델 전환 하나뿐입니다. 해결 방법은 둘 중 하나를 고르세요.

- **간단:** PowerShell에서 `code .`로 VS Code를 실행합니다. 셸 환경을 물려받습니다.
- **항상 적용 (권장):** `fable global on`을 실행합니다. `~\.claude\settings.json`의 `env`에 아래가 기록되어 IDE·앱·cmd·Git Bash 모두에 적용됩니다. `fable global off`로 되돌립니다. 이 경우 `fable off`여도 서브에이전트 모델은 유지됩니다.

```json
{
  "env": {
    "CLAUDE_CODE_SUBAGENT_MODEL": "claude-opus-5-5",
    "ANTHROPIC_DEFAULT_SONNET_MODEL": "claude-opus-5-5"
  }
}
```

### 3-2. 게이트 한도 조정은 `settings.json`의 `env`로

`args` 방식은 셸을 거치지 않아 명령 앞에 환경변수를 붙일 수 없습니다. 한도를 바꾸려면 `settings.json`에 넣으세요. 특정 프로젝트에서 게이트를 아예 끄려면 그 폴더에서 `fable project off`를 실행합니다.

```json
{ "env": { "FABLE_GATE_LIMIT": "3", "FABLE_REWRITE_LINES": "100" } }
```

### 3-3. 백신·EDR

일부 보안 제품이 매 도구 호출마다 실행되는 `py`를 지연시킬 수 있습니다. 훅이 10초 제한 시간을 넘기면 통과 처리(fail-open)되므로, `fable log`에 기록이 없는데 차단이 안 된다면 `timeout`을 30으로 늘려 보세요.

---

## 4. 일상 운영

```powershell
fable on        # 지휘자 모드 (다음 세션부터)
fable off       # 기본 모드 (다음 세션부터)
fable status    # 설치·상태·버전·로그 요약
fable log 30    # 최근 차단/경고/오류 30줄

fable global on          # IDE·앱 포함 전체에 서브에이전트 모델 적용 (~\.claude\settings.json)
fable global off
fable project off        # 현재 프로젝트에서만 게이트 끄기 (.\.claude\settings.json)
fable project off -Local # settings.local.json 에 기록 (git 미커밋)
fable project on
```

세 스위치의 적용 범위 차이는 공통 가이드의 "스위치 세 가지" 절을 참고하세요.

`fable on` 후 새 세션에서 `/model`로 **Fable 5.1**을 고르고 effort를 **medium**으로 둡니다.

---

## 5. 동작 검증

`fable on` 후 새 세션에서 요청해 보세요.

| # | 요청 | 기대 결과 |
|---|---|---|
| 1 | "a.py, b.py에 주석 한 줄씩 추가" | 허용 |
| 2 | 같은 턴에서 "c.py도" | 차단 → 위임 안내 |
| 3 | "README.md 수정" | 허용 |
| 4 | 50줄 넘는 기존 .py 전체 재작성 유도 | `Write` 차단 → Edit 안내 |
| 5 | "Set-Content로 a.py 내용 바꿔줘" | 차단 |
| 6 | "npm test 실행해서 마지막 20줄 보여줘" | 허용 |

훅만 따로 시험하려면:

```powershell
Set-Content "$HOME\.claude\.fable-state" 'on' -NoNewline -Encoding ascii
1..100 | Set-Content "$env:TEMP\big.py"
$p = ("$env:TEMP\big.py") -replace '\\', '/'
"{`"tool_name`":`"Write`",`"tool_input`":{`"file_path`":`"$p`"}}" | py -3 "$HOME\.claude\fable\hooks\orchestration-gate.py"
# → "permissionDecision": "deny" 가 출력되면 정상
Remove-Item "$env:TEMP\big.py"
fable off   # 시험 후 원래 상태로
```

---

## 6. 제거

```powershell
fable off
# 1) ~\.claude\CLAUDE.md 에서 '@~/.claude/fable/active.md' 줄 삭제
# 2) ~\.claude\settings.json 에서 orchestration-gate 훅 항목 삭제 (설치 시 만든 settings.json.bak 참고)
Remove-Item "$HOME\.claude\agents\deep-reasoner.md", "$HOME\.claude\agents\runner.md"
# 3) $PROFILE 에서 '. "$HOME\.claude\fable\env.ps1"' 줄 삭제
Remove-Item -Recurse -Force "$HOME\.claude\fable", "$HOME\.claude\.fable-state"
```

`fable global on`을 썼다면 그 전에 `fable global off`로 `settings.json`의 `env`를 정리하세요.

---

## 7. 문제 해결

| 증상 | 원인 | 조치 |
|---|---|---|
| `env.ps1` 로드 시 "스크립트를 실행할 수 없습니다" | 실행 정책 | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| `fable status`의 한글이 깨짐 | 콘솔 코드페이지 | `env.ps1`은 UTF-8(BOM)로 저장돼 있음. 다시 저장했다면 BOM 포함 UTF-8로 저장 |
| 차단이 전혀 안 됨 | 상태 off / 훅 미등록 / `py` 없음 | `fable status`, `fable log` 확인 |
| `gate.log`에 `WARN prompt_id 없음` | Claude Code 2.1.196 미만 | `claude update` |
| `gate.log`에 `ERROR` | 훅 입력 파싱 실패 등 | 로그 메시지 확인 후 공유 |
| `claude` 래퍼가 자기 자신을 호출 | 다른 프로필에 `claude` 함수가 또 있음 | `Get-Command claude -All`로 중복 확인 |
| 서브에이전트가 Opus 4.x/Sonnet으로 돎 | 래퍼 미적용 경로로 실행 | 3-1절 참고 |

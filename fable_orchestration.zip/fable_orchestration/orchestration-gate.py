#!/usr/bin/env python3
"""
orchestration-gate.py — Fable 오케스트레이션 PreToolUse 게이트

변경 이유
  - 원본 가이드의 `agent_id or agent_type` 판별은 `claude --agent X`로 띄운
    메인 세션도 서브에이전트로 오인해 게이트가 뚫림 → agent_id 만으로 판별.
  - Fable 5.1의 파일 전체 재작성 경향 대응 → 기존 코드 파일 Write 차단(모든 에이전트).
  - Bash 우회 패턴 보강(tee, python -c, node -e, git apply, patch, cp/mv),
    리다이렉트는 "코드 파일이 대상일 때만" 차단해 2>&1, >/dev/null, 로그 저장 허용.
  - fail-open 상태가 조용히 묻히지 않도록 모든 예외·경고를 gate.log에 기록.
  - Windows/macOS 호환: stdin/stdout UTF-8 고정(cp949 콘솔에서 한글 경로·메시지
    인코딩 오류로 fail-open 되는 문제 방지), PowerShell 툴 우회 패턴 추가,
    대소문자 무시 파일시스템(Windows·macOS)에서 같은 파일을 중복 카운트하지 않음.

규칙 적용 순서
  0. fable 상태가 on 이 아니면 전부 허용
  1. [전 에이전트] 기존 코드 파일(REWRITE_LINES 줄 초과)에 Write → 차단, Edit 유도
  2. 서브에이전트(agent_id 존재) → 이후 규칙 면제
  3. [메인] Bash로 코드 수정 시도 → 차단
  4. [메인] 코드 파일 편집은 prompt_id(턴)당 서로 다른 파일 LIMIT 개까지

설정(환경변수로 덮어쓰기 가능)
  FABLE_GATE_LIMIT      메인의 턴당 코드 파일 수정 한도 (기본 2)
  FABLE_REWRITE_LINES   이 줄 수를 넘는 기존 파일의 Write 차단 (기본 50)
  FABLE_GATE_OFF=1      이 프로젝트에서 게이트 비활성. 프로젝트 .claude/settings.json 또는
                        settings.local.json 의 env 에 넣는다 (`fable project off`).
                        환경변수로 안 들어와도 cwd 에서 위로 올라가며 두 파일을 직접 읽는다.

의존: Python 3.8+, Claude Code v2.1.196+ (prompt_id 필드)
"""
import json
import os
import re
import sys
import time

# ── 설정 ──────────────────────────────────────────────────────────────
HOME = os.path.expanduser("~")
FABLE_HOME = os.path.join(HOME, ".claude", "fable")
STATE_FILE = os.path.join(HOME, ".claude", ".fable-state")
COUNTER_DIR = os.path.join(FABLE_HOME, "state")
LOG_FILE = os.path.join(FABLE_HOME, "gate.log")
LOG_MAX_BYTES = 1_000_000

LIMIT = int(os.environ.get("FABLE_GATE_LIMIT", "2"))
REWRITE_LINES = int(os.environ.get("FABLE_REWRITE_LINES", "50"))

CODE_EXTS = (
    ".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".vue", ".svelte",
    ".java", ".kt", ".kts", ".scala", ".go", ".rs", ".c", ".h", ".cc", ".cpp",
    ".hpp", ".cs", ".swift", ".m", ".mm", ".rb", ".php", ".lua", ".dart",
    ".sh", ".bash", ".zsh", ".sql", ".r", ".jl", ".ex", ".exs", ".erl",
    ".clj", ".hs", ".ml", ".fs", ".pl", ".pm", ".ipynb",
    ".html", ".css", ".scss", ".sass", ".less", ".ps1", ".psm1", ".bat", ".cmd",
)
SHELL_TOOLS = {"Bash", "PowerShell"}
CASE_INSENSITIVE_FS = sys.platform in ("win32", "darwin")
EDIT_TOOLS = {"Write", "Edit", "MultiEdit", "NotebookEdit"}

# 코드 파일 경로를 잡는 정규식 조각 (따옴표 허용)
_EXT_ALT = "|".join(re.escape(e.lstrip(".")) for e in CODE_EXTS)
_CODE_PATH = r"""['"]?[^\s'";|&<>]+\.(?:%s)['"]?(?=\s|$|[;|&)])""" % _EXT_ALT

# 셸별 차단 패턴. 공통(_COMMON)은 양쪽에, 나머지는 해당 셸 툴에만 적용해
# 커밋 메시지 등 자연어 속 'move utils.py' 같은 오탐을 줄인다.
_COMMON_PATTERNS = [
    # 인라인 스크립트로 파일 쓰기
    (r"\bpy(?:thon[0-9.]*)?(?:\.exe)?\s+(?:-[0-9.]+\s+)?-c\b.*(open\([^)]*['\"][wa+]|write_text|write_bytes)", "python -c 파일 쓰기"),
    (r"\bnode\s+(-e|--eval|-p)\b.*(writeFile|appendFile|createWriteStream)", "node -e 파일 쓰기"),
    # 패치 적용
    (r"\bgit\s+apply\b", "git apply"),
    # 코드 파일을 대상으로 하는 리다이렉트
    (r"(?<![0-9&])>>?\s*" + _CODE_PATH, "코드 파일로 리다이렉트"),
]
BASH_BLOCK_PATTERNS = _COMMON_PATTERNS + [
    # in-place 편집기
    (r"\bsed\b[^|;&]*\s-[a-zA-Z]*i", "sed -i"),
    (r"\bperl\b[^|;&]*\s-[a-zA-Z]*i", "perl -i"),
    (r"\bruby\b[^|;&]*\s-[a-zA-Z]*i", "ruby -i"),
    (r"(^|[;&|]\s*)patch\s+-", "patch"),  # 명령 위치의 patch -p1 … 만 (문장 속 'patch' 는 제외)
    # tee / cp / mv / install
    (r"\btee\b(\s+-[a-zA-Z]+)*\s+" + _CODE_PATH, "tee 코드 파일"),
    (r"(^|[;&|]\s*)(cp|mv|install|rsync)\s[^;&|]*\s" + _CODE_PATH + r"\s*($|[;&|])", "cp/mv 로 코드 파일 덮어쓰기"),
    # heredoc 으로 코드 파일 생성
    (r"\bcat\b[^;&|]*<<-?\s*['\"]?\w+['\"]?[^;&|]*>\s*" + _CODE_PATH, "heredoc 코드 파일 생성"),
]
POWERSHELL_BLOCK_PATTERNS = _COMMON_PATTERNS + [
    (r"\b(Set-Content|Add-Content|Out-File|sc|ac)\b[^;|]*" + _CODE_PATH, "PowerShell 파일 쓰기"),
    (r"\bNew-Item\b[^;|]*" + _CODE_PATH + r"[^;|]*-Value\b", "New-Item -Value"),
    (r"(^|[;|]\s*)(Copy-Item|Move-Item|cpi|mi|copy|move)\s[^;|]*\s" + _CODE_PATH + r"\s*($|[;|])", "Copy/Move-Item 로 코드 파일 덮어쓰기"),
    (r"\[(System\.)?IO\.File\]::(Write|Append)", "[IO.File]::Write*"),
]
_SHELL_RE = {
    "Bash": [(re.compile(p, re.IGNORECASE | re.DOTALL), n) for p, n in BASH_BLOCK_PATTERNS],
    "PowerShell": [(re.compile(p, re.IGNORECASE | re.DOTALL), n) for p, n in POWERSHELL_BLOCK_PATTERNS],
}
# 커밋/PR 메시지처럼 자연어가 들어가는 인용 인자. 매칭 전에 비워서 오탐을 막는다.
_MESSAGE_ARG_RE = re.compile(
    r"""(?:(?<=\s)|^)(-m|--message|-b|--body|-t|--title|--description)(\s+|=)(?:"(?:[^"\\]|\\.)*"|'[^']*')""",
    re.DOTALL,
)


# ── 공통 유틸 ─────────────────────────────────────────────────────────
def log(level, msg, **ctx):
    try:
        os.makedirs(FABLE_HOME, exist_ok=True)
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_BYTES:
            os.replace(LOG_FILE, LOG_FILE + ".1")
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "level": level, "msg": msg, **ctx}
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def allow():
    sys.exit(0)


def deny(reason, **ctx):
    log("DENY", reason, **ctx)
    payload = json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": reason,
        }
    }, ensure_ascii=True)  # ASCII 이스케이프 → 콘솔 코드페이지(cp949 등)와 무관하게 안전
    sys.stdout.write(payload + "\n")
    sys.stdout.flush()
    sys.exit(0)


def read_input():
    raw = sys.stdin.buffer.read()
    return json.loads(raw.decode("utf-8-sig"))


def fable_on():
    try:
        # utf-8-sig: 메모장 등으로 편집해 BOM 이 붙어도 'on' 으로 읽히게
        with open(STATE_FILE, encoding="utf-8-sig") as f:
            return f.read().strip().lower() == "on"
    except FileNotFoundError:
        return False


_TRUE = {"1", "true", "yes", "on"}


def project_gate_off(cwd):
    """프로젝트별 끄기 스위치. env → cwd 상위 폴더들의 .claude/settings*.json 순으로 확인."""
    if os.environ.get("FABLE_GATE_OFF", "").strip().lower() in _TRUE:
        return True
    d = os.path.abspath(cwd or os.getcwd())
    for _ in range(32):
        for name in ("settings.local.json", "settings.json"):
            p = os.path.join(d, ".claude", name)
            if os.path.isfile(p):
                try:
                    with open(p, encoding="utf-8-sig") as f:
                        env = (json.load(f) or {}).get("env") or {}
                    if str(env.get("FABLE_GATE_OFF", "")).strip().lower() in _TRUE:
                        return True
                except Exception as e:
                    log("WARN", f"프로젝트 설정 읽기 실패: {p}: {e}")
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return False


def is_code(path):
    return bool(path) and path.lower().endswith(CODE_EXTS)


def resolve(path, cwd):
    if not path:
        return ""
    path = os.path.expanduser(path)
    if not os.path.isabs(path):
        path = os.path.join(cwd or os.getcwd(), path)
    return os.path.normpath(path)


def file_key(path):
    """턴 카운트용 키. 대소문자 무시 파일시스템에서는 소문자로 통일."""
    return path.lower() if CASE_INSENSITIVE_FS else path


def count_lines(path):
    n = 0
    with open(path, "rb") as f:
        for _ in f:
            n += 1
    return n


# ── 규칙 ──────────────────────────────────────────────────────────────
def rule_full_rewrite(tool, inp, cwd, who):
    """[전 에이전트] 기존 코드 파일 전체 재작성 차단."""
    if tool != "Write":
        return
    path = resolve(inp.get("file_path", ""), cwd)
    if not is_code(path) or not os.path.isfile(path):
        return
    lines = count_lines(path)
    if lines > REWRITE_LINES:
        deny(
            f"[fable-gate] {os.path.basename(path)}({lines}줄)는 이미 존재하는 코드 파일입니다. "
            f"Write로 전체를 다시 쓰지 말고 Edit로 바뀌는 부분만 수정하세요.",
            rule="full_rewrite", who=who, path=path, lines=lines,
        )


def rule_shell(tool, cmd):
    """[메인] Bash/PowerShell 로 코드 파일을 고치는 우회 차단."""
    scan = _MESSAGE_ARG_RE.sub(r"\1\2''", cmd)  # -m "..." 등 메시지 인자 제거
    for rx, name in _SHELL_RE.get(tool, ()):
        if rx.search(scan):
            deny(
                f"[fable-gate] 메인 에이전트는 {tool}로 코드 파일을 수정할 수 없습니다({name}). "
                f"구현 작업은 general-purpose 서브에이전트에 위임하세요.",
                rule="shell", tool=tool, pattern=name, cmd=cmd[:300],
            )


def rule_turn_limit(tool, inp, cwd, data):
    """[메인] prompt_id 당 서로 다른 코드 파일 LIMIT 개까지."""
    path = resolve(inp.get("file_path") or inp.get("notebook_path") or "", cwd)
    if not is_code(path):
        return
    prompt_id = data.get("prompt_id")
    if not prompt_id:
        log("WARN", "prompt_id 없음 — 턴 한도 미적용(fail-open). Claude Code v2.1.196+ 필요",
            tool=tool, path=path)
        return

    session = re.sub(r"[^A-Za-z0-9_-]", "_", data.get("session_id", "default"))
    os.makedirs(COUNTER_DIR, exist_ok=True)
    counter = os.path.join(COUNTER_DIR, f"turn-{session}.json")

    state = {"prompt_id": None, "files": []}
    if os.path.exists(counter):
        with open(counter, encoding="utf-8") as f:
            state = json.load(f)
    if state.get("prompt_id") != prompt_id:
        state = {"prompt_id": prompt_id, "files": []}

    key = file_key(path)
    if key in (file_key(p) for p in state["files"]):
        return  # 같은 파일 재수정은 카운트하지 않음
    if len(state["files"]) >= LIMIT:
        done = ", ".join(os.path.basename(p) for p in state["files"])
        deny(
            f"[fable-gate] 이번 턴에 메인이 수정할 수 있는 코드 파일 {LIMIT}개를 모두 사용했습니다({done}). "
            f"{os.path.basename(path)} 수정을 포함한 나머지 구현은 general-purpose 서브에이전트에 위임하세요.",
            rule="turn_limit", path=path, used=state["files"],
        )

    state["files"].append(path)
    tmp = counter + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f)
    os.replace(tmp, counter)


def cleanup_counters(max_age_sec=7 * 86400):
    try:
        now = time.time()
        for name in os.listdir(COUNTER_DIR):
            p = os.path.join(COUNTER_DIR, name)
            if now - os.path.getmtime(p) > max_age_sec:
                os.remove(p)
    except Exception:
        pass


# ── 진입점 ────────────────────────────────────────────────────────────
def main():
    if not fable_on():
        allow()

    data = read_input()
    tool = data.get("tool_name", "")
    inp = data.get("tool_input", {}) or {}
    cwd = data.get("cwd", "")
    if project_gate_off(cwd):
        allow()
    is_sub = bool(data.get("agent_id"))  # agent_type 은 --agent 메인 세션에도 들어오므로 사용 금지
    who = f"sub:{data.get('agent_type', '?')}" if is_sub else "main"

    # 1. 전 에이전트 공통
    rule_full_rewrite(tool, inp, cwd, who)

    # 2. 서브에이전트는 이후 규칙 면제
    if is_sub:
        allow()

    # 3~4. 메인 전용
    if tool in SHELL_TOOLS:
        rule_shell(tool, inp.get("command", ""))
    elif tool in EDIT_TOOLS:
        rule_turn_limit(tool, inp, cwd, data)
        if int(time.time()) % 50 == 0:
            cleanup_counters()

    allow()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:  # fail-open: 게이트 오류로 작업이 멈추지 않게 하되 반드시 기록
        log("ERROR", f"{type(e).__name__}: {e}")
        sys.exit(0)

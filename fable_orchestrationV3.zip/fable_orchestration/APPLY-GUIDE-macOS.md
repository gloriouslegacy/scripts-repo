# Fable 5.1 오케스트레이션 적용 가이드 — macOS (Max 요금제 전용)

> 기준일 2026-10-06
> **Max 요금제 전용 구성**입니다. 메인 Fable 5.1 / 구현 Opus 5.5 / 유틸 Haiku 4.5.
> Pro 요금제에서는 Fable 5.1이 첫 요청부터 사용 크레딧(API 요금)으로 과금되므로 이 구성을 그대로 쓰지 마세요.
> 원본 대비 변경점, effort 운영, 효과 측정, 알려진 한계는 공통 가이드 `APPLY-GUIDE.md`의 0·4·5·7·9절을 참고하세요. 이 문서는 macOS 설치·운영 절차만 다룹니다.

---

## 1. 준비물

| 항목 | 확인 명령 | 없을 때 |
|---|---|---|
| Claude Code 2.1.196+ | `claude --version` | `claude update` |
| Python 3.8+ | `python3 --version` | `xcode-select --install` 또는 `brew install python` |
| 셸 | `echo $SHELL` | macOS 기본은 zsh (`~/.zshrc`) |

> `python3`를 처음 실행할 때 "명령어 라인 개발자 도구 설치" 창이 뜨면 설치를 마친 뒤 진행하세요. 설치 전에는 게이트가 실행되지 않습니다(fail-open).

배포 폴더 `fable_orchestration` 은 한 폴더에 모든 파일이 들어 있습니다.

```
fable_orchestration/
├── fable.md                 # 오케스트레이션 지시문 (Max 전용)
├── orchestration-gate.py    # PreToolUse 게이트
├── fable-settings.py        # global / project 스위치
├── progress-watch.py        # 서브에이전트 멈춤 감시 (Monitor 가 실행)
├── env.sh                   # macOS·Linux 셸 스위치
├── env.ps1                  # Windows PowerShell 스위치
├── APPLY-GUIDE.md           # 공통 가이드 (Linux·WSL 설치 포함)
├── APPLY-GUIDE-macOS.md     ← 이 문서
└── APPLY-GUIDE-Windows.md
```

---

## 2. 설치

배포 폴더(`fable_orchestration`)에서 터미널을 열고 순서대로 실행합니다.

> **Windows에서 쓰던 설치본을 옮기는 경우에도** Windows의 `~/.claude/fable` 폴더를 복사하지 말고 이 배포 폴더로 새로 설치하세요. Windows의 `settings.json`(훅이 `py -3` + `C:/Users/...` 경로), `env.ps1`, `state/`, `gate.log`, `.fable-state`는 맥에서 쓸 수 없습니다. 지시문 수정분은 이 폴더의 `fable.md`에 이미 반영돼 있습니다.

### 2-1. 파일 배치

```bash
mkdir -p ~/.claude/fable/{agents,hooks,state} ~/.claude/agents
cp fable.md               ~/.claude/fable/fable.md
cp orchestration-gate.py  ~/.claude/fable/hooks/orchestration-gate.py
cp fable-settings.py      ~/.claude/fable/hooks/fable-settings.py
cp progress-watch.py      ~/.claude/fable/hooks/progress-watch.py
cp env.sh                 ~/.claude/fable/env.sh
chmod +x ~/.claude/fable/hooks/orchestration-gate.py
: > ~/.claude/fable/empty.md
echo off > ~/.claude/.fable-state
ln -sfn ~/.claude/fable/empty.md ~/.claude/fable/active.md

# Windows에서 받은 파일이면 CRLF 줄바꿈·BOM 제거 (이미 LF면 변화 없음)
for f in ~/.claude/fable/fable.md ~/.claude/fable/env.sh ~/.claude/fable/hooks/*.py; do
  sed -i '' -e $'s/\r$//' -e $'1s/^\xEF\xBB\xBF//' "$f"
done
```

### 2-2. 서브에이전트 정의

```bash
cat > ~/.claude/fable/agents/deep-reasoner.md <<'EOF'
---
name: deep-reasoner
description: 어려운 설계 판단, 원인 불명 버그 분석, 트레이드오프 검토가 필요할 때 사용. 구현은 하지 않고 결론과 근거만 반환.
model: claude-opus-5-5
effort: high
tools: Read, Grep, Glob, Bash
---
너는 분석 전담이다. 코드를 수정하지 말고 다음 형식으로만 답한다:
1) 결론 2) 근거 3~5줄 3) 대안과 각각의 리스크 4) 다음 행동 제안.
EOF

cat > ~/.claude/fable/agents/runner.md <<'EOF'
---
name: runner
description: 명령 실행, 테스트 실행, 빌드, 로그·출력 확인, 파일 탐색 같은 단순 작업에 사용.
model: claude-haiku-4-5-20251001
effort: low
tools: Bash, Read, Grep, Glob
---
요청받은 명령만 실행하고, 결과를 요약해서 돌려준다.
성공/실패, 핵심 에러 메시지(최대 20줄), 관련 파일 경로만 포함한다. 파일을 수정하지 않는다.
EOF

ln -sfn ~/.claude/fable/agents/deep-reasoner.md ~/.claude/agents/deep-reasoner.md
ln -sfn ~/.claude/fable/agents/runner.md        ~/.claude/agents/runner.md
```

> 모델 ID는 Claude Code에서 `/model`로 확인하고 다르면 바꾸세요.

### 2-3. 셸 연결 (`~/.zshrc`)

```bash
echo '[ -f "$HOME/.claude/fable/env.sh" ] && source "$HOME/.claude/fable/env.sh"' >> ~/.zshrc
source ~/.zshrc
```

bash를 쓰면 `~/.bash_profile`에 같은 줄을 넣습니다.

### 2-4. `CLAUDE.md` import

```bash
echo '@~/.claude/fable/active.md' >> ~/.claude/CLAUDE.md
```

### 2-5. `settings.json` 훅 등록

`~/.claude/settings.json`을 열어 `hooks`에 병합합니다. 파일이 없으면 아래 내용 그대로 만들면 됩니다.

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit|NotebookEdit|Bash",
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.claude/fable/hooks/orchestration-gate.py\"",
            "timeout": 10
          }
        ]
      }
    ]
  }
}
```

`jq`가 있으면 기존 설정을 보존한 채 자동 병합할 수 있습니다.

```bash
brew install jq   # 없을 때만
f=~/.claude/settings.json; [ -f "$f" ] || echo '{}' > "$f"
jq '.hooks.PreToolUse = ((.hooks.PreToolUse // []) | map(select(tostring | contains("orchestration-gate") | not))) + [{"matcher":"Write|Edit|MultiEdit|NotebookEdit|Bash","hooks":[{"type":"command","command":"python3 \"$HOME/.claude/fable/hooks/orchestration-gate.py\"","timeout":10}]}]' \
  "$f" > "$f.tmp" && mv "$f.tmp" "$f"
```

다시 실행해도 훅이 중복 등록되지 않습니다(기존 `orchestration-gate` 항목을 지우고 다시 넣음).

### 2-6. 확인

```bash
fable status
```

모든 항목이 `[ok]`이면 설치 완료입니다.

---

## 3. macOS에서 주의할 점

### 3-1. Dock·Spotlight로 실행한 앱에는 래퍼가 적용되지 않음

`~/.zshrc`의 `claude` 래퍼(Sonnet → Opus 5.5 재매핑)는 **터미널에서 실행한 `claude`** 에만 적용됩니다. 아래 경우에는 적용되지 않습니다.

- Dock이나 Spotlight로 실행한 VS Code·JetBrains의 Claude Code 확장
- Claude 데스크톱 앱의 Code 탭

게이트(훅)와 지시문(`CLAUDE.md`)은 어느 경로에서든 동작합니다. 영향을 받는 것은 **모델 전환 하나뿐**입니다. 해결 방법은 둘 중 하나를 고르세요.

- **간단:** 터미널에서 `code .` 또는 `idea .`로 IDE를 실행합니다. 셸 환경을 물려받습니다.
- **항상 적용 (권장):** `fable global on`을 실행합니다. `~/.claude/settings.json`의 `env`에 아래가 기록되어 IDE·앱에도 적용됩니다. `fable global off`로 되돌립니다. 이 경우 `fable off`여도 서브에이전트 모델은 유지됩니다.

```json
{
  "env": {
    "CLAUDE_CODE_SUBAGENT_MODEL": "claude-opus-5-5",
    "ANTHROPIC_DEFAULT_SONNET_MODEL": "claude-opus-5-5"
  }
}
```

### 3-2. 대소문자 구분 없는 파일 시스템

macOS 기본 파일 시스템(APFS)은 대소문자를 구분하지 않습니다. 게이트는 macOS에서 `App.py`와 `app.py`를 같은 파일로 취급해 턴 한도에 중복으로 세지 않습니다.

### 3-3. `alias claude`가 이미 있는 경우

`~/.zshrc`에 `alias claude=...`가 있으면 zsh가 함수 정의에서 오류를 냅니다. 별칭을 지우거나 `env.sh`를 source하는 줄보다 앞에 `unalias claude 2>/dev/null`을 넣으세요.

---

## 4. 일상 운영

```bash
fable on        # 지휘자 모드 (다음 세션부터)
fable off       # 기본 모드 (다음 세션부터)
fable status    # 설치·상태·버전·로그 요약
fable log 30    # 최근 차단/경고/오류 30줄

fable global on          # IDE·앱 포함 전체에 서브에이전트 모델 적용 (~/.claude/settings.json)
fable global off
fable project off        # 현재 프로젝트에서만 게이트 끄기 (./.claude/settings.json)
fable project off --local   # settings.local.json 에 기록 (git 미커밋)
fable project on
```

세 스위치의 적용 범위 차이는 공통 가이드의 "스위치 세 가지" 절을 참고하세요.

`fable on` 후 새 세션에서 `/model`로 **Fable 5.1**을 고르고 effort를 **medium**으로 둡니다.

---

## 5. 동작 검증

`fable on` 후 새 세션에서 요청해 보세요.

| # | 요청 | 기대 결과 |
|---|---|---|
| 1 | "a.py, b.py에 주석 한 줄씩 추가" | 허용 |
| 2 | (새 요청 하나로) "a.py, b.py, c.py에 주석 한 줄씩 추가" | 3번째 파일 차단 → 위임 안내 |
| 3 | "README.md 수정" | 허용 |
| 4 | 50줄 넘는 기존 .py 전체 재작성 유도 | `Write` 차단 → Edit 안내 |
| 5 | "sed -i로 a.py 수정" | 차단 |
| 6 | "npm test 2>&1 \| tail" | 허용 |

> 턴 한도는 **사용자 메시지 하나** 기준입니다. 1번 뒤에 "c.py도"라고 새로 보내면 새 턴이라 허용되므로, 2번은 한 메시지로 요청하세요.

훅만 따로 시험하려면:

```bash
echo on > ~/.claude/.fable-state
T="$HOME/fable-gate-test.py"      # /tmp 아래는 면제 경로라 시험에 쓸 수 없음
seq 1 100 > "$T"
printf '{"tool_name":"Write","tool_input":{"file_path":"%s"}}' "$T" \
  | python3 ~/.claude/fable/hooks/orchestration-gate.py
# → "permissionDecision": "deny" 가 출력되면 정상
rm "$T"
fable off   # 시험 후 원래 상태로
```

---

## 6. 제거

```bash
fable off
# 1) ~/.claude/CLAUDE.md 에서 '@~/.claude/fable/active.md' 줄 삭제
# 2) ~/.claude/settings.json 에서 orchestration-gate.py 훅 항목 삭제
rm ~/.claude/agents/deep-reasoner.md ~/.claude/agents/runner.md
# 3) ~/.zshrc 에서 'source "$HOME/.claude/fable/env.sh"' 줄 삭제
rm -rf ~/.claude/fable ~/.claude/.fable-state
```

`fable global on`을 썼다면 그 전에 `fable global off`로 `settings.json`의 `env`를 정리하세요.

---

## 7. 문제 해결

| 증상 | 원인 | 조치 |
|---|---|---|
| 차단이 전혀 안 됨 | 상태 off / 훅 미등록 / python3 없음 | `fable status`, `fable log` 확인 |
| `gate.log`에 `WARN prompt_id 없음` | Claude Code 2.1.196 미만 | `claude update` |
| `gate.log`에 `ERROR` | 훅 입력 파싱 실패 등 | 로그 메시지 확인 후 이슈 공유 |
| 서브에이전트가 Opus 4.x/Sonnet으로 돎 | 래퍼 미적용 경로로 실행 | 3-1절 참고 |
| `fable: command not found` | `~/.zshrc` 미반영 | `source ~/.zshrc` 또는 새 터미널 |

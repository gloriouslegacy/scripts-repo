// replay-theater: records each Edit/Write of a main-thread turn and, when the turn ends, offers
// "▶ Replay: 5 edits (r)" above the prompt; the pane (also /replay) steps through them one diff
// at a time: n next, p previous, c or Esc close. Calls are always passed on with next(e).
import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type { Replay, Step } from '../types'
import { counts, creation, lineCount, normalise, render } from './diff'
import type { RawHunk } from './diff'

const PANE = 'replay-theater'
const MAX_LINES = 12
const KEEP_LINES = 400

const replay = atom({ plugin: 'replay-theater', key: 'replay' } as const, { steps: [], pos: 0, isOpen: false } as Replay)

const shortPath = (path: string): string => {
  const parts = path.split(/[\\/]/).filter(Boolean)
  return parts.length <= 3 ? path : `.../${parts.slice(-3).join('/')}`
}

const makeStep = (path: string, tool: Step['tool'], isNew: boolean, raw: RawHunk[]): Step => {
  const { added, removed } = counts(raw)
  return { path, tool, isNew, added, removed, hunks: normalise(raw, KEEP_LINES).hunks }
}

async function openReplay($: EngineInterface): Promise<void> {
  await update($, replay, r => ({ ...r, pos: 0, isOpen: true }))
  await $.ui.open({ id: PANE, title: 'Replay', focus: true, closeOnEscape: true })
}

async function closeReplay($: EngineInterface): Promise<void> {
  // our own close does not pass through our ui.close hook, so mark it here too
  await update($, replay, r => ({ ...r, isOpen: false }))
  await $.ui.close({ id: PANE })
}

export const register: Register = on => {
  // The turn being recorded; replaced at each main-thread turn's start.
  let recording: Step[] = []

  on('session.start', async ($, e, next) => {
    const result = await next(e)
    await $.command.register({ name: 'replay', description: "Step through the last turn's file edits" })
    return result
  })

  on('command.run', { command: 'replay' }, async $ => {
    const r = await read($, replay)
    if (r.steps.length === 0) return { text: 'No edits to replay yet.' }
    await openReplay($)
    return { text: `Replaying ${r.steps.length} edit${r.steps.length === 1 ? '' : 's'}.` }
  })

  on('turn.start', async ($, e, next) => {
    recording = []
    return next(e)
  })

  on('tool.call', { tool: 'Edit' }, async ($, e, next) => {
    const ran = await next(e)
    if (ran.deny === undefined && !ran.isError && ran.result && !ran.result.staged) {
      recording.push(makeStep(e.file_path, 'Edit', false, ran.result.structuredPatch))
    }
    return ran
  })

  on('tool.call', { tool: 'Write' }, async ($, e, next) => {
    const ran = await next(e)
    if (ran.deny === undefined && !ran.isError && ran.result && !ran.result.staged) {
      const isNew = ran.result.type === 'create'
      const patch: RawHunk[] = ran.result.structuredPatch
      const raw = isNew && patch.length === 0 ? creation(e.content) : patch
      if (raw.length > 0) recording.push(makeStep(e.file_path, 'Write', isNew, raw))
    }
    return ran
  })

  on('turn.complete', async ($, e, next) => {
    const result = await next(e)
    if (e.agentId === undefined && recording.length > 0) {
      const steps = recording
      recording = []
      await update($, replay, r => ({ ...r, steps, pos: 0 }))
    }
    return result
  })

  on('ui.close', { id: PANE }, async ($, e, next) => {
    await update($, replay, r => ({ ...r, isOpen: false }))
    return next(e)
  })

  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    const r = await read($, replay)
    if (e.props.hasSurvey || e.props.isWorking || r.isOpen || r.steps.length === 0) return next(e)
    const { Box, Button, Text } = $.ui.resolve(e)
    return (
      <Box flexDirection="row" gap={1}>
        <Text color="cyan">▶ Replay: {r.steps.length} edit{r.steps.length === 1 ? '' : 's'}</Text>
        <Button key="replay" hotkey="r" label="Replay (r)" onPress={() => void openReplay($)} />
      </Box>
    )
  })

  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    const { Box, Button, Code, Text } = $.ui.resolve(e)
    const r = await read($, replay)
    const count = r.steps.length
    const at = Math.min(Math.max(r.pos, 0), Math.max(count - 1, 0))
    const step = r.steps[at]
    if (!step) return <Text dimColor>No edits to replay.</Text>
    const diff = render(step.hunks, MAX_LINES)
    const more = lineCount(step.hunks) - diff.shown
    const dots = r.steps.map((_, i) => (i === at ? '◉' : i < at ? '●' : '○')).join(' ')
    const go = (pos: number) => update($, replay, old => ({ ...old, pos: Math.min(Math.max(pos, 0), count - 1) }))
    return (
      <Box flexDirection="column" gap={1}>
        <Box flexDirection="column">
          <Text bold>
            Step {at + 1} / {count} · {step.tool}
            {step.isNew ? ' (new file)' : ''}
          </Text>
          <Text wrap="truncate-start">📄 {shortPath(step.path)}</Text>
          <Box flexDirection="row">
            <Text color="green">+{step.added}</Text>
            <Text> </Text>
            <Text color="red">-{step.removed}</Text>
            <Text dimColor>  {dots}</Text>
          </Box>
        </Box>
        {diff.source === '' ? <Text dimColor>(no diff to show)</Text> : <Code source={diff.source} format="diff" path={step.path} wrap="truncate-end" />}
        {more > 0 ? <Text dimColor>… {more} more line{more === 1 ? '' : 's'} in this edit</Text> : null}
        <Box flexDirection="row" gap={1}>
          <Button key="prev" hotkey="p" label="◀ Prev (p)" onPress={() => go(at - 1)} />
          <Button key="next" hotkey="n" label="Next ▶ (n)" variant="primary" onPress={() => go(at + 1)} />
          <Button key="close" hotkey="c" label="Close (c)" role="dismiss" onPress={() => void closeReplay($)} />
        </Box>
      </Box>
    )
  })
}

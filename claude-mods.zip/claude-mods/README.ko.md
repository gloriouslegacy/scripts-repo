# my-mods (한국어 안내)

Claude Code 모드(함수 훅 플러그인) 4개입니다. **Claude Code 2.1.287 이상**이 필요합니다. 화면에 표시되는 문구는 모두 영어입니다.

---

## 1. 설명

### tcw (token-cache-weather) — 프롬프트 아래 상태줄

Claude Code가 상태줄 앞에 플러그인 이름을 붙이기 때문에(`⚠ tcw: …`) 플러그인 이름을 짧게 `tcw`로 했습니다. 폴더 이름은 그대로 `token-cache-weather`입니다.

```
Opus 5.5 · ☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k · ⎇ main ↑2 ~3 · 🧊 cache 58m · 5h 35% left (57m) · week 54% left (2d 11h) · $15.50
```

| 항목 | 뜻 |
|---|---|
| `Opus 5.5` | 현재 모델(1M 컨텍스트 버전은 `(1M)`), `/model`로 바꾸면 따라 바뀜 |
| `☂ Showers 67%` | 컨텍스트 사용률을 날씨로 표시: ☀ Clear(25% 미만) · ☁ Cloudy(25–49%) · ☂ Showers(50–74%) · ☇ Storm(75–89%) · ↯ Compact soon(90% 이상) |
| `134.4k/200k` | 사용 토큰 / 전체 창 크기 |
| `▁▃█` | 최근 12턴의 컨텍스트 크기 그래프(표시된 턴 중 가장 큰 턴이 █) |
| `▲ +98.3k` | 마지막 턴에서 늘어난 양(압축 등으로 줄면 ▼) |
| `⎇ main ↑2 ~3` | 작업 폴더의 git 상태: 브랜치(분리된 HEAD는 `@1a2b3c4`), `↑` 푸시할 커밋, `↓` 받아올 커밋, `+` 스테이징됨, `~` 수정됨, `?` 추적 안 됨, `!` 충돌. 깨끗하면 `✓`. 저장소가 아니면 생략 |
| `🧊 cache 58m` | 마지막 응답 이후 프롬프트 캐시 남은 시간(1분 미만은 `45s`, 만료 후 `🔥 cache expired`, 첫 응답 전 `cache idle`) |
| `5h 35% left (57m)` · `week 54% left (2d 11h)` | 5시간·주간 사용 한도의 남은 비율과 리셋까지 남은 시간(구독 계정만 표시, API 키 사용 시 생략) |
| `$15.50` | 세션 누적 비용 |

15초마다, 그리고 응답이 올 때마다 갱신합니다. 캐시 만료 5분 전(5분짜리 캐시는 1분 전)에 알림을 한 번 띄웁니다. 엔진이 이미 가진 수치만 읽으므로 **토큰을 쓰지 않습니다**.

### change-tutor — 변경 학습 노트(Change Notes) 패널

Claude가 파일을 만들거나 고칠 때(Edit / Write)마다 노트가 하나씩 쌓입니다. 노트에는 파일과 `+추가 -삭제 · 시각`, **🙋 Request**(그 턴의 요청), **🤔 Why it changed**(변경 직전에 Claude가 한 말), diff가 담깁니다. 노트마다 **💡 Explain simply**(쉬운 설명)과 4지선다 **❓ Quiz**를 요청할 수 있습니다. 노트는 세션이 바뀌어도 남고, 최근 100건까지 보관합니다. 상태줄에 `📘 N change notes`가 표시됩니다.

### blast-radius — 위험한 셸 명령 안전장치

위험한 Bash 명령이 실행되기 전에 무엇이 바뀌는지 미리 계산해 패널에 보여줍니다. 터미널이 좁으면 프롬프트 위 줄에 보여줍니다. 그다음 **Cancel / Proceed**를 묻습니다.

| 명령 | 보여주는 것 |
|---|---|
| `rm -r`, `rm -f`, `rm -rf` | 지워질 파일 목록, 개수, 전체 크기 |
| `git reset --hard` | 사라질 커밋 안 된 변경 |
| `git checkout -- <경로>`, `git restore <경로>` | 버려질 스테이징 안 된 변경 |
| `git clean -f…` | 지워질 추적 안 된 경로(`git clean -n` 결과) |
| `git push --force` / `-f` / `--force-with-lease` / `+ref` | 원격에만 있어서 사라질 커밋 |
| `manage.py migrate`, `rails/rake db:migrate`, `alembic upgrade`, `prisma migrate deploy/dev/reset` 등 | 적용될 마이그레이션 |

미리보기에는 읽기 전용 명령만 씁니다(`find`, `du`, `git diff/status/log`, `git clean -n`, 마이그레이션 상태 조회). `cd`, `pushd`, `popd`, `git -C`로 바뀌는 위치도 따라갑니다.

### replay-theater — 마지막 턴의 수정을 한 단계씩 다시 보기

파일을 고친 턴이 끝나면 프롬프트 위에 `▶ Replay: N edits`가 나타납니다. Replay 패널에서 수정 하나씩 볼 수 있습니다. 단계, 도구, 파일, `+/-` 개수, 진행 점, 최대 12줄 diff가 표시됩니다.

---

## 2. 설치

압축을 계속 둘 폴더(예: `C:\Users\<이름>\claude-mods`, `~/claude-mods`)에 풀고, 그 폴더에서 실행합니다.

```bash
claude plugin marketplace add ./
claude plugin install tcw@my-mods --scope user
claude plugin install change-tutor@my-mods --scope user
claude plugin install blast-radius@my-mods --scope user
claude plugin install replay-theater@my-mods --scope user
```

- `--scope user`로 설치하면 모든 프로젝트, 터미널, 데스크톱 앱 Code 탭에서 로드됩니다. 필요한 것만 설치해도 됩니다.
- 설치할 때 "option not yet set" 안내가 나와도 기본값으로 동작합니다. 처음부터 지정하려면 `--config ttl=1h` / `--config model=haiku`를 붙이세요.
- 플러그인은 이 폴더에서 바로 읽힙니다. **폴더를 옮기거나 지우지 마세요.** 파일을 고친 뒤에는 `/reload-plugins`를 실행하면 반영됩니다.

다른 로드 방법:

```bash
# 이번 한 세션만
claude --plugin-dir ./token-cache-weather --plugin-dir ./change-tutor --plugin-dir ./blast-radius --plugin-dir ./replay-theater
```

```json
// ~/.claude/settings.json — 항상 로드(절대 경로, Windows는 ";", macOS·Linux는 ":"로 구분)
{ "env": { "CLAUDE_CODE_PLUGIN_DIRS": "C:\\Users\\<이름>\\claude-mods\\token-cache-weather;C:\\Users\\<이름>\\claude-mods\\blast-radius" } }
```

제거: `claude plugin uninstall <이름>@my-mods`
blast-radius는 PATH에 `bash`, `git`, `find`, `du`가 있어야 합니다. Windows는 Git Bash에 모두 들어 있습니다.

---

## 3. 사용법

### tcw (token-cache-weather)

할 일이 없습니다. 세션을 시작하면 프롬프트 아래에 자동으로 표시됩니다.

| 설정(`/config`) | 값 | 기본값 |
|---|---|---|
| `tcw.model` | `true`, `false` — 맨 앞 모델 이름 표시 여부 | `true` |
| `tcw.weather` | `true`, `false` — 날씨 부분(`☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k`) 표시 여부. `false`면 모델·git·캐시·한도·비용만 남음 | `true` |
| `tcw.ttl` | `1h`, `5m` — 사용 중인 프롬프트 캐시 유지 시간에 맞추세요 | `1h` |
| `tcw.git` | `true`, `false` — git 상태 표시 여부(갱신마다 `git status` 실행, 토큰 없음) | `true` |

남은 시간은 보여주기만 하고 요청을 보내지 않습니다. 그래서 캐시를 연장하지 않습니다. 캐시를 유지하려면 대화를 이어가세요.

### change-tutor

- 세션에서 첫 변경이 생기면 패널이 자동으로 열립니다. 언제든 **`/change-tutor`**로 열 수 있습니다.
- 단축키는 패널에 포커스가 있을 때 동작합니다(패널 클릭 또는 `ctrl+x tab`).

| 키 | 동작 |
|---|---|
| `h` / `l` | 이전 / 다음 노트 |
| `e` | 💡 Explain simply(쉬운 설명) |
| `q` | ❓ Quiz(이어서 `1`–`4`로 답 선택) |
| `v` | ⤢ Show all / ⤡ Collapse(diff 펼치기/접기) |
| `c` | Copy diff(diff 복사) |

- **This session** / **All notes** 탭과 **Latest**는 버튼으로 누릅니다.
- Explain과 Quiz는 누를 때만 모델을 호출합니다. 그때 토큰이 듭니다.

| 설정(`/config`) | 값 | 기본값 |
|---|---|---|
| `change-tutor.model` | `haiku`, `sonnet`, `opus` | `haiku` |

### blast-radius

설정할 것이 없습니다. Claude가 위험한 명령을 실행하려 하면 다음 순서로 진행됩니다.

1. **Blast radius** 패널에 보고서가 나옵니다. 터미널이 좁으면 프롬프트 위 줄에 나옵니다.
2. `Risky command … Run it?` 대화상자에서 **1 Cancel**(첫 번째, 안전한 기본값) 또는 **2 Proceed**를 고릅니다.
3. Cancel, Esc, 대화상자 닫기는 모두 거절로 처리됩니다. Claude에게는 다시 시도하지 말고 사용자에게 물어보라고 전달됩니다.

미리보기 계산 자체가 실패하면 명령을 실행하지 않고 막아 둡니다. 안전장치일 뿐 권한 시스템은 아닙니다. `$(...)`, alias, `eval`, 스크립트 내부, `cd -`는 따라가지 못합니다.

### replay-theater

- 파일을 고친 턴이 끝나면 프롬프트 위 **Replay (r)** 버튼을 누르세요. `ctrl+x tab`으로 그 줄에 포커스를 준 뒤 `r`을 눌러도 되고, **`/replay`**로 열어도 됩니다.
- 패널에서 `n` 다음 · `p` 이전 · `c` 또는 `Esc` 닫기
- 수정이 있었던 마지막 턴 하나만 이번 세션 동안 보관합니다. 단계마다 diff는 최대 12줄까지 보여줍니다.

---

## 확인

```bash
claude plugin validate ./<모드>
claude plugin test ./<모드>
```

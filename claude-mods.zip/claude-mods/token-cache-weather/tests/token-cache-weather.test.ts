import { expect, mock, test } from 'claude-code/testing'

import { cachePart } from '../hooks/cache'
import { modelName } from '../hooks/model'
import { gitPart, parseGit } from '../hooks/git'
import { delta, fmt, forecast, limitParts, span, sparkline, statusLine } from '../hooks/weather'

const MIN = 60_000

test('forecast tiers', () => {
  expect(forecast(24).word).toBe('Clear')
  expect(forecast(25).word).toBe('Cloudy')
  expect(forecast(50).word).toBe('Showers')
  expect(forecast(75).word).toBe('Storm')
  expect(forecast(89).word).toBe('Storm')
  expect(forecast(90).word).toBe('Compact soon')
})

test('pieces of the line', () => {
  expect(fmt(134_400)).toBe('134.4k')
  expect(fmt(200_000)).toBe('200k')
  expect(sparkline([0, 36_100, 134_400])).toBe('▁▃█')
  expect(sparkline(Array.from({ length: 20 }, () => 1)).length).toBe(12)
  expect(delta([36_100, 134_400])).toBe('▲ +98.3k')
  expect(delta([134_400, 20_000])).toBe('▼ −114.4k')
  expect(cachePart(null, '1h', 0)).toBe('🧊 cache idle')
  expect(cachePart(0, '1h', 2 * MIN)).toBe('🧊 cache 58m')
  expect(cachePart(0, '5m', 4 * MIN + 15_000)).toBe('🧊 cache 45s')
  expect(cachePart(0, '5m', 5 * MIN)).toBe('🔥 cache expired')
  expect(
    statusLine({ tokens: 134_400, window: 200_000, turns: [0, 36_100, 134_400], cache: '🧊 cache 58m', usd: 15.5 }),
  ).toBe('☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k · 🧊 cache 58m · $15.50')
})

test('rate-limit windows', () => {
  const now = Date.parse('2026-10-04T00:00:00Z')
  expect(span(57 * MIN)).toBe('57m')
  expect(span((2 * 24 + 11) * 60 * MIN)).toBe('2d 11h')
  expect(span(90 * MIN)).toBe('1h 30m')
  expect(
    limitParts(
      [
        { kind: 'five_hour', percentUsed: 65, resetsAt: new Date(now + 57 * MIN).toISOString() },
        { kind: 'seven_day', percentUsed: 46, resetsAt: new Date(now + (2 * 24 + 11) * 60 * MIN).toISOString() },
      ],
      now,
    ),
  ).toEqual(['5h 35% left (57m)', 'week 54% left (2d 11h)'])
  expect(limitParts([{ kind: 'spend_limit', percentUsed: 80 }], now)).toEqual(['spend 20% left'])
  expect(
    statusLine({ tokens: 102_000, window: 200_000, turns: [], cache: '🧊 cache 58m', limits: ['5h 35% left (57m)', 'week 54% left (2d 11h)'], usd: 3 }),
  ).toBe('☂ Showers 51% · 102k/200k · 🧊 cache 58m · 5h 35% left (57m) · week 54% left (2d 11h) · $3.00')
})

test('one line: chart per turn, countdown per response and every 15 s, one warning', async ($, on) => {
  const clock = mock.clock(on, { now: 1_000_000 })
  const shown: (string | undefined)[] = []
  const toasts: string[] = []
  let tokens: number | undefined
  on('session.usage', () => ({
    value: { startedAt: 0, rateLimits: [{ kind: 'five_hour', percentUsed: 65, resetsAt: new Date(1_000_000 + 300 * MIN).toISOString() }], context: { tokens, window: 200_000 }, cost: { usd: 15.5 } },
  }))
  on('ui.status', (_$, e) => {
    shown.push(e.text)
    return { value: undefined }
  })
  on('ui.toast', (_$, e) => {
    toasts.push(e.text)
    return { value: undefined }
  })
  on('session.start', () => ({ cwd: '/' }))
  on('turn.complete', () => ({ text: '' }))
  on('turn.step', async function* (_$, e) {
    return { turnId: e.turnId, index: e.index, answer: '', toolUses: [], stopReason: 'end_turn', usage: { input_tokens: 1, output_tokens: 1, cache_read_input_tokens: 0, cache_creation_input_tokens: 0, model: 'm' } }
  })
  const turn = { answer: 'ok', durationMs: 1, isAborted: false, turnId: 't', reason: 'answer' as const }
  const step = async () => {
    for await (const _ of $.turn.step({ turnId: 't', index: 0, model: 'm', messageCount: 1 })) {
      // drain
    }
  }

  await $.session.start({ cwd: '/', surface: 'terminal', isInteractive: true })
  expect(shown.at(-1)).toBe('☀ Clear 0% · 0/200k · ▁ · 🧊 cache idle · 5h 35% left (5h) · $15.50')

  tokens = 36_100
  await step()
  expect(shown.at(-1)).toBe('☀ Clear 18% · 36.1k/200k · ▁ · 🧊 cache 60m · 5h 35% left (5h) · $15.50')
  await $.turn.complete(turn)

  tokens = 134_400
  await step()
  await $.turn.complete(turn)
  expect(shown.at(-1)).toBe('☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k · 🧊 cache 60m · 5h 35% left (5h) · $15.50')

  await clock.advance(56 * MIN)
  expect(shown.at(-1)).toBe('☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k · 🧊 cache 4m · 5h 35% left (4h 4m) · $15.50')
  expect(toasts.length).toBe(1)

  await clock.advance(5 * MIN)
  expect(shown.at(-1)).toBe('☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k · 🔥 cache expired · 5h 35% left (3h 59m) · $15.50')
  expect(toasts.length).toBe(1)

  // a reload fires session.start again: no extra chart bar
  await $.session.start({ cwd: '/', surface: 'terminal', isInteractive: true })
  expect(shown.at(-1)).toContain('▁▃█ ▲ +98.3k')
})

const PORCELAIN = [
  '# branch.oid 1a2b3c4d5e6f',
  '# branch.head main',
  '# branch.upstream origin/main',
  '# branch.ab +2 -1',
  '1 M. N... 100644 100644 100644 a b src/a.ts',
  '1 .M N... 100644 100644 100644 a b src/b.ts',
  '1 MM N... 100644 100644 100644 a b src/c.ts',
  'u UU N... 1 2 3 4 a b c src/d.ts',
  '? notes.txt',
  '',
].join('\n')

test('git status part', () => {
  const s = parseGit(PORCELAIN)
  expect(s).toEqual({ branch: 'main', ahead: 2, behind: 1, staged: 2, modified: 2, untracked: 1, conflicts: 1 })
  expect(s && gitPart(s)).toBe('⎇ main ↑2 ↓1 +2 ~2 ?1 !1')
  const clean = parseGit('# branch.oid abc\n# branch.head dev\n')
  expect(clean && gitPart(clean)).toBe('⎇ dev ✓')
  const detached = parseGit('# branch.oid 1a2b3c4d5e6f\n# branch.head (detached)\n')
  expect(detached && gitPart(detached)).toBe('⎇ @1a2b3c4 ✓')
  expect(parseGit('')).toBe(null)
})

for (const git of [true, false]) {
  test(`git part is ${git ? 'shown' : 'left out when turned off'}`, { options: { git } }, async ($, on) => {
    mock.clock(on, { now: 0 })
    const shown: (string | undefined)[] = []
    on('session.usage', () => ({ value: { startedAt: 0, rateLimits: [], context: { tokens: 102_000, window: 200_000 } } }))
    on('session.cwd', () => ({ value: '/p' }))
    on('process.run', () => ({ value: { exitCode: 0, stdout: PORCELAIN, stderr: '', isStdoutTruncated: false, isStderrTruncated: false } }))
    on('ui.status', (_$, e) => {
      shown.push(e.text)
      return { value: undefined }
    })
    on('session.start', () => ({ cwd: '/p' }))
    await $.session.start({ cwd: '/p', surface: 'terminal', isInteractive: true })
    expect(shown.at(-1)).toBe(
      git ? '☂ Showers 51% · 102k/200k · █ · ⎇ main ↑2 ↓1 +2 ~2 ?1 !1 · 🧊 cache idle' : '☂ Showers 51% · 102k/200k · █ · 🧊 cache idle',
    )
  })
}

test('weather part can be turned off on its own', { options: { weather: false, git: true } }, async ($, on) => {
  mock.clock(on, { now: 0 })
  const shown: (string | undefined)[] = []
  on('session.usage', () => ({ value: { startedAt: 0, rateLimits: [], context: { tokens: 102_000, window: 200_000 }, cost: { usd: 1.5 } } }))
  on('session.cwd', () => ({ value: '/p' }))
  on('process.run', () => ({ value: { exitCode: 0, stdout: '# branch.oid abc\n# branch.head main\n', stderr: '', isStdoutTruncated: false, isStderrTruncated: false } }))
  on('ui.status', (_$, e) => {
    shown.push(e.text)
    return { value: undefined }
  })
  on('session.start', () => ({ cwd: '/p' }))
  await $.session.start({ cwd: '/p', surface: 'terminal', isInteractive: true })
  expect(shown.at(-1)).toBe('⎇ main ✓ · 🧊 cache idle · $1.50')
  expect(statusLine({ weather: false, tokens: 1, window: 2, turns: [1], cache: '🧊 cache 1m' })).toBe('🧊 cache 1m')
})

test('model names', () => {
  expect(modelName('claude-opus-5-5')).toBe('Opus 5.5')
  expect(modelName('claude-sonnet-4-5-20250929')).toBe('Sonnet 4.5')
  expect(modelName('claude-opus-4-6[1m]')).toBe('Opus 4.6 (1M)')
  expect(modelName('claude-3-5-haiku-20241022')).toBe('Haiku 3.5')
  expect(modelName('us.anthropic.claude-sonnet-4-20250514-v1:0')).toBe('Sonnet 4')
  expect(modelName('Opus 5.5')).toBe('Opus 5.5')
})

for (const model of [true, false]) {
  test(`model is ${model ? 'first' : 'left out'}`, { options: { model, git: false } }, async ($, on) => {
    mock.clock(on, { now: 0 })
    const shown: (string | undefined)[] = []
    on('session.usage', () => ({ value: { startedAt: 0, rateLimits: [], context: { tokens: 102_000, window: 200_000 } } }))
    on('session.model', () => ({ value: 'claude-opus-5-5' }))
    on('ui.status', (_$, e) => {
      shown.push(e.text)
      return { value: undefined }
    })
    on('session.start', () => ({ cwd: '/p' }))
    await $.session.start({ cwd: '/p', surface: 'terminal', isInteractive: true })
    expect(shown.at(-1)).toBe(`${model ? 'Opus 5.5 · ' : ''}☂ Showers 51% · 102k/200k · █ · 🧊 cache idle`)
  })
}

// tcw (token-cache-weather): one status line under the prompt —
//   Opus 5.5 · ☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k · ⎇ main ↑2 ~3 · 🧊 cache 58m · 5h 35% left (57m) · week 54% left (2d 11h) · $15.50
// (the rate-limit windows appear on a subscription; with an API key they are left out)
// Refreshed every 15 s and whenever a main-thread response arrives (turn.step); a reading for the
// 12-turn chart is taken at session start and after each main-thread turn. No model calls: the
// figures are the ones $.session.usage() already holds, which costs nothing.
import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type { CacheClock, Reading } from '../types'
import { cachePart, remainingMs, warnMs } from './cache'
import type { Ttl } from './cache'
import { gitPart, parseGit } from './git'
import { modelName } from './model'
import { BARS, limitParts, statusLine } from './weather'

const history = atom({ plugin: 'tcw', key: 'history' } as const, [] as Reading[])
const clock = atom({ plugin: 'tcw', key: 'clock' } as const, {
  lastAt: null,
  ttl: null,
  warnedFor: null,
} as CacheClock)

const TICK_MS = 15_000

async function gitLine($: EngineInterface): Promise<string | undefined> {
  try {
    const r = await $.process.run(['git', 'status', '--porcelain=v2', '--branch'], { cwd: await $.session.cwd(), timeoutMs: 3000 })
    if (r.exitCode !== 0) return undefined
    const s = parseGit(r.stdout)
    return s ? gitPart(s) : undefined
  } catch {
    return undefined // no git, not a repository, or too slow this time
  }
}

type Show = { model: boolean; weather: boolean; git: boolean }

async function refresh($: EngineInterface, configured: Ttl, show: Show): Promise<void> {
  try {
    const [turns, state, usage, now, git, model] = await Promise.all([
      read($, history),
      read($, clock),
      $.session.usage(),
      $.clock.now(),
      show.git ? gitLine($) : Promise.resolve(undefined),
      show.model ? $.session.model().catch(() => '') : Promise.resolve(''),
    ])
    const ttl = state.ttl ?? configured
    const { context } = usage
    if (context.window <= 0) return
    $.ui.status(
      statusLine({
        model: model ? modelName(model) : undefined,
        weather: show.weather,
        tokens: context.tokens ?? turns[turns.length - 1]?.tokens ?? 0,
        window: context.window,
        percent: context.percent,
        turns: turns.map(r => r.tokens).slice(-BARS - 1),
        cache: cachePart(state.lastAt, ttl, now),
        git,
        limits: limitParts(usage.rateLimits, now),
        usd: usage.cost?.usd,
      }),
    )
    const left = state.lastAt === null ? 0 : remainingMs(state.lastAt, ttl, now)
    if (state.lastAt !== null && left > 0 && left <= warnMs(ttl) && state.warnedFor !== state.lastAt) {
      const at = state.lastAt
      await update($, clock, c => ({ ...c, warnedFor: at }))
      $.ui.toast(`🧊 Prompt cache expires in ${Math.ceil(left / 60_000)} min. Keep working to keep it warm.`)
    }
  } catch {
    // usage unavailable for a moment: keep the last line
  }
}

async function record($: EngineInterface, fallbackTokens: number | null): Promise<void> {
  const { context } = await $.session.usage()
  const tokens = context.tokens ?? fallbackTokens
  if (tokens === null || context.window <= 0) return
  const reading: Reading = { tokens, window: context.window }
  await update($, history, prev => [...(prev ?? []), reading].slice(-(BARS + 1)))
}

export const register: Register = (on, options) => {
  const configured: Ttl = options.ttl === '5m' ? '5m' : '1h'
  const show: Show = { model: options.model !== false, weather: options.weather !== false, git: options.git !== false }

  on('session.start', async ($, e, next) => {
    const result = await next(e)
    try {
      // first reading so the line shows before the first turn; a reload keeps the history
      if ((await read($, history)).length === 0) await record($, 0)
    } catch {
      // usage unavailable at start: the chart starts after the first turn
    }
    $.clock.every(TICK_MS, () => void refresh($, configured, show))
    await refresh($, configured, show)
    return result
  })

  // Resumed or forked: the cache's age is the transcript's last response's.
  on('classic.SessionStart', async ($, e, next) => {
    const result = await next(e)
    if (e.seconds_since_last_response !== undefined) {
      const at = (await $.clock.now()) - e.seconds_since_last_response * 1000
      await update($, clock, c => ({ ...c, lastAt: at }))
      await refresh($, configured, show)
    }
    return result
  })

  // The engine says which TTL the cache runs on when the model switches.
  on('classic.PreModelSwitch', async ($, e, next) => {
    const result = await next(e)
    const ttl = e.cache_ttl
    await update($, clock, c => ({ ...c, ttl }))
    await refresh($, configured, show)
    return result
  })

  // Every main-thread response re-arms the cache and moves the context figure.
  on('turn.step', async function* ($, e, next) {
    const step = yield* next(e)
    if (e.agentId === undefined && step.usage !== null) {
      const at = await $.clock.now()
      await update($, clock, c => ({ ...c, lastAt: at }))
      await refresh($, configured, show)
    }
    return step
  })

  // One chart bar per main-thread turn.
  on('turn.complete', async ($, e, next) => {
    const result = await next(e)
    if (e.agentId !== undefined) return result
    try {
      await record($, null)
    } catch {
      // keep the last chart rather than break the turn
    }
    await refresh($, configured, show)
    return result
  })
}

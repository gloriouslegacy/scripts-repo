/** What one risky command would do, as found before it runs. */
export type Report = {
  /** The Bash call's tool_use_id. */
  id: string
  command: string
  /** Where it would run. */
  cwd: string
  sections: ReportSection[]
}

export type ReportSection = {
  /** "Deletes files", "Discards uncommitted changes", ... */
  title: string
  /** One line: "1,204 files · 38.2 MB". */
  summary: string
  /** Up to 10 detail lines (paths, commits, migrations). */
  lines: string[]
  /** How many detail lines there were in all. */
  total: number
}

declare module 'claude-code' {
  interface PluginState {
    'blast-radius': {
      /** Commands waiting for Proceed or Cancel, oldest first. */
      pending: Report[]
    }
  }
}

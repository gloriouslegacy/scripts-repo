import { expect, test } from 'claude-code/testing'

import { risks, split } from '../hooks/parse'
import { question, size } from '../hooks/report'

test('reads simple commands and follows cd', () => {
  expect(split('cd app && rm -rf "build dir" ; echo ok | cat')).toEqual([['cd', 'app'], ['rm', '-rf', 'build dir'], ['echo', 'ok'], ['cat']])
  expect(risks('cd app && rm -rf build', '/p')).toEqual([{ kind: 'rm', cwd: '/p/app', targets: ['build'] }])
  expect(risks('rm file.txt', '/p')).toEqual([])
  expect(risks('sudo rm -r -- -weird', '/p')).toEqual([{ kind: 'rm', cwd: '/p', targets: ['-weird'] }])
  expect(risks('git -C repo reset --hard HEAD~1', '/p')).toEqual([{ kind: 'reset', cwd: '/p/repo' }])
  expect(risks('git checkout -- .', '/p')[0]?.kind).toBe('discard')
  expect(risks('git restore --staged .', '/p')).toEqual([])
  expect(risks('git clean -fdx', '/p')).toEqual([{ kind: 'clean', cwd: '/p', flags: ['d', 'x'], paths: [] }])
  expect(risks('git clean -n', '/p')).toEqual([])
  expect(risks('git push --force origin main', '/p')).toEqual([{ kind: 'push', cwd: '/p', remote: 'origin', branch: 'main' }])
  expect(risks('git push origin +main', '/p')[0]?.kind).toBe('push')
  expect(risks('git push origin main', '/p')).toEqual([])
  expect(risks('python manage.py migrate', '/p')[0]).toMatchObject({ kind: 'migrate', tool: 'django' })
  expect(risks('npx prisma migrate deploy', '/p')[0]).toMatchObject({ kind: 'migrate', tool: 'prisma' })
  expect(risks('pushd x && rm -rf y && popd && rm -rf z', '/p').map(r => r.cwd)).toEqual(['/p/x', '/p'])
})

test('report text', () => {
  expect(size(39_117)).toBe('38.2 MB')
  expect(
    question({ id: 'b', command: 'rm -rf build', cwd: '/p', sections: [{ title: 'Deletes files', summary: '3 files · 12 KB', lines: [], total: 3 }] }),
  ).toBe('Risky command `rm -rf build` (Deletes files: 3 files · 12 KB). Run it?')
})

const fakeShell = (argv: readonly string[]): string => {
  if (argv[0] === 'bash' && (argv[2] ?? '').includes('compgen')) return 'build\n'
  if (argv[0] === 'bash') return ''
  if (argv[0] === 'find') return 'build/a.js\nbuild/b.js\nbuild/c.map\n'
  if (argv[0] === 'du') return '12\tbuild\n12\ttotal\n'
  return ''
}

for (const answer of ['Proceed', 'Cancel'] as const) {
  test(`rm -rf is held, previewed, and ${answer === 'Proceed' ? 'runs' : 'is refused'} on ${answer}`, async ($, on) => {
    const asked: string[] = []
    let ran = 0
    on('session.cwd', () => ({ value: '/p' }))
    on('process.run', (_$, e) => ({ value: { exitCode: 0, stdout: fakeShell(e.argv), stderr: '', isStdoutTruncated: false, isStderrTruncated: false } }))
    on('ui.open', () => ({ value: { isPlaced: true } }))
    on('ui.close', () => ({ value: undefined }))
    on('ui.panes', () => ({ value: [] }))
    on('ui.render', ($$, e) => {
      const { Box } = $$.ui.resolve(e)
      return <Box key="engine" />
    })
    const drawn: string[] = []
    on('tool.call', { tool: 'AskUserQuestion' }, async (_$, e) => {
      const q = e.questions[0]?.question ?? ''
      asked.push(q)
      for (const surface of ['terminal', 'desktop'] as const) {
        const pane = await $.ui.mount({ plugin: 'blast-radius', surface, component: 'Pane', requestId: 'blast-radius', props: { title: 'Blast radius', isFocused: false, bodyColumns: 80, placement: 'dock', scroll: { offset: 0, bodyRows: 30 }, view: {} } })
        drawn.push((await pane.find({ text: /build\/a\.js/ }))?.text ?? 'missing pane line')
        const band = await $.ui.mount({ plugin: 'blast-radius', surface, component: 'AbovePrompt', props: { hasSurvey: false, isWorking: true, maxRows: 10, bodyColumns: 80, scroll: { offset: 0, bodyRows: 10 }, view: {} } })
        drawn.push((await band.find({ text: /blast-radius: rm -rf build/ }))?.text ?? 'missing band line')
      }
      return { result: { questions: e.questions, answers: { [q]: answer } } }
    })
    on('tool.call', { tool: 'Bash' }, () => {
      ran += 1
      return { result: { stdout: '', stderr: '', interrupted: false } }
    })

    const r = await $.tool.call({ tool: 'Bash', tool_use_id: 'b1', command: 'rm -rf build' })
    expect(asked[0]).toBe('Risky command `rm -rf build` (Deletes files: 3 files · 12 KB). Run it?')
    expect(ran).toBe(answer === 'Proceed' ? 1 : 0)
    if (answer === 'Cancel') expect(r.deny ?? r.text ?? '').toContain('cancelled')
    expect(drawn.filter(d => d.startsWith('missing'))).toEqual([])

    await $.tool.call({ tool: 'Bash', tool_use_id: 'b2', command: 'ls -la' })
    expect(asked.length).toBe(1)
  })
}

// blast-radius: a small shell reader — split a command into simple commands, follow cd/pushd/popd,
// and name the risky ones. Not a full shell parser: $(...), aliases, eval and scripts are not followed.

export type Risk =
  | { kind: 'rm'; cwd: string; targets: string[] }
  | { kind: 'reset'; cwd: string }
  | { kind: 'discard'; cwd: string; paths: string[] }
  | { kind: 'clean'; cwd: string; flags: string[]; paths: string[] }
  | { kind: 'push'; cwd: string; remote: string | null; branch: string | null }
  | { kind: 'migrate'; cwd: string; tool: 'django' | 'rails' | 'alembic' | 'prisma' | 'other'; argv: string[] }

/** Words of each simple command, split on ; && || | and newlines outside quotes. */
export const split = (command: string): string[][] => {
  const out: string[][] = []
  let words: string[] = []
  let word = ''
  let has = false
  let quote: '"' | "'" | null = null
  const endWord = () => {
    if (has) words.push(word)
    word = ''
    has = false
  }
  const endCommand = () => {
    endWord()
    if (words.length > 0) out.push(words)
    words = []
  }
  for (let i = 0; i < command.length; i += 1) {
    const c = command[i] ?? ''
    if (quote) {
      if (c === quote) quote = null
      else if (c === '\\' && quote === '"' && i + 1 < command.length) word += command[++i]
      else word += c
      continue
    }
    if (c === '"' || c === "'") {
      quote = c
      has = true
    } else if (c === '\\' && i + 1 < command.length) {
      word += command[++i]
      has = true
    } else if (c === ' ' || c === '\t') endWord()
    else if (c === ';' || c === '\n' || c === '|' || c === '&') {
      if ((c === '&' || c === '|') && command[i + 1] === c) i += 1
      endCommand()
    } else {
      word += c
      has = true
    }
  }
  endCommand()
  return out
}

const join = (base: string, dir: string): string => {
  if (dir.startsWith('/') || /^[A-Za-z]:[\\/]/.test(dir)) return dir
  if (dir === '~' || dir.startsWith('~/')) return dir
  const parts = base.split('/')
  for (const p of dir.split('/')) {
    if (p === '' || p === '.') continue
    if (p === '..') parts.length > 1 && parts.pop()
    else parts.push(p)
  }
  return parts.join('/') || '/'
}

const ENV = /^[A-Za-z_][A-Za-z0-9_]*=/
const WRAPPERS = new Set(['sudo', 'command', 'nohup', 'time', 'env'])

const strip = (words: string[]): string[] => {
  let i = 0
  while (i < words.length && (ENV.test(words[i] ?? '') || WRAPPERS.has(words[i] ?? ''))) i += 1
  return words.slice(i)
}

const shortFlags = (args: string[]): string => args.filter(a => /^-[A-Za-z]+$/.test(a)).map(a => a.slice(1)).join('')

const gitRisk = (args: string[], cwd: string): Risk | null => {
  let at = cwd
  let rest = [...args]
  while (rest[0] === '-C' && rest[1] !== undefined) {
    at = join(at, rest[1])
    rest = rest.slice(2)
  }
  const [sub, ...tail] = rest
  if (sub === 'reset' && tail.includes('--hard')) return { kind: 'reset', cwd: at }
  if (sub === 'checkout' && tail.includes('--')) {
    const paths = tail.slice(tail.indexOf('--') + 1)
    if (paths.length > 0) return { kind: 'discard', cwd: at, paths }
  }
  if (sub === 'checkout' && tail.length === 1 && tail[0] === '.') return { kind: 'discard', cwd: at, paths: ['.'] }
  if (sub === 'restore' && !tail.includes('--staged') && !tail.includes('-S')) {
    const paths = tail.filter(t => !t.startsWith('-'))
    if (paths.length > 0) return { kind: 'discard', cwd: at, paths }
  }
  if (sub === 'clean') {
    const flags = shortFlags(tail)
    if (flags.includes('f') || tail.includes('--force')) {
      return { kind: 'clean', cwd: at, flags: [...new Set(flags.replace(/[fniqe]/g, '').split('').filter(Boolean))], paths: tail.filter(t => !t.startsWith('-')) }
    }
  }
  if (sub === 'push') {
    const forced = tail.some(t => t === '--force' || t.startsWith('--force-with-lease') || t === '--force-if-includes' || (/^-[A-Za-z]+$/.test(t) && t.includes('f')))
    const positional = tail.filter(t => !t.startsWith('-'))
    const plusRef = positional.some(t => t.startsWith('+'))
    if (forced || plusRef) {
      const ref = positional[1]?.replace(/^\+/, '').split(':').pop() ?? null
      return { kind: 'push', cwd: at, remote: positional[0] ?? null, branch: ref }
    }
  }
  return null
}

const migrateRisk = (words: string[], cwd: string): Risk | null => {
  const line = words.join(' ')
  if (/manage\.py\s+migrate\b/.test(line)) return { kind: 'migrate', cwd, tool: 'django', argv: words }
  if (/\b(rails|rake)\b.*\bdb:migrate\b/.test(line)) return { kind: 'migrate', cwd, tool: 'rails', argv: words }
  if (/\balembic\b.*\bupgrade\b/.test(line)) return { kind: 'migrate', cwd, tool: 'alembic', argv: words }
  if (/\bprisma\s+migrate\s+(deploy|dev|reset)\b/.test(line)) return { kind: 'migrate', cwd, tool: 'prisma', argv: words }
  if (/\b(db:migrate|migrate:latest|migrate:fresh|migrate:reset)\b/.test(line)) return { kind: 'migrate', cwd, tool: 'other', argv: words }
  return null
}

/** Every risky simple command in `command`, each with the directory it would run in. */
export const risks = (command: string, startCwd: string): Risk[] => {
  const found: Risk[] = []
  let cwd = startCwd
  const stack: string[] = []
  for (const raw of split(command)) {
    const words = strip(raw)
    const [name, ...args] = words
    if (name === undefined) continue
    if (name === 'cd') {
      const to = args.find(a => !a.startsWith('-'))
      if (to !== undefined && to !== '-') cwd = join(cwd, to)
      continue
    }
    if (name === 'pushd' && args[0] !== undefined) {
      stack.push(cwd)
      cwd = join(cwd, args[0])
      continue
    }
    if (name === 'popd') {
      cwd = stack.pop() ?? cwd
      continue
    }
    if (name === 'rm') {
      const flags = shortFlags(args)
      const isRisky = /[rRf]/.test(flags) || args.includes('--recursive') || args.includes('--force')
      const dashdash = args.indexOf('--')
      const targets = args.filter((a, i) => (dashdash >= 0 ? i > dashdash : !a.startsWith('-')))
      if (isRisky && targets.length > 0) found.push({ kind: 'rm', cwd, targets })
      continue
    }
    if (name === 'git') {
      const r = gitRisk(args, cwd)
      if (r) found.push(r)
      continue
    }
    const m = migrateRisk(words, cwd)
    if (m) found.push(m)
  }
  return found
}

// blast-radius: holds a risky Bash call (rm -r/-f, git reset --hard, git checkout -- / restore,
// git clean -f, a force push, a migration), works out what it would change with read-only
// commands, shows that in a pane (or the band above the prompt when the pane cannot be placed),
// and asks Cancel / Proceed in the engine's own dialog. Cancel, Esc or a dismissed dialog refuses.
import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type { Report, ReportSection } from '../types'
import { risks } from './parse'
import type { Risk } from './parse'
import { SHOW, commits, deletion, outLines, question, section } from './report'

const PANE = 'blast-radius'
const pending = atom({ plugin: 'blast-radius', key: 'pending' } as const, [] as Report[])

type Ran = { ok: boolean; out: string; err: string }

async function sh($: EngineInterface, argv: string[], cwd: string, timeoutMs = 15_000): Promise<Ran> {
  try {
    const r = await $.process.run(argv, { cwd, timeoutMs })
    return { ok: r.exitCode === 0, out: r.stdout, err: r.stderr }
  } catch (err) {
    return { ok: false, out: '', err: String(err) }
  }
}

async function preview($: EngineInterface, risk: Risk): Promise<ReportSection> {
  const cwd = risk.cwd
  switch (risk.kind) {
    case 'rm': {
      // expand globs without running anything: compgen -G only lists matches
      const expanded = await sh($, ['bash', '-c', 'for p in "$@"; do compgen -G "$p" || printf "%s\\n" "$p"; done', '_', ...risk.targets], cwd)
      const paths = outLines(expanded.out)
      const exists = await sh($, ['bash', '-c', 'for p in "$@"; do [ -e "$p" ] || [ -L "$p" ] || printf "%s\\n" "$p"; done', '_', ...paths], cwd)
      const missing = outLines(exists.out)
      const present = paths.filter(p => !missing.includes(p))
      if (present.length === 0) return deletion([], 0, missing)
      const files = await sh($, ['find', ...present, '-type', 'f'], cwd, 20_000)
      const du = await sh($, ['du', '-sck', ...present], cwd, 20_000)
      const total = /^(\d+)\s+total$/m.exec(du.out)
      return deletion(outLines(files.out), total ? Number(total[1]) : null, missing)
    }
    case 'reset': {
      const stat = await sh($, ['git', 'diff', '--shortstat', 'HEAD'], cwd)
      const status = await sh($, ['git', 'status', '--porcelain'], cwd)
      const changed = outLines(status.out).filter(l => !l.startsWith('??'))
      const summary = stat.ok ? stat.out.trim() || 'no uncommitted changes to tracked files' : `not a git repository? ${stat.err.trim()}`
      return section('Discards uncommitted changes', summary, changed)
    }
    case 'discard': {
      const stat = await sh($, ['git', 'diff', '--shortstat', '--', ...risk.paths], cwd)
      const names = await sh($, ['git', 'diff', '--name-status', '--', ...risk.paths], cwd)
      return section('Discards unstaged changes', stat.out.trim() || 'no unstaged changes there', outLines(names.out))
    }
    case 'clean': {
      const flags = risk.flags.map(f => `-${f}`)
      const dry = await sh($, ['git', 'clean', '-n', ...flags, '--', ...risk.paths], cwd)
      const list = outLines(dry.out).map(l => l.replace(/^Would remove /, ''))
      return section('Removes untracked files', `${list.length} path${list.length === 1 ? '' : 's'}`, list)
    }
    case 'push': {
      let ref = risk.remote && risk.branch ? `${risk.remote}/${risk.branch}` : '@{u}'
      if (risk.remote && !risk.branch) {
        const head = await sh($, ['git', 'rev-parse', '--abbrev-ref', 'HEAD'], cwd)
        if (head.ok) ref = `${risk.remote}/${head.out.trim()}`
      }
      const log = await sh($, ['git', 'log', '--oneline', `HEAD..${ref}`], cwd)
      if (!log.ok) return section('Force push', `could not compare with ${ref} (no remote-tracking branch?)`, [])
      return commits(outLines(log.out), ref)
    }
    case 'migrate': {
      if (risk.tool === 'django') {
        const py = risk.argv[0]?.includes('python') ? risk.argv[0] : 'python'
        const plan = await sh($, [py, 'manage.py', 'showmigrations', '--plan'], cwd, 30_000)
        const todo = outLines(plan.out).filter(l => l.trimStart().startsWith('[ ]')).map(l => l.trim().slice(4))
        return section('Applies migrations', plan.ok ? `${todo.length} pending` : 'could not list pending migrations', todo)
      }
      if (risk.tool === 'rails') {
        const bin = risk.argv[0] ?? 'rails'
        const status = await sh($, [bin, 'db:migrate:status'], cwd, 30_000)
        const todo = outLines(status.out).filter(l => /^\s*down\b/.test(l)).map(l => l.trim())
        return section('Applies migrations', status.ok ? `${todo.length} pending` : 'could not list pending migrations', todo)
      }
      if (risk.tool === 'alembic') {
        const hist = await sh($, ['alembic', 'history', '-r', 'current:heads'], cwd, 30_000)
        const todo = outLines(hist.out).filter(l => !l.includes('(current)'))
        return section('Applies migrations', hist.ok ? `${todo.length} pending` : 'could not list pending migrations', todo)
      }
      if (risk.tool === 'prisma') {
        const st = await sh($, ['npx', 'prisma', 'migrate', 'status'], cwd, 60_000)
        return section('Applies migrations', 'prisma migrate status says:', outLines(st.out + st.err))
      }
      return section('Runs database migrations', 'pending list not available for this tool', [])
    }
  }
}

async function decide($: EngineInterface, report: Report): Promise<boolean> {
  await update($, pending, list => [...list.filter(r => r.id !== report.id), report])
  try {
    await $.ui.open({ id: PANE, title: 'Blast radius' })
  } catch {
    // no pane: the band and the dialog still show it
  }
  try {
    const answer = await $.ui.ask(question(report), { header: 'Blast radius', options: ['Cancel', 'Proceed'] })
    return answer === 'Proceed'
  } catch {
    return false // dismissed, Esc, or no one to ask
  } finally {
    await update($, pending, list => list.filter(r => r.id !== report.id))
    if ((await read($, pending)).length === 0) await $.ui.close({ id: PANE })
  }
}

export const register: Register = on => {
  on('tool.call', { tool: 'Bash' }, async ($, e, next) => {
    const cwd = await $.session.cwd()
    const found = risks(e.command, cwd)
    if (found.length === 0) return next(e)
    const sections: ReportSection[] = []
    for (const risk of found) sections.push(await preview($, risk))
    const report: Report = { id: e.tool_use_id, command: e.command, cwd, sections }
    const isGo = await decide($, report)
    return isGo ? next(e) : { deny: 'blast-radius: the user cancelled this command after seeing what it would change. Do not retry it; ask them how to proceed.' }
  }).catch(() => ({ deny: 'blast-radius: could not check this risky command, so it was held. Ask the user to run it themselves.' }))

  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    const { Box, Text } = $.ui.resolve(e)
    const list = await read($, pending)
    if (list.length === 0) return <Text dimColor>Nothing is held.</Text>
    return (
      <Box flexDirection="column" gap={1}>
        {list.map(r => (
          <Box flexDirection="column">
            <Text bold color="red">⚠ {r.command}</Text>
            <Text dimColor>in {r.cwd}</Text>
            {r.sections.map(s => (
              <Box flexDirection="column" marginTop={1}>
                <Text bold>{s.title}</Text>
                <Text color="yellow">{s.summary}</Text>
                {s.lines.map(l => (
                  <Text wrap="truncate-middle">  {l}</Text>
                ))}
                {s.total > SHOW ? <Text dimColor>  … and {s.total - SHOW} more</Text> : null}
              </Box>
            ))}
            <Text dimColor>Answer in the dialog below: 1 Cancel · 2 Proceed</Text>
          </Box>
        ))}
      </Box>
    )
  })

  // Narrow terminals: no pane is placed, so the report rides the band above the prompt.
  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    const list = await read($, pending)
    if (list.length === 0) return next(e)
    const panes = await $.ui.panes()
    if (panes.some(p => p.id === PANE && p.isPlaced)) return next(e)
    const { Box, Text } = $.ui.resolve(e)
    const r = list[0]
    if (!r) return next(e)
    const below = await next(e) // keep other mods' rows in the band
    return (
      <Box flexDirection="column">
        {below}
        <Text bold color="red">⚠ blast-radius: {r.command}</Text>
        {r.sections.map(s => (
          <Text>
            {s.title}: <Text color="yellow">{s.summary}</Text>
            {s.lines.length > 0 ? ` (${s.lines.slice(0, 3).join(', ')}${s.total > 3 ? ', …' : ''})` : ''}
          </Text>
        ))}
      </Box>
    )
  })
}

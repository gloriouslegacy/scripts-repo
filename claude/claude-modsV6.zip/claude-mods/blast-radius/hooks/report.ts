// blast-radius: pure helpers that turn command output into report sections and the question.
import type { Report, ReportSection } from '../types'

export const SHOW = 10

const n = (x: number): string => x.toLocaleString('en-US')

/** du's kilobytes as "38.2 MB". */
export const size = (kb: number): string => {
  if (kb >= 1024 * 1024) return `${(kb / 1024 / 1024).toFixed(1)} GB`
  if (kb >= 1024) return `${(kb / 1024).toFixed(1)} MB`
  return `${kb} KB`
}

export const outLines = (text: string): string[] => text.split('\n').map(l => l.trimEnd()).filter(l => l.trim() !== '')

export const section = (title: string, summary: string, all: string[]): ReportSection => ({
  title,
  summary,
  lines: all.slice(0, SHOW),
  total: all.length,
})

export const deletion = (files: string[], kb: number | null, missing: string[]): ReportSection => {
  const parts = [`${n(files.length)} file${files.length === 1 ? '' : 's'}`]
  if (kb !== null) parts.push(size(kb))
  if (missing.length > 0) parts.push(`${missing.length} path${missing.length === 1 ? '' : 's'} not found`)
  return section('Deletes files', parts.join(' · '), files)
}

export const commits = (list: string[], ref: string): ReportSection =>
  list.length === 0
    ? section('Force push', `no commits on ${ref} would be dropped`, [])
    : section('Force push', `drops ${n(list.length)} commit${list.length === 1 ? '' : 's'} on ${ref} that you do not have locally`, list)

export const oneLine = (text: string, max: number): string => {
  const flat = text.replace(/\s+/g, ' ').trim()
  return flat.length > max ? `${flat.slice(0, max - 1)}…` : flat
}

/** The dialog's question: the command and each section's one-line summary. */
export const question = (r: Report): string => {
  const what = r.sections.map(s => `${s.title}: ${s.summary}`).join('; ')
  return `Risky command \`${oneLine(r.command, 80)}\` (${what}). Run it?`
}

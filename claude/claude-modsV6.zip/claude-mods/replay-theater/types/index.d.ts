/** One hunk of a unified diff, as the Edit and Write tools report it. */
export type Hunk = { oldStart: number; newStart: number; lines: string[] }

/** One file edit of a turn. */
export type Step = {
  path: string
  tool: 'Edit' | 'Write'
  isNew: boolean
  added: number
  removed: number
  hunks: Hunk[]
}

export type Replay = {
  /** The edits of the last main-thread turn that made any, in order. */
  steps: Step[]
  /** The step shown in the pane. */
  pos: number
  /** True while the pane is open (the band then hides its hint). */
  isOpen: boolean
}

declare module 'claude-code' {
  interface PluginState {
    'replay-theater': { replay: Replay }
  }
}

import { expect, test } from 'claude-code/testing'

const lines = (n: number) => Array.from({ length: n }, (_, i) => `line ${i + 1}`).join('\n') + '\n'

for (const surface of ['terminal', 'desktop'] as const) {
  test(`records a turn's edits and steps through them on ${surface}`, async ($, on) => {
    on('session.start', () => ({ cwd: '/' }))
    on('command.register', (_$, e) => ({ value: { command: e.name } }))
    on('ui.open', () => ({ value: { isPlaced: true } }))
    on('ui.close', () => ({ value: undefined }))
    on('turn.start', (_$, e) => ({ turnId: e.turnId }))
    on('turn.complete', () => ({ text: '' }))
    on('tool.call', { tool: 'Write' }, (_$, e) => ({
      result: { type: 'create', filePath: e.file_path, content: e.content, structuredPatch: [], originalFile: null },
    }))
    on('tool.call', { tool: 'Edit' }, (_$, e) => ({
      result: {
        filePath: e.file_path, oldString: e.old_string, newString: e.new_string, originalFile: 'a\nb\nc\n', userModified: false, replaceAll: false,
        structuredPatch: [{ oldStart: 1, oldLines: 3, newStart: 1, newLines: 3, lines: [' a', '-b', '+B', ' c'] }],
      },
    }))
    on('ui.render', ($$, e) => {
      const { Box } = $$.ui.resolve(e)
      return <Box key="engine" />
    })

    await $.session.start({ cwd: '/', surface, isInteractive: true })
    await $.turn.start({ text: 'go', turnId: 't1' })
    await $.tool.call({ tool: 'Write', tool_use_id: 'w', file_path: '/p/src/app.py', content: lines(20) })
    await $.tool.call({ tool: 'Edit', tool_use_id: 'e', file_path: '/p/src/util.py', old_string: 'b', new_string: 'B' })
    await $.turn.complete({ answer: 'done', durationMs: 1, isAborted: false, turnId: 't1', reason: 'answer' })

    const band = await $.ui.mount({ plugin: 'replay-theater', surface, component: 'AbovePrompt', props: { hasSurvey: false, isWorking: false, maxRows: 10, bodyColumns: 80, scroll: { offset: 0, bodyRows: 10 }, view: {} } })
    expect(await band.find({ text: '▶ Replay: 2 edits' })).toBeDefined()

    const pane = await $.ui.mount({ plugin: 'replay-theater', surface, component: 'Pane', requestId: 'replay-theater', props: { title: 'Replay', isFocused: true, bodyColumns: 80, placement: 'dock', scroll: { offset: 0, bodyRows: 30 }, view: {} } })
    await band.press({ key: 'replay' })
    expect(await pane.find({ text: /Step 1 \/ 2 · Write \(new file\)/ })).toBeDefined()
    expect(await pane.find({ text: '… 8 more lines in this edit' })).toBeDefined()
    expect(await band.find({ text: '▶ Replay: 2 edits' })).toBeUndefined()

    await pane.press({ key: 'next' })
    expect(await pane.find({ text: /Step 2 \/ 2 · Edit/ })).toBeDefined()
    expect(await pane.find({ text: /util\.py/ })).toBeDefined()
    await pane.press({ key: 'next' })
    expect(await pane.find({ text: /Step 2 \/ 2/ })).toBeDefined()
    await pane.press({ key: 'prev' })
    expect(await pane.find({ text: /Step 1 \/ 2/ })).toBeDefined()

    await pane.press({ key: 'close' })
    expect(await band.find({ text: '▶ Replay: 2 edits' })).toBeDefined()
  })
}

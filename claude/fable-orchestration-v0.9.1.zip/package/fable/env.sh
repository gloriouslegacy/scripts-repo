# ~/.claude/fable/env.sh — Fable orchestration switch (macOS zsh / bash · Linux) — Max·Pro (플랜은 설치 때 선택) (V5)
# ~/.zshrc 에서:  [ -f "$HOME/.claude/fable/env.sh" ] && source "$HOME/.claude/fable/env.sh"

FABLE_HOME="$HOME/.claude/fable"
FABLE_STATE="$HOME/.claude/.fable-state"
FABLE_MIN_CC="2.1.271"               # 최소 Claude Code 버전(가이드와 일치)

# 구현 서브에이전트(general-purpose 등)가 쓸 모델: 설치본 plan.env 의 FABLE_EXEC_MODEL, 없으면 claude-opus-5-5.
# plan.env 는 실행(source)하지 않고 파싱만 한다: '^KEY=' 첫 줄의 나머지, \r·BOM 제거.
_fable_exec_model() {
  local v bom; bom=$(printf '\357\273\277')   # BSD sed(macOS)는 \xHH 를 몰라 printf 로 만든다
  v=$(sed "1s/^$bom//" "$FABLE_HOME/plan.env" 2>/dev/null | sed -n 's/^FABLE_EXEC_MODEL=//p' | head -1 | tr -d '\r')
  echo "${v:-claude-opus-5-5}"
}

_fable_run() {
  if [ "$(cat "$FABLE_STATE" 2>/dev/null)" = "on" ]; then
    # CLAUDE_CODE_SUBAGENT_MODEL: model 을 지정하지 않은 서브에이전트(general-purpose 포함)의 모델.
    #   없으면 메인 모델을 그대로 물려받아 위임 효과가 사라짐. deep-reasoner/runner 처럼
    #   frontmatter 에 model 이 있는 에이전트는 영향 없음. 호출 때마다 plan.env 를 읽는다.
    local m; m=$(_fable_exec_model)
    CLAUDE_CODE_SUBAGENT_MODEL="$m" \
    ANTHROPIC_DEFAULT_SONNET_MODEL="$m" "$@"
  else
    "$@"
  fi
}
claude() { _fable_run command claude "$@"; }

_fable_ok() { if [ "$1" = 0 ]; then echo "[ok] $2"; else echo "[!!] $2"; fi; }

fable() {
  case "$1" in
    on)
      echo on > "$FABLE_STATE"
      ln -sfn "$FABLE_HOME/fable.md" "$FABLE_HOME/active.md"
      echo "fable: ON (다음 세션부터 적용)";;
    off)
      echo off > "$FABLE_STATE"
      ln -sfn "$FABLE_HOME/empty.md" "$FABLE_HOME/active.md"
      echo "fable: OFF (다음 세션부터 적용)";;
    status)
      echo "state      : $(cat "$FABLE_STATE" 2>/dev/null || echo missing)"
      echo "active.md  : $(readlink "$FABLE_HOME/active.md")"
      grep -q 'fable/active.md' "$HOME/.claude/CLAUDE.md" 2>/dev/null;       _fable_ok $? "CLAUDE.md import"
      grep -q 'orchestration-gate.py' "$HOME/.claude/settings.json" 2>/dev/null; _fable_ok $? "settings.json hook"
      ok=0; for a in implementer architect deep-reasoner runner; do [ -e "$HOME/.claude/agents/$a.md" ] || ok=1; done; _fable_ok $ok "agents 4개 (implementer architect deep-reasoner runner)"
      [ -f "$FABLE_HOME/kickoff.md" ] && [ -f "$FABLE_HOME/coding-rules.md" ] && [ -f "$FABLE_HOME/hooks/progress-watch.py" ] && [ -f "$FABLE_HOME/hooks/folder-check.py" ] && [ -f "$FABLE_HOME/hooks/project-map.py" ] && [ -f "$FABLE_HOME/hooks/gate_common.py" ] && [ -f "$FABLE_HOME/hooks/fable_debt.py" ] && [ -f "$FABLE_HOME/hooks/fable_switches.py" ]; _fable_ok $? "kickoff.md · coding-rules.md · progress-watch.py · folder-check.py · project-map.py · gate_common.py · fable_debt.py · fable_switches.py"
      python3 -c 'import sys; sys.exit(sys.version_info < (3, 8))' 2>/dev/null; _fable_ok $? "python3 3.8+"
      v=$(command claude --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)
      # macOS 기본 sort 는 버전마다 -V 지원이 달라 python 으로 비교
      python3 -c 'import sys; a=[int(x) for x in sys.argv[1].split(".")]; b=[int(x) for x in sys.argv[2].split(".")]; sys.exit(a < b)' "${v:-0.0.0}" "$FABLE_MIN_CC" 2>/dev/null
      _fable_ok $? "claude ${v:-?} (${FABLE_MIN_CC} 이상 필요)"
      python3 "$FABLE_HOME/hooks/fable-settings.py" status 2>/dev/null
      if [ -f "$FABLE_HOME/gate.log" ]; then
        echo "gate.log   : DENY $(grep -c '"DENY"' "$FABLE_HOME/gate.log") / WARN $(grep -c '"WARN"' "$FABLE_HOME/gate.log") / ERROR $(grep -c '"ERROR"' "$FABLE_HOME/gate.log")"
      fi;;
    log)  tail -n "${2:-20}" "$FABLE_HOME/gate.log";;
    check)    # 프로젝트 구조 점검 (현재 폴더). --dry-run: V5 도입 영향 조사 (지도 생성 안 함) · --json: 지도 생성 생략
      shift; local _t=.; case "$1" in ""|-*) ;; *) _t="$1"; shift;; esac   # '-' 로 시작하는 첫 인자는 옵션 → 경로 '.'
      python3 "$FABLE_HOME/hooks/folder-check.py" "$_t" "$@"
      case " $* " in *" --dry-run "*|*" --json "*) ;; *) python3 "$FABLE_HOME/hooks/project-map.py" "$_t";; esac;;
    map)      # map [경로] [--stdout] [--check]  docs/map.md 생성(변경 있을 때만 씀)
      shift; local _t=.; case "$1" in ""|-*) ;; *) _t="$1"; shift;; esac
      python3 "$FABLE_HOME/hooks/project-map.py" "$_t" "$@";;
    debt)     # 부채 관리: list | add <경로> "<조건>" [--kind 줄수|안내|루트|구조] | fix <경로> [--kind] | keep <경로> "<조건>" [--kind] | drop <경로> [--kind] | enforce on|off
      python3 "$FABLE_HOME/hooks/fable-settings.py" debt "${@:2}";;
    global)   # 전체 적용 스위치: ~/.claude/settings.json env 에 모델 변수 기록/제거 (IDE·앱 포함). 모델은 fable-settings.py 가 plan.env 에서 읽는다
              # global require-md on|off (안내 파일 필수 전역 기본) · global map on|off (SessionStart 지도 갱신 훅)
      case "${2:-}" in
        require-md|map)
          if [ -z "${3:-}" ]; then echo "usage: fable global $2 on|off"
          else python3 "$FABLE_HOME/hooks/fable-settings.py" global "${@:2}"; fi;;
        *) python3 "$FABLE_HOME/hooks/fable-settings.py" global "${2:-}";;
      esac;;
    project)  # 프로젝트 스위치: on|off (게이트) · require-md on|off (안내 파일 필수) · --local
      python3 "$FABLE_HOME/hooks/fable-settings.py" project "${@:2}";;
    *)    echo "usage: fable on|off|status|log [n] | global on|off | project on|off|require-md on|off [--local]"
          echo "       fable check [경로] [--dry-run] [--json] | fable debt list|add|fix|keep|drop|enforce"
          echo "       fable map [경로]  docs/map.md 생성(변경 있을 때만 씀)"
          echo "       fable global require-md on | off   안내 파일 필수를 전역 기본으로 (프로젝트 값이 우선)"
          echo "       fable global map on | off          세션 시작 때 docs/map.md 자동 갱신 (SessionStart 훅)"
          echo "       fable debt add <경로> \"<조건>\" [--kind 줄수|안내|루트|구조] · keep|fix|drop <경로> … [--kind]";;
  esac
}

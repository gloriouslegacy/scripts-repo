﻿# ~/.claude/fable/env.ps1 — Fable orchestration switch (Windows PowerShell 5.1 / PowerShell 7) — Max·Pro (플랜은 설치 때 선택) (V5)
# $PROFILE 에서 dot-source 로 불러옵니다:  . "$HOME\.claude\fable\env.ps1"

$script:FableHome      = Join-Path $HOME '.claude\fable'
$script:FableState     = Join-Path $HOME '.claude\.fable-state'
$script:FableMinCC     = [version]'2.1.271'  # 최소 Claude Code 버전(가이드와 일치)

# 구현 서브에이전트(general-purpose 등)가 쓸 모델: 설치본 plan.env 의 FABLE_EXEC_MODEL, 없으면 claude-opus-5-5.
# plan.env 는 실행하지 않고 파싱만 한다: '^KEY=' 첫 줄의 나머지, \r·BOM 제거.
function Get-FableExecModel {
    $p = Join-Path $script:FableHome 'plan.env'
    if (Test-Path $p) {
        foreach ($line in [IO.File]::ReadAllLines($p)) {   # ReadAllLines 는 BOM·\r 을 걷어 낸다
            if ($line.TrimStart([char]0xFEFF) -match '^FABLE_EXEC_MODEL=(.*)$') {
                $v = $Matches[1].Trim("`r")
                if ($v) { return $v }
                break
            }
        }
    }
    'claude-opus-5-5'
}

function Get-FableState {
    if (Test-Path $script:FableState) { (Get-Content $script:FableState -Raw).Trim() } else { 'missing' }
}

function Get-ClaudeExe {
    Get-Command claude -CommandType Application, ExternalScript -ErrorAction SilentlyContinue |
        Select-Object -First 1
}

function claude {
    $exe = Get-ClaudeExe
    if (-not $exe) { Write-Error 'claude 실행 파일을 찾을 수 없습니다.'; return }
    if ((Get-FableState) -eq 'on') {
        # CLAUDE_CODE_SUBAGENT_MODEL: model 을 지정하지 않은 서브에이전트(general-purpose 포함)의 모델.
        # 없으면 메인 모델을 그대로 물려받아 위임 효과가 사라짐. 호출 때마다 plan.env 를 읽는다.
        $model = Get-FableExecModel
        $names = 'CLAUDE_CODE_SUBAGENT_MODEL', 'ANTHROPIC_DEFAULT_SONNET_MODEL'
        $prev = @{}
        foreach ($n in $names) { $prev[$n] = [Environment]::GetEnvironmentVariable($n); Set-Item "Env:$n" $model }
        try { & $exe.Source @args }
        finally {
            foreach ($n in $names) {
                if ($null -eq $prev[$n]) { Remove-Item "Env:$n" -ErrorAction SilentlyContinue } else { Set-Item "Env:$n" $prev[$n] }
            }
        }
    } else {
        & $exe.Source @args
    }
}

function Invoke-FableSettings {
    $script_ = Join-Path $script:FableHome 'hooks\fable-settings.py'
    if (Get-Command py -ErrorAction SilentlyContinue)          { & py -3 $script_ @args }
    elseif (Get-Command python -ErrorAction SilentlyContinue)  { & python $script_ @args }
    else { Write-Host '[!!] python 을 찾을 수 없습니다 (py 또는 python)' }
}

function Invoke-FableMap([string]$Target, [string[]]$MapArgs = @()) {
    # project-map.py 는 stdout 에 UTF-8 바이트를 쓴다 → 호출 동안만 콘솔 인코딩을 UTF-8 로 (한글 깨짐 방지)
    $map  = Join-Path $script:FableHome 'hooks\project-map.py'
    $prev = [Console]::OutputEncoding
    try {
        [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
        if (Get-Command py -ErrorAction SilentlyContinue) { & py -3 $map $Target @MapArgs } else { & python $map $Target @MapArgs }
    } finally { [Console]::OutputEncoding = $prev }
}

function fable {
    param(
        [Parameter(Position = 0)][string]$Cmd = 'help',
        [Parameter(Position = 1)][string]$Sub = '',
        [Parameter(Position = 2, ValueFromRemainingArguments = $true)][string[]]$Rest = @(),
        [switch]$Local,
        [switch]$DryRun
    )
    $N = 20; if ($Sub -match '^\d+$') { $N = [int]$Sub }

    $active = Join-Path $script:FableHome 'active.md'
    $log    = Join-Path $script:FableHome 'gate.log'

    switch ($Cmd) {
        'on' {
            Set-Content -Path $script:FableState -Value 'on' -NoNewline -Encoding ascii
            # 심볼릭 링크 대신 복사 (개발자 모드·관리자 권한 불필요)
            Copy-Item (Join-Path $script:FableHome 'fable.md') $active -Force
            Write-Host 'fable: ON (다음 세션부터 적용)'
        }
        'off' {
            Set-Content -Path $script:FableState -Value 'off' -NoNewline -Encoding ascii
            [IO.File]::WriteAllText($active, '')   # BOM 없는 빈 파일 (PS 5.1 의 -Encoding utf8 은 BOM 을 남김)
            Write-Host 'fable: OFF (다음 세션부터 적용)'
        }
        'status' {
            $ok = { param($c, $m) if ($c) { Write-Host "[ok] $m" -ForegroundColor Green } else { Write-Host "[!!] $m" -ForegroundColor Yellow } }
            Write-Host ("state      : {0}" -f (Get-FableState))
            $isOn = (Test-Path $active) -and ([IO.File]::ReadAllText($active).Trim([char]0xFEFF, ' ', "`t", "`r", "`n").Length -gt 0)
            Write-Host ("active.md  : {0}" -f ($(if ($isOn) { 'fable.md 내용' } else { '비어 있음(off)' })))

            $claudeMd = Join-Path $HOME '.claude\CLAUDE.md'
            & $ok ((Test-Path $claudeMd) -and (Select-String -Path $claudeMd -Pattern 'fable/active.md' -SimpleMatch -Quiet)) 'CLAUDE.md import'

            $settings = Join-Path $HOME '.claude\settings.json'
            & $ok ((Test-Path $settings) -and (Select-String -Path $settings -Pattern 'orchestration-gate.py' -SimpleMatch -Quiet)) 'settings.json hook'

            $agents = Join-Path $HOME '.claude\agents'
            $allAgents = @('implementer', 'architect', 'deep-reasoner', 'runner') | ForEach-Object { Test-Path (Join-Path $agents "$_.md") }
            & $ok (-not ($allAgents -contains $false)) 'agents 4개 (implementer architect deep-reasoner runner)'
            $extras = @('kickoff.md', 'coding-rules.md', 'hooks\progress-watch.py', 'hooks\folder-check.py', 'hooks\project-map.py', 'hooks\gate_common.py', 'hooks\fable_debt.py', 'hooks\fable_switches.py') | ForEach-Object { Test-Path (Join-Path $script:FableHome $_) }
            & $ok (-not ($extras -contains $false)) 'kickoff.md · coding-rules.md · progress-watch.py · folder-check.py · project-map.py · gate_common.py · fable_debt.py · fable_switches.py'

            # env.sh 와 같은 기준: Python 3.8+ (py -3 우선, 없으면 python)
            $pyOk = $false
            $pyChk = 'import sys; sys.exit(sys.version_info < (3, 8))'
            if (Get-Command py -ErrorAction SilentlyContinue) { & py -3 -c $pyChk 2>$null; $pyOk = ($LASTEXITCODE -eq 0) }
            if (-not $pyOk -and (Get-Command python -ErrorAction SilentlyContinue)) { & python -c $pyChk 2>$null; $pyOk = ($LASTEXITCODE -eq 0) }
            & $ok $pyOk 'python 3.8+'

            $exe = Get-ClaudeExe
            $v = $null
            if ($exe) {
                $raw = (& $exe.Source --version 2>$null | Out-String)
                $m = [regex]::Match($raw, '\d+\.\d+\.\d+')
                if ($m.Success) { $v = [version]($m.Value) }
            }
            & $ok ($v -and $v -ge $script:FableMinCC) ("claude {0} ({1} 이상 필요)" -f $(if ($v) { $v } else { '?' }), $script:FableMinCC)

            Invoke-FableSettings status
            if (Test-Path $log) {
                $c = Get-Content $log -Encoding utf8
                $d = ($c | Select-String '"DENY"').Count
                $w = ($c | Select-String '"WARN"').Count
                $e = ($c | Select-String '"ERROR"').Count
                Write-Host "gate.log   : DENY $d / WARN $w / ERROR $e"
            }
        }
        'log' {
            if (Test-Path $log) { Get-Content $log -Encoding utf8 -Tail $N } else { Write-Host 'gate.log 없음' }
        }
        'check' {    # 프로젝트 구조 점검. fable check [경로] [-DryRun | --dry-run] [--json]
            # '--dry-run'·'--json' 같은 토큰은 위치 인자로 $Sub/$Rest 에 들어온다 → 그대로 folder-check.py 로 넘긴다
            $pass = @(@($Sub) + $Rest | Where-Object { $_ })
            $target = '.'
            if ($pass.Count -gt 0 -and -not $pass[0].StartsWith('-')) { $target = $pass[0]; $pass = @($pass | Select-Object -Skip 1) }
            $chk = Join-Path $script:FableHome 'hooks\folder-check.py'
            $extra = @($pass); if ($DryRun -and ($extra -notcontains '--dry-run')) { $extra += '--dry-run' }
            if (Get-Command py -ErrorAction SilentlyContinue) { & py -3 $chk $target @extra } else { & python $chk $target @extra }
            # dry-run 이 아니면 지도 생성. --json 이면 출력이 JSON 을 오염시키지 않게 건너뛴다
            if (-not ($extra -contains '--dry-run') -and -not ($extra -contains '--json')) { Invoke-FableMap $target }
        }
        'map' {      # map [경로] [--stdout | --check]  docs/map.md 생성(변경 있을 때만 씀). env.sh 와 같이 '-' 로 시작하는 첫 인자는 옵션
            $pass = @(@($Sub) + $Rest | Where-Object { $_ })
            $target = '.'
            if ($pass.Count -gt 0 -and -not $pass[0].StartsWith('-')) { $target = $pass[0]; $pass = @($pass | Select-Object -Skip 1) }
            Invoke-FableMap $target @($pass)
        }
        'debt' {     # fable debt list | add <경로> "<조건>" [--kind 줄수|안내|루트|구조] | fix <경로> [--kind] | keep <경로> "<조건>" [--kind] | drop <경로> [--kind] | enforce on|off
            $args_ = @(@($Sub) + $Rest | Where-Object { $_ })   # 빈 Sub 를 '' 인자로 넘기지 않는다
            Invoke-FableSettings debt @args_
        }
        'global' {   # 전체 적용 스위치: ~\.claude\settings.json env 에 모델 변수 기록/제거 (IDE·앱 포함). 모델은 fable-settings.py 가 plan.env 에서 읽는다
            # global require-md on|off (안내 파일 필수 전역 기본) · global map on|off (SessionStart 지도 갱신 훅)
            if ($Sub -eq 'require-md' -or $Sub -eq 'map') {
                $rest_ = @($Rest | Where-Object { $_ })
                if ($rest_.Count -eq 0) { Write-Host "usage: fable global $Sub on|off" }
                else { Invoke-FableSettings global $Sub @rest_ }
            } else {
                $args_ = @(@($Sub) | Where-Object { $_ })
                Invoke-FableSettings global @args_
            }
        }
        'project' {  # fable project on|off | require-md on|off  (-Local 이면 settings.local.json)
            $args_ = @(@($Sub) + $Rest | Where-Object { $_ })
            if ($Local) { Invoke-FableSettings project @args_ --local } else { Invoke-FableSettings project @args_ }
        }
        default {
            Write-Host 'usage: fable on|off|status|log [n] | global on|off | project on|off|require-md on|off [-Local]'
            Write-Host '       fable check [경로] [-DryRun|--dry-run] [--json] | fable debt list|add|fix|keep|drop|enforce'
            Write-Host '       fable map [경로]  docs/map.md 생성(변경 있을 때만 씀)'
            Write-Host '       fable global require-md on | off   안내 파일 필수를 전역 기본으로 (프로젝트 값이 우선)'
            Write-Host '       fable global map on | off          세션 시작 때 docs/map.md 자동 갱신 (SessionStart 훅)'
            Write-Host '       fable debt add <경로> "<조건>" [--kind 줄수|안내|루트|구조] · keep|fix|drop <경로> … [--kind]'
        }
    }
}

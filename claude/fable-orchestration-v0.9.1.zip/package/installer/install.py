#!/usr/bin/env python3
"""Fable 오케스트레이션 V5 설치·갱신·제거 (Windows / macOS / Linux·WSL).

guide/APPLY-GUIDE-{Windows,macOS,Linux}.md 의 1~5절(설치)·7절(갱신)·8절(제거)을 코드화한 것이다.
표준 라이브러리와 설치기 전용 모듈(`install_*`)만 import 하고 훅 스크립트는 import 하지 않는다.
  py -3 installer/install.py (또는 python3 installer/install.py) [--dry-run] [--yes] [--uninstall] [--home <경로>]
      [--plan max|pro] [--model-<역할> ID] [--effort-<역할> low|medium|high|xhigh|max|default]
      [--require-md on|off] [--map-on-start on|off]
종료 코드: 0 성공 · 1 사전 검사 실패 · 2 그 외 오류
"""
import argparse
import datetime
import json
import os
import shutil
import stat
import sys

SRC = os.path.dirname(os.path.abspath(__file__))  # package/installer (설치기 모듈 폴더)
PKG = os.path.dirname(SRC)  # 패키지 루트: VERSION, fable/, hooks/, agents/
PLAN_SRC = os.path.join(PKG, "fable")  # plan-*.env·plan-*.md 가 있는 폴더 (install_plan 의 src)
sys.dont_write_bytecode = True  # 레포에서 실행해도 package/__pycache__ 가 생겨 zip 에 섞이지 않게
sys.path.insert(0, SRC)  # -P·-I·PYTHONSAFEPATH·._pth 에서도 같은 폴더 모듈을 찾게
try:
    from install_util import (IS_WIN, PrecheckFailed, ok, warn, plan, ask, run, read_bytes, write_bytes,
                              read_text, append_line, slash, read_version, load_json, save_json, rm_tree)
    from install_env import precheck, count_running, find_profiles, link_profiles
    import install_plan
except ImportError as e:  # 진입점 종단: traceback 대신 안내
    print("[!!] 설치기 모듈을 불러오지 못했습니다 (%s). 패키지 폴더 전체가 필요합니다."
          " 압축을 푼 패키지 폴더 안의 설치기로 실행하세요" % e)
    sys.exit(2)

FABLE_FILES = ("fable.md", "kickoff.md", "coding-rules.md", "env.sh", "env.ps1")  # PKG/fable/ 아래
ROOT_FILES = ("VERSION",)  # PKG 루트. 릴리스 번호, fable status 가 설치본을 읽는다
HOOK_FILES = ("orchestration-gate.py", "fable-settings.py", "progress-watch.py", "folder-check.py",
              "project-map.py",  # 훅 등록 없음, 복사만 (fable map·fable check 가 호출)
              "gate_common.py", "fable_debt.py",  # 뒤 세 개는 앞 스크립트들이 import 하는 보조 모듈
              "fable_switches.py")  # fable-settings.py 가 import (global require-md|map)
AGENTS = ("implementer", "architect", "deep-reasoner", "runner")
IMPORT_LINE = "@~/.claude/fable/active.md"
GATE_MARK = "orchestration-gate"
STATE_NAME = ".fable-state"

class Ctx(object):
    def __init__(self, a):
        self.dry, self.yes, self.custom_home = a.dry_run, a.yes, a.home is not None
        self.args, self.values = a, {}  # values: install_plan.resolve·check 의 최종값
        self.switches, self.switch_src, self.switch_before = {}, {}, {}  # install_plan.ask_switches 결과
        self.had_install = False  # 설치 시작 때 설치본(게이트 스크립트)이 있었는가 — 재설치 알림 조건
        self.home = os.path.abspath(a.home) if a.home else os.path.expanduser("~")
        self.c = os.path.join(self.home, ".claude")
        self.f = os.path.join(self.c, "fable")
        self.hooks = os.path.join(self.f, "hooks")
        self.agents = os.path.join(self.c, "agents")
        self.settings = os.path.join(self.c, "settings.json")
        self.claude_md = os.path.join(self.c, "CLAUDE.md")
        self.has_py = bool(shutil.which("py")) if IS_WIN else False
        self.running = 0
        self.profiles = []

    def targets(self):
        """(원본 PKG 기준 상대 경로, 설치 경로) 18개. 생성 파일 plan.env·plan.md 는 install_plan.plan_files."""
        out = [(os.path.join("fable", n), os.path.join(self.f, n)) for n in FABLE_FILES]
        out += [(n, os.path.join(self.f, n)) for n in ROOT_FILES]
        out += [(os.path.join("hooks", n), os.path.join(self.hooks, n)) for n in HOOK_FILES]
        out += [(os.path.join("agents", "agent-%s.md" % n), os.path.join(self.agents, n + ".md")) for n in AGENTS]
        return out

def gate_entry(ctx):
    if IS_WIN:
        gate = slash(os.path.join(ctx.hooks, "orchestration-gate.py"))
        cmd, args = ("py", ["-3", gate]) if ctx.has_py else (slash(sys.executable), [gate])
        return {"matcher": "Write|Edit|MultiEdit|NotebookEdit|Bash|PowerShell|Agent",
                "hooks": [{"type": "command", "command": cmd, "args": args, "timeout": 10}]}
    return {"matcher": "Write|Edit|MultiEdit|NotebookEdit|Bash|Agent",
            "hooks": [{"type": "command",
                       "command": 'python3 "$HOME/.claude/fable/hooks/orchestration-gate.py"',
                       "timeout": 10}]}

def set_gate(ctx, install):
    data = load_json(ctx.settings)
    hooks = data.get("hooks") if isinstance(data.get("hooks"), dict) else {}
    pre = hooks.get("PreToolUse") if isinstance(hooks.get("PreToolUse"), list) else []
    keep = [e for e in pre if GATE_MARK not in json.dumps(e, ensure_ascii=False)]
    removed = len(pre) - len(keep)
    if install:
        keep.append(gate_entry(ctx))
    elif not removed:
        ok("settings.json: 게이트 항목 없음")
        return
    if keep:
        hooks["PreToolUse"] = keep
    else:
        hooks.pop("PreToolUse", None)
    if hooks:
        data["hooks"] = hooks
    else:
        data.pop("hooks", None)
    verb = "등록" if install else "제거"
    if ctx.dry:
        plan("settings.json 게이트 훅 %s (기존 게이트 항목 %d개 교체·제거, settings.json.bak 백업)" % (verb, removed))
        return
    save_json(ctx.settings, data)
    ok("settings.json 게이트 훅 %s (기존 게이트 항목 %d개 정리, settings.json.bak 백업)" % (verb, removed))

# ── 3·4. 백업과 복사 ─────────────────────────────────────────────────
def payload(src_name):
    """src_name 은 PKG 기준 상대 경로 (targets() 의 첫 요소)."""
    data = read_bytes(os.path.join(PKG, src_name))
    if not IS_WIN:  # Windows 에서 받은 파일의 BOM·CRLF 정리
        data = (data[3:] if data.startswith(b"\xef\xbb\xbf") else data).replace(b"\r\n", b"\n")
    return data

def backup_and_copy(ctx):
    items = [(dst, install_plan.render_agent(src, payload(src), ctx.values)
              if os.path.basename(src).startswith("agent-") else payload(src)) for src, dst in ctx.targets()]
    items += install_plan.plan_files(ctx, ctx.values, PLAN_SRC)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M")
    bak = os.path.join(ctx.f, "bak-" + stamp)
    changed = [dst for dst, data in items if os.path.isfile(dst) and read_bytes(dst) != data]
    act = os.path.join(ctx.f, "active.md")
    if os.path.isfile(act) and not os.path.islink(act) and read_bytes(act) != payload(os.path.join("fable", "fable.md")):
        changed.append(act)
    for dst in changed:
        rel = os.path.relpath(dst, ctx.c)
        if ctx.dry:
            plan("백업 %s → %s" % (rel, os.path.relpath(os.path.join(bak, rel), ctx.c)))
        else:
            write_bytes(os.path.join(bak, rel), read_bytes(dst))
    if changed and not ctx.dry:
        ok("기존 파일 %d개 백업 → %s" % (len(changed), bak))
    elif not changed:
        ok("백업할 변경 파일 없음")
    gp = os.path.join(ctx.agents, "general-purpose.md")
    if os.path.lexists(gp):
        if ctx.dry:
            plan("V3 잔재 삭제: " + gp)
        else:
            os.remove(gp)
            ok("V3 잔재 삭제: " + gp)
    if ctx.dry:
        plan("디렉터리 생성: %s, %s, %s" % (ctx.hooks, os.path.join(ctx.f, "state"), ctx.agents))
        for dst, _ in items:
            plan("복사 → " + os.path.relpath(dst, ctx.home))
        return
    for d in (ctx.hooks, os.path.join(ctx.f, "state"), ctx.agents):
        os.makedirs(d, exist_ok=True)
    for dst, data in items:
        write_bytes(dst, data)
        if not IS_WIN and dst.endswith(".py"):
            os.chmod(dst, os.stat(dst).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    ok("파일 %d개 복사%s" % (len(items), "" if IS_WIN else " (CRLF·BOM 정리, .py 실행 권한)"))

# ── 6. CLAUDE.md import ─────────────────────────────────────────────
def link_claude_md(ctx):
    if "fable/active.md" in read_text(ctx.claude_md):
        ok("CLAUDE.md import 이미 있음")
    elif ctx.dry:
        plan("%s 끝에 %s 추가" % (ctx.claude_md, IMPORT_LINE))
    else:
        append_line(ctx.claude_md, IMPORT_LINE)
        ok("CLAUDE.md 에 %s 추가" % IMPORT_LINE)

def unlink_claude_md(ctx):
    text = read_text(ctx.claude_md)
    if IMPORT_LINE not in text:
        ok("CLAUDE.md import 없음")
        return
    if ctx.dry:
        plan("%s 에서 %s 줄 제거" % (ctx.claude_md, IMPORT_LINE))
        return
    lines = [ln for ln in text.splitlines() if ln.strip() != IMPORT_LINE]
    while lines and not lines[-1].strip():
        lines.pop()
    write_bytes(ctx.claude_md, ("\n".join(lines) + ("\n" if lines else "")).encode("utf-8"))
    ok("CLAUDE.md 에서 import 줄 제거")

# ── 8. 상태 파일 ─────────────────────────────────────────────────────
def write_state(ctx):
    empty, state = os.path.join(ctx.f, "empty.md"), os.path.join(ctx.c, STATE_NAME)
    act, fable = os.path.join(ctx.f, "active.md"), os.path.join(ctx.f, "fable.md")
    if ctx.dry:
        plan("%s 빈 파일, %s=on, active.md ← fable.md (%s)" % (empty, state, "복사" if IS_WIN else "심볼릭 링크"))
        return
    write_bytes(empty, b"")
    write_bytes(state, b"on")
    if IS_WIN:
        write_bytes(act, read_bytes(fable))
    else:
        if os.path.lexists(act):
            os.remove(act)
        os.symlink(fable, act)
    ok("상태 파일: empty.md · state=on · active.md ← fable.md")

# ── 9. 서브에이전트 모델 전역 적용 ─────────────────────────────────────
def settings_global(ctx, action, script=None):
    script = script or os.path.join(ctx.hooks, "fable-settings.py")
    extra = ["--model", ctx.values["FABLE_EXEC_MODEL"]] if action == "on" and ctx.values else []
    if ctx.dry:
        plan("fable-settings.py global %s %s(대상 홈 %s)" % (action, " ".join(extra) + " " if extra else "", ctx.home))
        return
    env = dict(os.environ, HOME=ctx.home, USERPROFILE=ctx.home, PYTHONIOENCODING="utf-8")
    r = run([sys.executable, script, "global", action] + extra, env=env, timeout=60)
    if r is not None and r.returncode == 0:
        ok("서브에이전트 모델 전역 %s" % ("적용" if action == "on" else "해제"))
    else:
        err = ((r.stderr or r.stdout or "").strip() if r else "실행 불가")[-300:]
        warn("global %s 실패 (종료 코드 %s): %s" % (action, r.returncode if r else "-", err))

# ── 9-1. 전역 스위치 (docs/design-global-defaults.md C 절) ─────────────────
def apply_switches(ctx):
    """fable-settings.py global require-md|map on|off 로 적용. require-md 는 off 도 "0" 기록."""
    script = os.path.join(ctx.hooks, "fable-settings.py")
    env = dict(os.environ, HOME=ctx.home, USERPROFILE=ctx.home, PYTHONIOENCODING="utf-8")
    for key, action, _, _, label in install_plan.SWITCHES:
        value = "on" if ctx.switches[key] else "off"
        if ctx.dry:
            plan("fable-settings.py global %s %s (대상 홈 %s)" % (action, value, ctx.home))
            continue
        r = run([sys.executable, script, "global", action, value], env=env, timeout=60)
        if r is not None and r.returncode == 0:
            ok("%s: %s" % (label, "ON" if value == "on" else "off"))
        else:
            err = ((r.stderr or r.stdout or "").strip() if r else "실행 불가")[-300:]
            warn("global %s %s 실패 (종료 코드 %s): %s" % (action, value, r.returncode if r else "-", err))

def clear_switches(ctx):
    """제거: SessionStart 의 project-map 항목과 전역 env 의 require-md 키를 settings.json 에서 직접 지운다."""
    data = load_json(ctx.settings)
    env = data.get("env") if isinstance(data.get("env"), dict) else {}
    hooks = data.get("hooks") if isinstance(data.get("hooks"), dict) else {}
    start = hooks.get("SessionStart") if isinstance(hooks.get("SessionStart"), list) else []
    keep = [e for e in start if install_plan.MAP_MARK not in json.dumps(e, ensure_ascii=False)]
    removed, has_key = len(start) - len(keep), install_plan.REQUIRE_KEY in env
    if not removed and not has_key:
        ok("settings.json: 전역 스위치 항목 없음")
        return
    what = "SessionStart project-map 항목 %d개, env %s %s" % (removed, install_plan.REQUIRE_KEY,
                                                           "키" if has_key else "없음")
    if ctx.dry:
        plan("settings.json 전역 스위치 제거 (%s)" % what)
        return
    env.pop(install_plan.REQUIRE_KEY, None)
    if env:
        data["env"] = env
    else:
        data.pop("env", None)
    if keep:
        hooks["SessionStart"] = keep
    else:
        hooks.pop("SessionStart", None)
    if hooks:
        data["hooks"] = hooks
    else:
        data.pop("hooks", None)
    save_json(ctx.settings, data)
    ok("settings.json 전역 스위치 제거 (%s)" % what)

def switch_notice(ctx):
    """업그레이드 사용자에게만 "새 동작" 블록(install_plan.notice_lines)."""
    lines = install_plan.notice_lines(ctx.had_install, ctx.switch_before, ctx.switches)
    if lines:
        print("\n── 새 동작 (이번 업그레이드) ──")
        for ln in lines:
            print("  " + ln)

def init_notice():
    """완료 안내 맨 앞: 프로젝트 안내 파일 위치(.claude/CLAUDE.md). 설치 성공 경로에서만."""
    print("\n[중요] Fable 은 프로젝트의 .claude/CLAUDE.md 를 기준으로 동작합니다.")
    print("  /init 은 루트 CLAUDE.md 에 쓰므로 실행 후 옮기세요:")
    print("    mkdir -p .claude && git mv CLAUDE.md .claude/CLAUDE.md")
    print("    (PowerShell: New-Item -ItemType Directory -Force .claude; git mv CLAUDE.md .claude/CLAUDE.md)")
    print("  루트에만 있으면 Fable Orchestration 이 정상 구동되지 않습니다.")

# ── 10. 자가진단 ─────────────────────────────────────────────────────
def self_check(ctx):
    print("\n── 자가진단 ──")
    if ctx.dry:
        plan("(dry-run) 자가진단 생략")
        return
    tg = ctx.targets() + [(None, os.path.join(ctx.f, n)) for n in ("plan.env", "plan.md")]
    miss = [dst for _, dst in tg if not os.path.isfile(dst)]
    (ok if not miss else warn)("설치 파일 %d/%d%s" % (len(tg) - len(miss), len(tg),
                                                   "" if not miss else " 없음: " + ", ".join(miss)))
    try:
        data = load_json(ctx.settings)
    except ValueError as e:
        warn("settings.json 해석 실패: %s" % e)
        data = {}
    pre = (data.get("hooks") or {}).get("PreToolUse") if isinstance(data.get("hooks"), dict) else None
    n = sum(1 for e in (pre or []) if GATE_MARK in json.dumps(e, ensure_ascii=False))
    (ok if n == 1 else warn)("settings.json 게이트 훅 %d개" % n)
    (ok if "fable/active.md" in read_text(ctx.claude_md) else warn)("CLAUDE.md import")
    st = read_text(os.path.join(ctx.c, STATE_NAME)).strip()
    (ok if st == "on" else warn)("state: %s" % (st or "?"))
    pat = "fable\\env.ps1" if IS_WIN else "fable/env.sh"
    for p in ctx.profiles:
        (ok if pat in read_text(p) else warn)("프로필 연결: " + p)
    gm = (data.get("env") or {}).get("CLAUDE_CODE_SUBAGENT_MODEL") if isinstance(data.get("env"), dict) else None
    (ok if gm else warn)("global: %s" % ("ON (%s)" % gm if gm else "off"))
    install_plan.self_check(ctx, ctx.values, gm)
    got = install_plan.switch_state(data)
    for line, key in zip(install_plan.switch_lines(ctx.switches, ctx.switch_src), ("require_md", "map_on_start")):
        (ok if got[key] == ctx.switches[key] else warn)(line + ("" if got[key] == ctx.switches[key] else
                                                              " ≠ settings.json %s" % got[key]))
    init_notice()
    print("\n새 셸(터미널)을 열고 `fable status` 로 확인하세요.")
    if ctx.running:
        print("실행 중이던 Claude Code 세션 %d개는 다시 열어야 적용됩니다." % ctx.running)

# ── 제거 ────────────────────────────────────────────────────────────
def uninstall(ctx):
    print("Fable V5 제거 (설치본 v%s) — 대상 %s" % (read_version(ctx.f), ctx.c))
    if not ctx.dry and not ask(ctx, "settings·CLAUDE.md·에이전트·%s 를 제거할까?" % ctx.f):
        warn("제거를 취소했습니다")
        return 0
    set_gate(ctx, install=False)
    clear_switches(ctx)
    unlink_claude_md(ctx)
    script = os.path.join(ctx.hooks, "fable-settings.py")
    settings_global(ctx, "off", script if os.path.isfile(script) else os.path.join(PKG, "hooks", "fable-settings.py"))
    for p in [os.path.join(ctx.agents, n + ".md") for n in AGENTS] + [os.path.join(ctx.c, STATE_NAME)]:
        if not os.path.lexists(p):
            continue
        if ctx.dry:
            plan("삭제 " + p)
        else:
            os.remove(p)
            ok("삭제 " + p)
    if os.path.isdir(ctx.f):
        if ctx.dry:
            plan("폴더 삭제 " + ctx.f)
        else:
            rm_tree(ctx.f)
            ok("폴더 삭제 " + ctx.f + " (bak-* 포함)")
    profiles, pat, _ = find_profiles(ctx)
    for p in profiles:
        for ln in read_text(p).splitlines():
            if pat in ln:
                warn("프로필에서 직접 지우세요: %s → %s" % (p, ln.strip()))
    ok("제거 완료. 새 셸을 여세요")
    return 0

def install(ctx):
    print("Fable V5 설치 (v%s) — 원본 %s → 대상 %s%s" % (read_version(PKG), PKG, ctx.c,
                                                    " (dry-run)" if ctx.dry else ""))
    print("\n── 1. 사전 검사 ──")
    precheck(ctx)
    print("\n── 2. 실행 중인 Claude Code ──")
    count_running(ctx)
    print("\n── 2-1. 플랜·모델 ──")
    values, sources = install_plan.resolve(ctx, PLAN_SRC)
    ctx.values = install_plan.check(values, PLAN_SRC)
    install_plan.show(ctx, ctx.values, sources)
    print("\n── 2-2. 스위치 ──")
    ctx.had_install = os.path.isfile(os.path.join(ctx.hooks, "orchestration-gate.py"))  # 복사 전에 기억
    ctx.switches, ctx.switch_src, ctx.switch_before = install_plan.ask_switches(ctx, load_json(ctx.settings))
    for line in install_plan.switch_lines(ctx.switches, ctx.switch_src):
        (plan if ctx.dry else ok)(line)
    print("\n── 3·4. 백업·복사 ──")
    backup_and_copy(ctx)
    print("\n── 5. settings.json 훅 ──")
    set_gate(ctx, install=True)
    print("\n── 6. CLAUDE.md ──")
    link_claude_md(ctx)
    print("\n── 7. 셸 프로필 ──")
    link_profiles(ctx)
    print("\n── 8. 상태 파일 ──")
    write_state(ctx)
    print("\n── 9. 서브에이전트 모델 ──")
    settings_global(ctx, "on")
    print("\n── 9-1. 전역 스위치 ──")
    apply_switches(ctx)
    self_check(ctx)
    switch_notice(ctx)
    return 0

def main():
    for s in (sys.stdout, sys.stderr):
        if hasattr(s, "reconfigure"):
            s.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(description="Fable 오케스트레이션 V5 설치·갱신·제거")
    ap.add_argument("--dry-run", action="store_true", help="쓰기·실행 없이 할 일만 출력")
    ap.add_argument("--yes", action="store_true", help="모든 확인 질문에 예")
    ap.add_argument("--uninstall", action="store_true", help="제거")
    ap.add_argument("--home", help="홈 디렉터리 대체(테스트용)")
    ap.add_argument("--plan", choices=install_plan.available(PLAN_SRC),
                    help="플랜 프로필 (지정하면 설치본 plan.env 의 이전 선택을 리셋, 없으면 설치본 → max)")
    for r in AGENTS:
        ap.add_argument("--model-" + r, metavar="ID",
                        help="%s 모델 (프로필·설치본보다 우선. 대화형 후보 밖 ID — Bedrock 형식·새 모델 — 는 이 플래그로만)" % r)
        ap.add_argument("--effort-" + r, choices=install_plan.EFFORTS + ("default",),
                        help="%s effort (default = 줄 제거, 모델 기본 = medium)" % r)
    ap.add_argument("--require-md", choices=("on", "off"),
                    help="안내 파일 필수 전역 기본 (없으면 대화형 > 설치본 현재값 > on)")
    ap.add_argument("--map-on-start", choices=("on", "off"),
                    help="세션 시작 때 docs/map.md 자동 갱신 (없으면 대화형 > 설치본 현재값 > on)")
    a = ap.parse_args()
    ctx = Ctx(a)
    try:
        if a.uninstall:
            precheck(ctx, need_claude=False)
            return uninstall(ctx)
        return install(ctx)
    except PrecheckFailed as e:
        warn("사전 검사 실패: %s" % e)
        return 1
    except KeyboardInterrupt:
        warn("중단됨")
        return 2
    except Exception as e:  # 진입점 종단: traceback 대신 메시지
        warn("오류: %s: %s" % (type(e).__name__, e))
        return 2

if __name__ == "__main__":
    sys.exit(main())

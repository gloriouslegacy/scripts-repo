"""Fable 설치기 공통 I/O (출력·확인 질문·명령 실행·파일/JSON 쓰기).

설치기 전용 모듈이다. 설치 대상이 아니며(복사 목록에 없음) 같은 폴더의 설치기만 import 한다.
표준 라이브러리만 쓰고 Python 3.8 호환을 유지한다. 설치기의 Ctx 는 import 하지 않는다
(ask 는 넘겨받은 ctx 의 yes 만 읽는다).
"""
import json
import os
import shutil
import stat
import subprocess
import sys

IS_WIN = os.name == "nt"

class PrecheckFailed(Exception):
    pass

def ok(msg): print("[ok] " + msg)  # noqa: E704
def warn(msg): print("[!!] " + msg)  # noqa: E704
def plan(msg): print("[--] " + msg)  # noqa: E704

def ask(ctx, question):
    if ctx.yes:
        return True
    if not (sys.stdin and sys.stdin.isatty()):
        warn(question + " → 아니오 (입력 장치가 터미널이 아니고 --yes 도 없음)")
        return False
    try:
        ans = input(question + " [y/N] ").strip().lower()
    except EOFError:  # Windows 는 NUL 리다이렉트도 tty 로 보인다
        print("")
        warn(question + " → 아니오 (입력 없음, --yes 도 없음)")
        return False
    return ans in ("y", "yes", "예", "ㅇ")

def run(cmd, env=None, timeout=120):
    """명령 실행. 실행 파일이 없거나 실패하면 None."""
    try:
        return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              universal_newlines=True, encoding="utf-8", errors="replace",
                              env=env, timeout=timeout)
    except (OSError, subprocess.SubprocessError):
        return None

def read_bytes(p):
    with open(p, "rb") as fh:
        return fh.read()

def write_bytes(p, data):
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    with open(p, "wb") as fh:
        fh.write(data)

def read_text(p):
    if not os.path.isfile(p):
        return ""
    with open(p, encoding="utf-8-sig", errors="replace") as fh:
        return fh.read()

def append_line(p, line):
    """p 끝에 한 줄 추가(앞 줄과 분리). 기존 인코딩·BOM 은 건드리지 않는다."""
    prev = read_bytes(p) if os.path.isfile(p) else b""
    write_bytes(p, prev + ("\n" + line + "\n").encode("utf-8"))

def slash(p):
    return p.replace("\\", "/")

def read_version(folder):
    """folder/VERSION 의 릴리스 버전(strip). 파일이 없거나 비면 "?"."""
    return read_text(os.path.join(folder, "VERSION")).strip() or "?"

# ── 설정 파일 (fable-settings.py 의 load/save 와 같은 규칙) ────────────────
def load_json(path):
    if not os.path.exists(path):
        return {}
    text = read_text(path).strip()
    try:
        data = json.loads(text) if text else {}
    except ValueError as e:  # 번역: 어느 파일인지 붙여 다시 던진다
        raise ValueError("%s 해석 실패 (%s). 직접 고친 뒤 다시 실행하세요" % (path, e)) from e
    if not isinstance(data, dict):
        warn("%s 최상위가 JSON 객체가 아니라 빈 설정으로 취급합니다" % path)
        return {}
    return data

def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        raw = read_bytes(path)
        orig = path + ".fable-orig.bak"  # 처음 손대기 전 원본(1회만)
        if not os.path.exists(orig):
            write_bytes(orig, raw)
        write_bytes(path + ".bak", raw)  # 직전 상태
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
        fh.write("\n")
    os.replace(tmp, path)

# ── 제거 ────────────────────────────────────────────────────────────
def rm_tree(path):
    def onerr(func, p, _exc):
        os.chmod(p, stat.S_IWRITE)  # Windows 읽기 전용 파일
        func(p)
    shutil.rmtree(path, onerror=onerr)

"""Fable 설치기 OS·환경 조사 (사전 검사·실행 중 Claude Code 감지·셸 프로필).

설치기 전용 모듈이다. 설치 대상이 아니며(복사 목록에 없음) 같은 폴더의 설치기만 import 한다.
표준 라이브러리와 install_util 만 쓰고 Python 3.8 호환을 유지한다. 설치기의 Ctx 는 import 하지 않는다
(넘겨받은 ctx 의 dry·yes·has_py·home·custom_home·running·profiles 만 쓴다).
"""
import os
import re
import shutil
import sys

from install_util import IS_WIN, PrecheckFailed, ok, warn, plan, ask, run, read_text, append_line

MIN_CC = (2, 1, 271)
PS_LINE = '. "$HOME\\.claude\\fable\\env.ps1"'
SH_LINE = '[ -f "$HOME/.claude/fable/env.sh" ] && source "$HOME/.claude/fable/env.sh"'

# ── 1. 사전 검사 ─────────────────────────────────────────────────────
def claude_version():
    exe = shutil.which("claude")
    if not exe:
        return None, None
    r = run([exe, "--version"], timeout=60)
    if r is None or r.returncode != 0:
        return exe, None
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", r.stdout or "")
    return exe, (tuple(int(x) for x in m.groups()) if m else None)

def vstr(v):
    return ".".join(str(x) for x in v) if v else "?"

def precheck(ctx, need_claude=True):
    if sys.version_info < (3, 8):
        raise PrecheckFailed("Python 3.8 이상이 필요합니다 (현재 %s)" % sys.version.split()[0])
    ok("python %s (%s)" % (sys.version.split()[0], sys.executable))
    if IS_WIN:
        (ok if ctx.has_py else warn)("py 런처 %s" % ("있음" if ctx.has_py else
                                                    "없음 → 훅은 %s 로 실행" % sys.executable))
    if not need_claude:
        return
    exe, ver = claude_version()
    if exe and ver and ver >= MIN_CC:
        ok("claude %s (%s 이상)" % (vstr(ver), vstr(MIN_CC)))
        return
    if exe:
        warn("claude %s — %s 이상 필요" % (vstr(ver), vstr(MIN_CC)))
        if ctx.dry:
            plan("확인 후 `claude update` 실행")
            return
        if ask(ctx, "`claude update` 실행할까?"):
            r = run([exe, "update"], timeout=600)
            exe, ver = claude_version()
            if ver and ver >= MIN_CC:
                ok("claude %s 로 갱신됨" % vstr(ver))
                return
            warn("갱신 후에도 claude %s (종료 코드 %s). 나중에 `claude update` 를 직접 실행하세요"
                 % (vstr(ver), r.returncode if r else "실행 실패"))
        else:
            warn("claude 갱신을 건너뜀. 게이트가 일부 동작하지 않을 수 있습니다")
        return
    warn("claude 명령을 찾을 수 없습니다")
    cmd = (["powershell", "-NoProfile", "-Command", "irm https://claude.ai/install.ps1 | iex"] if IS_WIN
           else ["bash", "-c", "curl -fsSL https://claude.ai/install.sh | bash"])
    if ctx.dry:
        plan("확인 후 공식 설치 스크립트 실행: " + cmd[-1])
        return
    if ask(ctx, "공식 설치 스크립트(%s)를 실행할까?" % cmd[-1]):
        r = run(cmd, timeout=600)
        if r is None or r.returncode != 0:
            warn("설치 스크립트 실패: %s" % ((r.stderr or "").strip()[-300:] if r else "실행 불가"))
        exe, ver = claude_version()
        if exe:
            ok("claude %s 설치됨" % vstr(ver))
            return
    raise PrecheckFailed("claude 가 없습니다. https://claude.ai 의 설치 안내를 따른 뒤 새 터미널에서 다시 실행하세요"
                         " (설치 직후라면 PATH 반영을 위해 새 터미널이 필요할 수 있습니다)")

# ── 2. 실행 중인 Claude Code ──────────────────────────────────────────
def count_running(ctx):
    if IS_WIN:
        r = run(["tasklist", "/FI", "IMAGENAME eq claude.exe", "/FO", "CSV", "/NH"], timeout=30)
        n = sum(1 for ln in (r.stdout if r else "").splitlines() if ln.lower().startswith('"claude.exe"'))
    else:
        r = run(["pgrep", "-x", "claude"], timeout=30)  # -f 는 이 스크립트 경로(.claude)까지 잡는다
        n = len([ln for ln in (r.stdout if r else "").split() if ln.strip()])
    ctx.running = n
    if n:
        warn("실행 중인 Claude Code %d개 — 설치는 진행하지만 새 설정은 세션을 다시 열어야 적용" % n)
    else:
        ok("실행 중인 Claude Code 없음")

# ── 7. 셸 프로필 ─────────────────────────────────────────────────────
def find_profiles(ctx):
    if IS_WIN:
        out = []
        docs = os.path.join(ctx.home, "Documents")
        for exe, sub in (("pwsh", "PowerShell"), ("powershell", "WindowsPowerShell")):
            if not shutil.which(exe):
                continue
            if ctx.custom_home:
                out.append(os.path.join(docs, sub, "Microsoft.PowerShell_profile.ps1"))
                continue
            r = run([exe, "-NoProfile", "-Command", "$PROFILE"], timeout=60)
            lines = (r.stdout or "").strip().splitlines() if r and r.returncode == 0 else []
            if lines:
                out.append(lines[-1].strip())
        ctx.profiles = sorted(set(out), key=out.index)
        return ctx.profiles, "fable\\env.ps1", PS_LINE
    rc = ".zshrc" if os.path.basename(os.environ.get("SHELL", "")) == "zsh" else ".bashrc"
    ctx.profiles = [os.path.join(ctx.home, rc)]
    return ctx.profiles, "fable/env.sh", SH_LINE

def link_profiles(ctx):
    profiles, pat, line = find_profiles(ctx)
    if not profiles:
        warn("셸 프로필을 찾지 못했습니다. 프로필에 직접 추가하세요: " + line)
    for p in profiles:
        try:  # 작업 단위 경계: 프로필 하나가 실패해도 보고하고 다음 프로필·단계로 진행
            if pat in read_text(p):
                ok("프로필 연결 이미 있음: " + p)
            elif ctx.dry:
                plan("%s 에 추가: %s" % (p, line))
            else:
                append_line(p, line)  # write_bytes 가 상위 폴더를 makedirs 로 만든다
                ok("프로필 연결 추가: " + p)
        except OSError as e:
            warn("프로필 연결 실패 %s (%s: %s). Windows 라면 Defender '제어된 폴더 액세스'가 Python 의 Documents 쓰기를 막는 경우가 흔합니다 (Python 에서는 FileNotFoundError 로 보임). 해당 셸에서 직접 추가하세요: %s" % (p, type(e).__name__, e, line))

"""Fable 설치기 플랜·모델 단계 (프로필 → 설치본 plan.env 기억 → 플래그, 에이전트 frontmatter 치환).

설치기 전용 모듈이다. 설치 대상이 아니며 install_util 만 import 한다
(의존 방향: 설치기 진입점 → install_plan → install_util). 설계: docs/design-plan-profiles.md.
표준 라이브러리만 쓰고 Python 3.8 호환을 유지한다.
"""
import glob
import json
import os
import sys

from install_util import PrecheckFailed, ok, warn, plan, read_text, ask

ROLES = ("implementer", "architect", "deep-reasoner", "runner")
EFFORTS = ("low", "medium", "high", "xhigh", "max")
DEFAULT_PLAN = "max"
CANDIDATES = (("1", "Fable 5.1", "claude-fable-5-1"),  # 번호 → ID. 새 모델은 이 표와 plan-*.env 만 고친다
              ("2", "Opus 5.5", "claude-opus-5-5"),      # 후보 밖 ID(Bedrock 등)는 --model-<역할> 플래그로만
              ("3", "Sonnet 5.5", "claude-sonnet-5-5"),
              ("4", "Haiku 5.5", "claude-haiku-5-5"),
              ("5", "Haiku 4.5", "claude-haiku-4-5-20251001"))
EFFORT_CHOICES = tuple((str(i + 1), e) for i, e in enumerate(EFFORTS)) + (("6", ""),)  # 번호 → effort, "" = 모델 기본
MODEL_EFFORT = "medium"  # 빈 effort = 모델 기본. Opus·Sonnet·Haiku 5.5 의 공식 기본이라 같은 값으로 본다
DEFAULT_EFFORT_LABEL = "모델 기본 medium"

def elabel(e): return e or DEFAULT_EFFORT_LABEL  # noqa: E704
def same_effort(a, b): return (a or MODEL_EFFORT) == (b or MODEL_EFFORT)  # noqa: E704
BAD_CHARS = " \t\r\n\"'="  # plan.env 형식을 깨는 문자(거부)
TRIES = 3  # 대화형: 잘못된 입력은 이 횟수까지 묻고 기본값
CONFIRMED = "_CONFIRMED"  # values 안의 임시 키: 대화형에서 메인급 재확인을 받은 역할 목록(check 가 꺼낸다)

def mkey(role): return "FABLE_MODEL_" + role.upper().replace("-", "_")  # noqa: E704
def ekey(role): return "FABLE_EFFORT_" + role.upper().replace("-", "_")  # noqa: E704

PROFILE_KEYS = (("FABLE_PLAN", "FABLE_MAIN_LABEL", "FABLE_MAIN_EFFORT")
                + tuple(mkey(r) for r in ROLES) + tuple(ekey(r) for r in ROLES))
REQUIRED = PROFILE_KEYS[:3] + tuple(mkey(r) for r in ROLES)  # effort 는 없어도 "모델 기본"

def available(src):
    """src 의 plan-*.env 에서 플랜 이름 목록(argparse choices)."""
    names = [os.path.basename(p)[len("plan-"):-len(".env")] for p in glob.glob(os.path.join(src, "plan-*.env"))]
    return sorted(names)

def read_env(path):
    """KEY=VALUE 파싱: 키마다 첫 줄, '#' 주석·'=' 없는 줄 무시, BOM·\\r 허용. source 하지 않는다."""
    out = {}
    for line in read_text(path).splitlines():
        line = line.rstrip("\r")
        if line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out.setdefault(k, v)
    return out

def profile(src, name):
    p = os.path.join(src, "plan-%s.env" % name)
    if not os.path.isfile(p):
        raise PrecheckFailed("플랜 프로필 없음: %s (패키지 폴더 전체가 필요합니다)" % p)
    return read_env(p)

def flag_value(args, kind, role):
    return getattr(args, "%s_%s" % (kind, role.replace("-", "_")), None)

def resolve(ctx, src):
    """최종값과 역할별 출처. 우선순위: 플래그 > 대화형 선택 > 기준값(--plan 프로필 > 설치본 plan.env > max)."""
    args, installed = ctx.args, os.path.join(ctx.f, "plan.env")
    if args.plan:
        values, origin = profile(src, args.plan), "%s 기본" % args.plan
        if os.path.isfile(installed):
            plan("--plan %s 지정: 설치본 plan.env 의 이전 선택을 리셋합니다" % args.plan)
    elif os.path.isfile(installed):
        mem = read_env(installed)
        name = mem.get("FABLE_PLAN") or DEFAULT_PLAN
        if name not in available(src):
            warn("설치본 plan.env 의 플랜 '%s' 이 패키지에 없어 빈 키는 %s 기본으로 채웁니다" % (name, DEFAULT_PLAN))
            name = DEFAULT_PLAN
        values = profile(src, name)
        values.update({k: v for k, v in mem.items() if k in PROFILE_KEYS})
        custom = [r for r in mem.get("FABLE_CUSTOM", "").split(",") if r]
        origin = {r: ("설치본 plan.env (사용자 변경)" if r in custom else "설치본 plan.env (%s 기본)" % name)
                  for r in ROLES}
    else:
        name = ask_plan(ctx, src)
        values, origin = profile(src, name), "%s 기본" % name
    sources = origin if isinstance(origin, dict) else {r: origin for r in ROLES}
    skip = set()
    for role in ROLES:
        for kind in ("model", "effort"):
            if flag_value(args, kind, role) is not None:
                skip.add((kind, role))
    base, values = values, choose(ctx, values, skip)
    for role in ROLES:
        if any(values.get(k(role), "") != base.get(k(role), "") for k in (mkey, ekey)):
            sources[role] = "대화형 선택"
    for role in ROLES:
        hit = []
        m, e = flag_value(args, "model", role), flag_value(args, "effort", role)
        if m is not None:
            values[mkey(role)] = m
            hit.append("--model-" + role)
            if role in values.get(CONFIRMED, []):  # 플래그가 이기면 재확인 표시도 무효
                values[CONFIRMED].remove(role)
        if e is not None:
            values[ekey(role)] = "" if e == "default" else e
            hit.append("--effort-" + role)
        if hit:  # 한쪽만 플래그면 나머지의 기준값 출처도 남긴다
            sources[role] = ", ".join(hit if len(hit) == 2 else [sources[role]] + hit)
    return values, sources

def interactive(ctx):
    """질문할 수 있는가: --yes·dry-run 이 아니고 stdin 이 터미널(install_util.ask 의 규칙과 같다)."""
    return not (ctx.yes or ctx.dry) and bool(sys.stdin) and sys.stdin.isatty()

def _input(prompt):
    """이 모듈의 대화형 입력은 전부 여기를 지난다(테스트는 builtins.input 을 바꾼다). EOF 는 Enter."""
    try:
        return input(prompt).strip()
    except EOFError:  # Windows 는 NUL 리다이렉트도 tty 로 보인다
        print("")
        return ""

def _pick(prompt, valid, default):
    """valid(답) 이 None 이 아닐 때까지 최대 TRIES 번 묻는다. Enter 나 횟수 소진이면 default."""
    for i in range(TRIES):
        ans = _input(prompt)
        if not ans:
            return default
        got = valid(ans)
        if got is not None:
            return got
        warn("잘못된 입력 %r — %s" % (ans, "다시 입력하세요" if i < TRIES - 1 else "기본값 %s 을 씁니다" % (default or "-")))
    return default

def ask_plan(ctx, src):
    """--plan·설치본 plan.env 가 모두 없을 때의 플랜 질문(5-1 ①). 질문할 수 없으면 DEFAULT_PLAN."""
    names = available(src)
    if not interactive(ctx) or len(names) < 2:
        return DEFAULT_PLAN
    order = [DEFAULT_PLAN] + [n for n in names if n != DEFAULT_PLAN]
    num = {str(i + 1): n for i, n in enumerate(order)}
    menu = " ".join("[%d] %s%s" % (i + 1, n, " (기본)" if n == DEFAULT_PLAN else "") for i, n in enumerate(order))
    return _pick("플랜 %s: " % menu, lambda a: num.get(a) or (a.lower() if a.lower() in order else None),
                 DEFAULT_PLAN)

def main_grade(role, m):
    """implementer 가 메인급(Fable·inherit) 모델인가 — 대화형 재확인과 check 경고의 공통 조건."""
    low = m.lower()
    return role == "implementer" and ("fable" in low or low == "inherit")

def _model(role, default):
    """역할 모델 질문(5-1 ③). (ID, 재확인 여부). 후보 밖 ID 는 --model-<역할> 플래그로만 받는다.
    implementer 에 메인급을 번호로 고르면 그 자리에서 재확인, N·Enter 면 번호를 다시 묻는다."""
    ids = {n: mid for n, _, mid in CANDIDATES}
    menu = " · ".join("%s %s" % (n, label) for n, label, _ in CANDIDATES)
    cur = next(("%s %s" % (n, label) for n, label, mid in CANDIDATES if mid == default), default or "-")
    print("  %s 모델: %s  (현재 기본: %s)" % (role, menu, cur))
    while True:
        got = _pick("    번호 (Enter = 기본): ", lambda a: (ids[a],) if a in ids else None, None)
        if got is None:  # Enter·횟수 소진 = 기본값(재확인 없음, check 가 출처대로 경고)
            return default, False
        if not main_grade(role, got[0]):
            return got[0], False
        print("    [!!] 구현이 메인급 모델로 돌아 위임 효과가 사라집니다 (%s)" % got[0])
        if _input("    그래도 쓸까요? [y/N]: ").lower() == "y":
            return got[0], True

def _effort(role, default):
    """역할 effort 질문(5-1 ③). 번호 → EFFORT_CHOICES, 마지막 번호는 빈 값(모델 기본)."""
    nums = dict(EFFORT_CHOICES)
    menu = " · ".join("%s %s" % (n, e or "모델 기본(=%s)" % MODEL_EFFORT) for n, e in EFFORT_CHOICES)
    print("  %s effort: %s  (현재: %s)" % (role, menu, elabel(default)))
    return _pick("    번호 (Enter = 기본): ", nums.get, default)

def choose(ctx, base, skip):
    """대화형 선택(5-1절 ②~④). --yes·비터미널·dry-run 이면 묻지 않고 base 를 그대로 돌려준다.
    skip 은 플래그로 받은 (kind, role) — 그 질문만 건너뛴다. base 는 바꾸지 않는다."""
    if not interactive(ctx):
        return base
    values = dict(base)
    if ask(ctx, "역할별 모델을 바꾸시겠습니까?"):
        hinted = False
        for role in ROLES:
            if ("model", role) not in skip:
                values[mkey(role)], sure = _model(role, values.get(mkey(role), ""))
                if sure:  # check 가 같은 경고를 다시 내지 않도록 표시(check 가 꺼낸다)
                    values.setdefault(CONFIRMED, []).append(role)
            if ("effort", role) not in skip:
                if not hinted:
                    print("    (effort 를 높이면 같은 한도에서 호출 수가 줄어듭니다)")
                    hinted = True
                values[ekey(role)] = _effort(role, values.get(ekey(role), ""))
    return values  # 메인 /model 안내는 show() 의 플랜별 문구 하나만 낸다

# ── 스위치 단계 (docs/design-global-defaults.md C 절) ───────────────────────
REQUIRE_KEY = "FABLE_REQUIRE_FOLDER_MD"  # hooks/fable_switches.py 와 같은 값(설치기는 훅 모듈을 import 하지 않는다)
MAP_MARK = "project-map.py"
TRUE_VALUES = ("1", "true", "yes", "on")
SWITCHES = (  # (args 속성·키, fable-settings.py global 동작, 질문, 설명, 요약 이름)
    ("require_md", "require-md", "모듈 안내 파일 필수(require-md)를 전역 기본으로 켤까요?",
     "상위 폴더에 CLAUDE.md 가 없는 곳에 새 코드 파일 생성을 막습니다."
     " 프로젝트별로 fable project require-md off 로 끌 수 있습니다.", "require-md(전역)"),
    ("map_on_start", "map", "세션 시작 때 프로젝트 지도(docs/map.md)를 자동 갱신할까요?",
     "Fable 프로젝트(.claude/CLAUDE.md + docs/)에서만 동작, 최대 2초.", "map on start"))

def switch_state(data):
    """settings.json 딕셔너리 → {키: True|False|None}. None = 아직 결정 안 함.
    require-md: env 키 "1"/"0" → on/off, 키 없음 None. map: SessionStart 의 project-map 항목 있음 → on,
    없으면 require-md 키가 있을 때(이 스위치 단계를 거친 설치본)만 off, 아니면 None(구버전 설치본)."""
    env = data.get("env") if isinstance(data.get("env"), dict) else {}
    raw = env.get(REQUIRE_KEY)
    req = None if raw is None else str(raw).strip().lower() in TRUE_VALUES
    hooks = data.get("hooks") if isinstance(data.get("hooks"), dict) else {}
    start = hooks.get("SessionStart") if isinstance(hooks.get("SessionStart"), list) else []
    has = any(MAP_MARK in json.dumps(e, ensure_ascii=False) for e in start)
    return {"require_md": req, "map_on_start": True if has else (False if req is not None else None)}

def resolve_switch(flag, picked, installed):
    """(최종 bool, 출처). 우선순위: 플래그("on"/"off") > 대화형 선택 > 설치본 현재값 > 내장 on."""
    if flag is not None:
        return flag == "on", "플래그"
    if picked is not None:
        return picked, "대화형 선택"
    if installed is not None:
        return installed, "설치본 현재값"
    return True, "내장 기본"

def _yes_no(default):
    def valid(a):
        low = a.lower()
        return True if low in ("y", "yes", "예", "ㅇ") else (False if low in ("n", "no", "아니오", "ㄴ") else None)
    return valid

def ask_switches(ctx, data):
    """스위치 단계. (최종값 {키: bool}, 출처 {키: str}, 설치본 현재값 {키: bool|None}).
    --yes·비터미널·dry-run 이면 묻지 않는다(설치본 현재값 > 내장 on). 플래그로 받은 질문은 건너뛴다."""
    before = switch_state(data)
    ask_now = interactive(ctx) and any(getattr(ctx.args, k, None) is None for k, *_ in SWITCHES)
    if ask_now:
        print("[스위치]")
    values, sources = {}, {}
    for i, (key, _, question, hint, _) in enumerate(SWITCHES):
        flag, picked = getattr(ctx.args, key, None), None
        if flag is None and ask_now:
            default = True if before[key] is None else before[key]
            print("  %d) %s %s" % (i + 1, question, "[Y/n]" if default else "[y/N]"))
            print("     - " + hint)
            picked = _pick("     > ", _yes_no(default), default)
        values[key], sources[key] = resolve_switch(flag, picked, before[key])
    return values, sources, before

def switch_lines(values, sources):
    """요약 한 줄씩: `require-md(전역): ON ← 출처`."""
    return ["%s: %s ← %s" % (label, "ON" if values[key] else "off", sources[key])
            for key, _, _, _, label in SWITCHES]

def notice_lines(had_install, before, values):
    """업그레이드(설치본 있었음) + 결정 전(None) + 최종 on 일 때만 "새 동작" 알림 줄. 그 외 빈 목록."""
    if not had_install:
        return []
    out = []
    if before["require_md"] is None and values["require_md"]:
        out += ["① require-md 가 전역 ON 이 됐습니다 — 상위 폴더에 CLAUDE.md 가 없는 곳의 새 코드 파일 생성이 막힙니다",
                "② 끄기: 전역 `fable global require-md off` / 이 프로젝트만 `fable project require-md off`",
                "③ 이미 끈 적 있는 프로젝트는 키가 지워져 있으므로 `fable project require-md off` 를 한 번 더 실행하세요"]
    if before["map_on_start"] is None and values["map_on_start"]:
        out.append("④ 세션 시작 때 docs/map.md 가 자동 갱신됩니다 (끄기 `fable global map off`)")
    return out

def check(values, src):
    """5-4절 검증. 필수 키 누락·형식을 깨는 모델 값만 PrecheckFailed(쓰기 전), 나머지는 경고."""
    miss = [k for k in REQUIRED if not values.get(k)]
    if miss:
        raise PrecheckFailed("플랜 값 누락: " + ", ".join(miss))
    ids, sure = [c[2] for c in CANDIDATES], values.pop(CONFIRMED, [])
    for role in ROLES:
        m = values[mkey(role)]
        if any(ch in m for ch in BAD_CHARS):
            raise PrecheckFailed("%s 모델 값 %r 에 공백·따옴표·'='·개행은 쓸 수 없습니다" % (role, m))
        if m not in ids:
            warn("%s: '%s' 는 후보 표(%s)에 없습니다. 잘못된 ID 는 첫 요청에서 오류가 납니다."
                 " 설치 후 해당 에이전트를 한 번 호출해 확인하세요" % (role, m, ", ".join(ids)))
        low = m.lower()
        if main_grade(role, m):
            if role not in sure:  # 대화형 재확인을 받은 값은 이미 경고했다(플래그·설치본 출처만)
                warn("implementer: 구현이 메인급 모델로 돌아 위임 효과가 사라집니다 (%s)" % m)
        elif low == "inherit":
            warn("%s: inherit 은 메인 모델을 따라갑니다" % role)
        e = values.get(ekey(role), "")
        if e and e not in EFFORTS:
            warn("%s: effort '%s' 는 %s 밖이라 모델 기본으로 취급합니다" % (role, e, "|".join(EFFORTS)))
            e = ""
        values[ekey(role)] = e
    name = values["FABLE_PLAN"]
    if not os.path.isfile(os.path.join(src, "plan-%s.md" % name)):
        warn("plan-%s.md 없음: plan.md 에는 역할·모델 표만 씁니다" % name)
    try:
        ref = profile(src, name)
    except PrecheckFailed:
        ref = profile(src, DEFAULT_PLAN)
    values["FABLE_EXEC_MODEL"] = values[mkey("implementer")]
    values["FABLE_CUSTOM"] = ",".join(r for r in ROLES if values[mkey(r)] != ref.get(mkey(r))
                                      or not same_effort(values[ekey(r)], ref.get(ekey(r), "")))
    return values

def show(ctx, values, sources):
    """역할별 `모델 (effort) ← 출처` 와 메인 권장 안내."""
    say = plan if ctx.dry else ok
    say("plan: %s%s" % (values["FABLE_PLAN"],
                        " (사용자 변경: %s)" % values["FABLE_CUSTOM"] if values["FABLE_CUSTOM"] else ""))
    for role in ROLES:
        say("%-13s: %s (%s) ← %s" % (role, values[mkey(role)], elabel(values[ekey(role)]), sources[role]))
    print("     메인은 Claude Code 의 /model 에서 고릅니다 (권장: %s, effort %s. Claude Code 기본은 Opus 5.5)"
          % (values["FABLE_MAIN_LABEL"], values["FABLE_MAIN_EFFORT"]))

def _split_front(text):
    """(줄 목록, 닫는 --- 인덱스). 첫 줄이 --- 가 아니거나 닫히지 않으면 (lines, None)."""
    lines = text.split("\n")
    if not lines or lines[0].rstrip("\r") != "---":
        return lines, None
    end = next((i for i in range(1, len(lines)) if lines[i].rstrip("\r") == "---"), None)
    return lines, end

def render_agent(src_name, data, values):
    """agent-<role>.md 의 첫 --- 블록에서 model: 치환, effort: 치환·추가(닫는 --- 앞)·제거(빈 값)."""
    role = os.path.basename(src_name)[len("agent-"):-len(".md")]  # 원본은 agents/agent-<role>.md 형태
    bom = b"\xef\xbb\xbf" if data.startswith(b"\xef\xbb\xbf") else b""
    text = data[len(bom):].decode("utf-8")
    cr = "\r" if "\r\n" in text else ""
    lines, end = _split_front(text)
    if end is None:
        raise PrecheckFailed("%s 에 frontmatter(--- 블록)가 없습니다" % src_name)
    head = lines[1:end]
    mi = [i for i, ln in enumerate(head) if ln.startswith("model:")]
    if not mi:
        raise PrecheckFailed("%s frontmatter 에 model: 줄이 없습니다" % src_name)
    head[mi[0]] = "model: %s%s" % (values[mkey(role)], cr)
    eff = values.get(ekey(role), "")
    ei = [i for i, ln in enumerate(head) if ln.startswith("effort:")]
    if eff and ei:
        head[ei[0]] = "effort: %s%s" % (eff, cr)
    elif eff:
        head.append("effort: %s%s" % (eff, cr))
    elif ei:
        del head[ei[0]]
    return bom + "\n".join(lines[:1] + head + lines[end:]).encode("utf-8")

def plan_files(ctx, values, src):
    """[(f/plan.env, bytes), (f/plan.md, bytes)]. plan.md = plan-<name>.md 본문(자리표시 치환) + 역할 표."""
    name = values["FABLE_PLAN"]
    env = ["# plan.env — Fable 설치기가 생성 (런타임 단일 출처). 바꾸려면 설치기를 다시 실행하세요"]
    env += ["%s=%s" % (k, values.get(k, "")) for k in PROFILE_KEYS + ("FABLE_EXEC_MODEL", "FABLE_CUSTOM")]
    body = read_text(os.path.join(src, "plan-%s.md" % name)).replace("\r\n", "\n").rstrip("\n")
    body = body.replace("{MAIN_EFFORT}", values["FABLE_MAIN_EFFORT"]).replace("{MAIN}", values["FABLE_MAIN_LABEL"])
    table = ["### 역할별 모델 (설치기 생성 — plan %s%s)" % (
                 name, ", 사용자 변경: " + values["FABLE_CUSTOM"] if values["FABLE_CUSTOM"] else ""),
             "", "| 역할 | 모델 | effort |", "|---|---|---|",
             "| 메인 (권장, `/model` 에서 선택) | %s | %s |" % (values["FABLE_MAIN_LABEL"], values["FABLE_MAIN_EFFORT"])]
    table += ["| %s | `%s` | %s |" % (r, values[mkey(r)], elabel(values[ekey(r)])) for r in ROLES]
    md = (body + "\n\n" if body else "") + "\n".join(table) + "\n"
    return [(os.path.join(ctx.f, "plan.env"), ("\n".join(env) + "\n").encode("utf-8")),
            (os.path.join(ctx.f, "plan.md"), md.encode("utf-8"))]

def front_values(path):
    """설치된 에이전트 파일의 (model, effort). 없으면 빈 문자열."""
    lines, end = _split_front(read_text(path))
    got = {"model": "", "effort": ""}
    for ln in lines[1:end or 0]:
        k, _, v = ln.rstrip("\r").partition(":")
        if k in got and not got[k]:
            got[k] = v.strip()
    return got["model"], got["effort"]

def self_check(ctx, values, global_model):
    """plan·역할별 모델 표시와 설치본(에이전트 model:/effort:, 전역 모델, plan.env) 일치 확인."""
    mem = read_env(os.path.join(ctx.f, "plan.env"))
    (ok if mem.get("FABLE_PLAN") == values["FABLE_PLAN"] else warn)(
        "plan: %s%s" % (mem.get("FABLE_PLAN") or "? (plan.env 없음)",
                        " (사용자 변경: %s)" % values["FABLE_CUSTOM"] if values["FABLE_CUSTOM"] else ""))
    for role in ROLES:
        m, e = front_values(os.path.join(ctx.agents, role + ".md"))
        want_m, want_e = values[mkey(role)], values[ekey(role)]
        good = m == want_m and e == want_e
        (ok if good else warn)("%-13s: %s (%s)%s" % (role, m or "?", elabel(e),
                                                    "" if good else " ≠ plan %s (%s)" % (want_m, elabel(want_e))))
    want = values["FABLE_EXEC_MODEL"]
    (ok if global_model == want else warn)("CLAUDE_CODE_SUBAGENT_MODEL: %s (plan %s)" % (global_model or "없음", want))

#!/usr/bin/env bash
# Fable V5 설치 부트스트랩 (macOS / Linux / WSL)
# python3 (3.8+) 를 찾거나(없으면 OS 패키지 관리자로 설치) installer/install.py 를 실행한다. 인자는 install.py 로 그대로 넘긴다.
# 사용: bash install.sh [--dry-run] [--yes] [--uninstall] [--home <경로>] [--plan max|pro] [--model-<역할> ID] [--effort-<역할> 값]
set -euo pipefail

say() { printf '[fable-install] %s\n' "$*"; }

assume_yes=0
for a in "$@"; do
  if [ "$a" = "--yes" ]; then assume_yes=1; fi
done

have_python() {
  command -v python3 >/dev/null 2>&1 || return 1
  python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' >/dev/null 2>&1
}

confirm() {
  if [ "$assume_yes" = 1 ]; then say "$1 → 예 (--yes)"; return 0; fi
  local ans=""
  if ! read -r -p "$1 [y/N] " ans; then
    say "입력을 받을 수 없어 '아니오' 로 처리합니다. 질문 없이 진행하려면 --yes 를 붙이세요."
    return 1
  fi
  case "$ans" in y|Y|yes|YES|예|네) return 0 ;; *) return 1 ;; esac
}

install_python() {
  case "$(uname -s)" in
    Darwin)
      if ! command -v brew >/dev/null 2>&1; then
        say "Homebrew 가 없습니다. https://www.python.org/downloads/ 에서 Python 3.12 를 설치한 뒤 다시 실행하세요."
        exit 1
      fi
      confirm "Python 을 brew 로 설치할까?" || { say "설치를 취소했습니다."; exit 1; }
      say "brew install python 실행"
      brew install python
      ;;
    Linux)
      local cmd=""
      if command -v apt-get >/dev/null 2>&1; then cmd="apt-get install -y python3"
      elif command -v dnf >/dev/null 2>&1; then cmd="dnf install -y python3"
      elif command -v pacman >/dev/null 2>&1; then cmd="pacman -S --noconfirm python"
      else
        say "apt-get / dnf / pacman 을 찾지 못했습니다. 배포판의 방법으로 python3 (3.8+) 를 설치한 뒤 다시 실행하세요."
        exit 1
      fi
      confirm "python3 를 'sudo $cmd' 로 설치할까?" || { say "설치를 취소했습니다."; exit 1; }
      say "sudo $cmd 실행"
      # shellcheck disable=SC2086
      sudo $cmd
      ;;
    *)
      say "지원하지 않는 OS 입니다($(uname -s)). python3 (3.8+) 를 설치한 뒤 다시 실행하세요."
      exit 1
      ;;
  esac
}

if ! have_python; then
  say "python3 3.8 이상을 찾지 못했습니다."
  install_python
  hash -r
  if ! have_python; then
    say "python3 를 설치했지만 아직 찾을 수 없습니다. 새 터미널을 열고 다시 실행하세요."
    exit 1
  fi
fi

say "Python 사용: $(command -v python3)"
INSTALL_PY="$(cd "$(dirname "$0")" && pwd)/installer/install.py"
if [ ! -f "$INSTALL_PY" ]; then
  say "installer/install.py 를 찾을 수 없습니다. 압축을 푼 패키지 폴더 전체가 필요합니다."
  exit 1
fi
exec python3 "$INSTALL_PY" "$@"

﻿# Fable V5 설치 부트스트랩 (Windows, PowerShell 5.1 / 7)
# Python 3.8+ 을 찾거나(없으면 winget 으로 설치) installer\install.py 를 실행한다. 인자는 install.py 로 그대로 넘긴다.
# 사용: powershell -ExecutionPolicy Bypass -File install.ps1 [--dry-run] [--yes] [--uninstall] [--home <경로>] [--plan max|pro] [--model-<역할> ID] [--effort-<역할> 값]
$ErrorActionPreference = 'Stop'
$scriptArgs = @($args)
$assumeYes = $scriptArgs -contains '--yes'

function Say([string]$m) { Write-Host "[fable-install] $m" }

# 실행 파일과 앞 인자로 Python 3.8+ 인지 확인한다. 실패는 모두 '없음' 으로 취급(복구).
function Test-Python([string]$exe, [string[]]$pre) {
    $ErrorActionPreference = 'Continue'
    if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { return $false }
    try {
        $out = & $exe @pre -c "import sys; print(1 if sys.version_info >= (3, 8) else 0)" 2>$null
    } catch {
        return $false
    }
    return ($LASTEXITCODE -eq 0 -and ("$out").Trim() -eq '1')
}

# 사용할 Python 을 @{ Exe; Pre } 로 돌려준다. 없으면 $null.
function Find-Python {
    if (Test-Python 'py' @('-3')) { return @{ Exe = 'py'; Pre = @('-3') } }
    if (Test-Python 'python' @()) { return @{ Exe = 'python'; Pre = @() } }
    return $null
}

function Confirm-Yes([string]$question) {
    if ($assumeYes) { Say "$question → 예 (--yes)"; return $true }
    try {
        $ans = Read-Host "$question [y/N]"
    } catch {
        Say "입력을 받을 수 없어 '아니오' 로 처리합니다. 질문 없이 진행하려면 --yes 를 붙이세요."
        return $false
    }
    return ($ans -match '^(y|yes|예|네)$')
}

function Update-PathFromRegistry {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = (@($machine, $user) | Where-Object { $_ }) -join ';'
}

# 실행 정책 안내 (이 스크립트는 이미 실행 중이므로 계속한다)
try {
    $policy = Get-ExecutionPolicy
    if ("$policy" -eq 'Restricted') {
        Say "실행 정책이 Restricted 입니다. 다음부터는 'powershell -ExecutionPolicy Bypass -File install.ps1' 로 실행하세요. 이번 실행은 계속합니다."
    }
} catch {
    Say "실행 정책을 확인하지 못했습니다(무시하고 계속): $($_.Exception.Message)"
}

$installPy = if ($PSScriptRoot) { Join-Path $PSScriptRoot 'installer\install.py' } else { '' }
if (-not $installPy -or -not (Test-Path -LiteralPath $installPy)) {
    Say "installer\install.py 를 찾을 수 없습니다. 압축을 푼 패키지 폴더 전체가 필요합니다. 패키지 폴더 안의 install.ps1 을 파일로 실행하세요(예: powershell -ExecutionPolicy Bypass -File .\install.ps1)."
    exit 1
}

$py = Find-Python
if (-not $py) {
    Say "Python 3.8 이상을 찾지 못했습니다(py -3, python 확인)."
    if (-not (Get-Command 'winget' -ErrorAction SilentlyContinue)) {
        Say "winget 이 없습니다. https://www.python.org/downloads/ 에서 Python 3.12 를 설치한 뒤(설치 화면에서 'Add python.exe to PATH' 선택) 다시 실행하세요."
        exit 1
    }
    if (-not (Confirm-Yes "Python 3.12 를 winget 으로 설치할까?")) {
        Say "설치를 취소했습니다. Python 3.8 이상을 설치한 뒤 다시 실행하세요."
        exit 1
    }
    Say "winget install Python.Python.3.12 실행"
    & winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements
    Say "winget 종료 코드=$LASTEXITCODE"
    Update-PathFromRegistry
    $py = Find-Python
    if (-not $py) {
        Say "Python 을 설치했지만 이 창에서는 아직 보이지 않습니다. 새 PowerShell 창을 열고 다시 실행하세요."
        exit 1
    }
}

Say "Python 사용: $($py.Exe) $($py.Pre -join ' ')"
$callArgs = @($py.Pre) + @($installPy) + $scriptArgs
& $py.Exe @callArgs
exit $LASTEXITCODE

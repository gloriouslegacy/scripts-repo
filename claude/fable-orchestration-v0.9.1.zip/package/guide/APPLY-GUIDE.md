# Fable 오케스트레이션 V5 — 처음 사용자 가이드 (공통)

> **중요 — 프로젝트 안내 파일은 `.claude/CLAUDE.md` 에 둡니다.** Fable 은 프로젝트의 `.claude/CLAUDE.md` 를 기준으로 동작합니다. `/init` 은 루트 `CLAUDE.md` 에 쓰므로 실행 후 옮기세요: `mkdir -p .claude && git mv CLAUDE.md .claude/CLAUDE.md` (PowerShell: `New-Item -ItemType Directory -Force .claude; git mv CLAUDE.md .claude/CLAUDE.md`). 루트에만 있으면 Fable Orchestration 이 정상 구동되지 않습니다.

> 기준일 2026-10-10 · **Max·Pro 요금제**. 설치 때 `--plan max|pro` 로 프로필을 고르고, 역할별 모델·effort 도 바꿀 수 있습니다(1절 플랜 표). Pro 는 `--plan pro` 로 설치하고 메인은 Opus 5.5(Claude Code 기본값)를 그대로 씁니다. Pro 에서 Fable 5.1 을 메인으로 쓰면 한도가 급격히 소모되니 피하세요.
>
> 설치 명령은 운영체제별 문서를 따르세요: **macOS → `APPLY-GUIDE-macOS.md`**, **Windows → `APPLY-GUIDE-Windows.md`**, **Linux·WSL → `APPLY-GUIDE-Linux.md`**.
> 이 문서는 "무엇을, 왜" 와 설치 후 사용법을 다룹니다.

---

## 1. 이것이 무엇인가 (3분 설명)

Claude Code 에서 가장 비싼 모델(Max: **Fable 5.1**, Pro: **Opus 5.5**)을 "지휘자"로만 쓰고, 실제 코드 작성은 더 싼 모델(Max: Opus 5.5, Pro: Sonnet 5.5)에게, 단순 명령 실행은 **Haiku 5.5** 에게 맡기는 구성입니다. 지휘자는 턴마다 쌓인 맥락 전체를 다시 읽기 때문에, 지휘자가 직접 코드를 고치면 한도가 금방 바닥납니다(Max 에서 Fable 은 주간 한도의 절반까지만 쓸 수 있습니다).

"맡겨라"라고 지시문에 쓰는 것만으로는 모델이 지키지 않기 때문에, 이 구성은 **게이트**(Claude Code 의 훅)로 물리적으로 막습니다. 예를 들어 Fable 이 한 번에 코드 파일 3개를 고치려 하면 3번째는 거부되고 "implementer 에게 맡기라"는 메시지를 받습니다.

### 구성 요소

| 이름 | 역할 | 비유 |
|---|---|---|
| `fable.md` | Fable(메인)이 읽는 작업 방식 지시문 | 지휘자의 업무 수칙 |
| 에이전트 4개 | `implementer`(코드 작성), `architect`(설계), `deep-reasoner`(분석), `runner`(명령 실행) | 팀원 |
| `orchestration-gate.py` | 규칙을 물리적으로 강제하는 훅 | 출입 통제 |
| `progress-watch.py` | 백그라운드 작업이 멈췄는지 감시 | 타이머 |
| `folder-check.py` | 프로젝트 구조 점검 보고서 | 정기 점검 |
| `project-map.py` | 프로젝트 지도 `docs/map.md` 자동 생성 (9절) | 현황판 |
| `fable-settings.py` | 설정 스위치·부채 관리 | 제어판 |
| `kickoff.md` | 새 프로젝트·새 모듈을 시작하는 절차 | 착수 회의 |
| `coding-rules.md` | 구현 에이전트의 로그·예외·크기 규칙 | 코딩 표준 |
| `env.sh` / `env.ps1` | 터미널 명령 `fable …` | 리모컨 |
| `install.sh` / `install.ps1` | 자동 설치기. 위 파일을 `~/.claude/` 에 설치하고 훅·import·프로필을 연결한 뒤 켜고 자가진단 (기존 설치본 갱신·제거도 담당) | 설치 마법사 |
| `VERSION` | 릴리스 번호 한 줄(예 `0.6.0`). GitHub Releases 태그 `v0.6.0` 과 같고, `fable status` 첫 줄에 설치본 버전으로 표시. "V5" 는 세대 이름이라 따로 간다 | 버전표 |
| `plan-max.env` / `plan-pro.env` · `plan-max.md` / `plan-pro.md` | 요금제 프로필(역할별 모델·effort 기본값)과 한도 원칙 문구. 설치기가 고른 값으로 `~/.claude/fable/plan.env`·`plan.md` 를 만들고 `fable.md` 가 `plan.md` 를 import | 요금제 설정 |

### 플랜별 추천 모델·추론 강도(effort)

설치 때 `--plan max|pro` 로 플랜을 고릅니다(생략하면 이전 설치의 선택, 처음이면 `max`). 아래가 플랜별 **추천 기본값**입니다. 메인 모델은 패키지가 강제하지 못하므로 `/model` 에서 직접 고릅니다.

| 역할 | 하는 일 | Max 추천 | Pro 추천 |
|---|---|---|---|
| 메인(지휘자) | 계획·분배·검수·인터뷰. 턴마다 맥락 전체를 다시 읽음 | **Fable 5.1 · medium** | **Opus 5.5 · medium** (Claude Code 기본값) |
| `implementer` | 코드 작성·수정·테스트. 호출이 가장 많음 | **Opus 5.5 · 모델 기본(medium)** | **Sonnet 5.5 · 모델 기본(medium)** |
| `architect` | 구조안·ADR·모듈 안내 초안. 드물지만 결과가 이후 발주를 좌우 | **Opus 5.5 · high** | **Opus 5.5 · high** |
| `deep-reasoner` | 원인 불명 버그·단일 결정 분석. 좁고 깊은 질문 | **Opus 5.5 · high** | **Opus 5.5 · high** |
| `runner` | 명령 실행·로그 확인·탐색. 판단 없음 | **Haiku 5.5 · low** | **Haiku 5.5 · low** |

**왜 이렇게 나누나**
- 메인은 가장 비싼 자원입니다. 턴마다 쌓인 맥락을 다시 읽으므로 모델보다 "읽는 양"이 비용을 좌우합니다. 그래서 메인 effort 는 medium 이면 충분하고, 깊은 판단은 `deep-reasoner`/`architect` 에 넘깁니다.
- `implementer` 는 호출 수가 가장 많아 비용의 대부분을 차지합니다. Max 는 Opus 로 품질을, Pro 는 Sonnet 으로 한도를 지킵니다. effort 는 모델 기본(medium)으로 두고, 발주를 작게 나누는 쪽이 effort 를 올리는 것보다 효과가 큽니다.
- `architect`·`deep-reasoner` 는 호출이 드물지만 틀리면 그 뒤 구현 발주 여러 건이 틀어집니다. Pro 에서도 high 를 유지하는 이유입니다. 메인이 같은 Opus 라도 위임하는 목적은 "더 깊이 생각"보다 **메인 맥락을 늘리지 않는 것**입니다.
- `runner` 는 판단이 없는 실행이라 가장 싼 모델·가장 낮은 effort 입니다.

**바꾸는 방법**: 설치기를 다시 실행합니다. `--yes` 없이 실행하면 역할마다 모델 후보 5개(`1 Fable 5.1 · 2 Opus 5.5 · 3 Sonnet 5.5 · 4 Haiku 5.5 · 5 Haiku 4.5`)와 effort 6개(`1 low … 5 max · 6 모델 기본`)를 **번호로** 고릅니다(Enter 는 현재 값). 후보에 없는 ID(Bedrock·Vertex 형식, 새 모델)는 `--model-<역할> <ID>` 플래그로만 넣을 수 있고, effort 는 `--effort-<역할> low|medium|high|xhigh|max|default` 입니다. `implementer` 에 Fable 5.1 을 고르면 그 자리에서 "위임 효과가 사라집니다" 경고와 함께 `그래도 쓸까요? [y/N]` 를 묻고, N 이면 번호를 다시 고릅니다.

**상황별 조정**
| 상황 | 조정 |
|---|---|
| Pro 에서 한도에 자주 닿음 | `--effort-architect medium --effort-deep-reasoner medium` |
| 구현이 자주 재발주됨(복잡한 로직·레거시) | `--effort-implementer high` (Pro 는 `--model-implementer claude-opus-5-5` 도 고려) |
| 탐색·로그 요약이 부정확함 | `--effort-runner medium` |
| 한도 여유가 크고 설계 품질이 최우선(Max) | `--effort-architect xhigh` |

**effort 값**: `low` < `medium`(모델 기본) < `high` < `xhigh` < `max`. 높일수록 한 호출이 더 길게 생각하고, 같은 한도에서 호출 수가 줄어듭니다. 모델이 지원하지 않는 단계를 고르면 오류 없이 그 아래 지원 단계로 내려갑니다. `default` 는 effort 줄을 빼서 모델 기본으로 돌립니다.

최종값은 `~/.claude/fable/plan.env` 한 파일에 있고 `fable status` 가 `plan` 줄과 역할별 `모델 (effort)` 로 보여 줍니다. `--plan` 을 주면 프로필로 리셋, 안 주면 이전 선택이 유지됩니다.

### 용어

- **메인**: 사용자가 대화하는 Claude. 이 구성에서는 Fable 5.1.
- **서브에이전트**: 메인이 일을 맡기는 별도 Claude. 각자 자기 맥락을 갖고, 끝나면 요약만 돌려줍니다.
- **게이트 / 훅**: Claude 가 도구(파일 쓰기, 셸 실행)를 쓰기 직전에 실행되는 검사 스크립트. 거부하면 그 도구 호출은 일어나지 않습니다.
- **안내 파일**: 폴더마다 두는 `CLAUDE.md`. Claude 가 그 폴더의 파일을 건드릴 때 자동으로 읽습니다.
- **부채**: 규칙(예: 파일 500줄, 루트 코드 파일, 안내 파일 필수, 구조)을 당장 못 지키는 파일·폴더를 사용자가 승인해 종류별로 등록한 것. 등록된 동안 그 종류의 규칙만 적용되지 않습니다(8절).

---

## 2. 설치 전에 확인할 것

| 항목 | 확인 | 없을 때 |
|---|---|---|
| Claude Code **2.1.271 이상** | `claude --version` | `claude update` |
| Python 3.8 이상 | `python3 --version` (Windows 는 `py -3 --version`) | OS 가이드 참고 |
| Max 요금제 | `/model` 에서 Fable 5.1 이 보이는지 | `--plan max`(기본) |
| Pro 요금제 | `/model` 에서 Opus 5.5·Sonnet 5.5·Haiku 5.5 가 보이는지 | `--plan pro` 로 설치. 메인은 Opus 5.5 그대로 |
| 스킬 3개 비활성화(또는 삭제) | `architecture-review`, `lean-scaffolding`, `code-conventions` | 켜 두면 메인의 판단과 패키지 규칙이 충돌할 수 있음. 서브에이전트는 Skill 이 막혀 있어 영향 없음 (3절) |

Windows 는 PowerShell, macOS 는 터미널(zsh), Linux·WSL 은 터미널(bash)에서 작업합니다. "터미널에 입력"이라고 쓰인 명령은 그곳에 붙여 넣으면 됩니다.

---

## 3. 이 구성이 바꾸는 것 (설치 전에 알아 둘 규칙)

| 규칙 | 내용 | 걸리면 |
|---|---|---|
| 메인 턴당 코드 2파일 | Fable 이 한 번의 요청에서 직접 고칠 수 있는 코드 파일은 2개 | 3번째부터 거부 → 메인이 `implementer` 에게 맡김 |
| 기존 코드 Write 금지 | 50줄 넘는 기존 코드 파일을 통째로 다시 쓰지 못함 | Edit 로 부분 수정 |
| 파일 500줄 상한 | 수정 결과가 500줄을 넘으면 거부. 이미 넘은 파일은 작업당 +30줄까지 | 새 책임은 새 파일로 / 사용자가 부채 등록(종류 `줄수`, 파일·폴더) |
| 빈 catch 금지 | `catch (e) {}` 같은 빈 예외 처리가 **새로** 생기면 거부 | 복구·번역·종단 중 하나로 |
| 루트에 새 파일 금지 | 프로젝트 루트에 코드·문서를 새로 만들지 못함 (설정 파일·README 등은 허용) | 모듈 폴더 / `docs/` 로 / 사용자가 `FABLE_ROOT_ALLOW` 또는 부채 등록(종류 `루트`, 파일) |
| 문서는 `docs/` 아래 | 새 `.md` 는 `docs/`, 점 폴더, 모듈 `CLAUDE.md` 만 | `docs/` 로 |
| 안내 파일은 메인만 | 모듈 `CLAUDE.md`·`CLAUDE.local.md` 는 메인이 Write 로만, 30줄 이하. 서브에이전트는 읽기만 | — |
| 루트 안내 파일 200줄 | 루트 `.claude/CLAUDE.md`·루트 `CLAUDE.md` 를 고친 결과가 200줄(`FABLE_ROOT_NAV_LINES`)을 넘으면 거부. **줄을 늘리지 않는 수정(줄이기·같은 줄 수)은 항상 허용**. 전역 `~/.claude/CLAUDE.md` 는 대상 아님 | 규칙만 남기고 모듈 목록·파일 표는 `docs/structure.md` 로 (현황은 `docs/map.md`) |
| `docs/map.md` 보호 | 자동 생성되는 프로젝트 지도는 어떤 에이전트(메인 포함)도 Write·Edit 못 함 | 사용자가 `fable map` 으로 재생성 (9절) |
| 세션 메모 `docs/mem.md` 20줄 | 메인만, Write(전체 재작성)만, 20줄(`FABLE_MEM_LINES`) 넘으면 거부. 서브에이전트는 못 씀 | 지난 항목을 `CLAUDE.md`·ADR·`fable debt` 로 옮기고 지움 (9절) |
| 읽기 전용 에이전트 | `architect`·`deep-reasoner`·`runner` 는 파일을 못 고침(`architect` 의 `docs/` 와 스크래치 폴더만 예외) | — |
| 부채 줄 보호 | `CLAUDE.local.md`(루트 포함)의 `[부채]`·`[부채:종류]` 줄은 종류와 무관하게(알 수 없는 종류 포함) 에이전트(메인 포함)가 추가·수정·삭제 못 함 | 사용자가 터미널에서 `fable debt …` |
| `general-purpose` 금지 | 메인은 `implementer` 를 써야 함 | — |
| 안내 파일 필수 (전역 기본 ON) | 루트를 뺀 상위 어디에도 `CLAUDE.md` 가 없는 폴더에 **새** 코드 파일 생성 금지. 설치기가 전역 ON 으로 두고, 프로젝트별로 `fable project require-md off`(프로젝트 값 > 전역 값) | 상위 폴더에 `CLAUDE.md` 한 장(메인이 인터뷰 후 Write) → 하위 전부 통과 / 사용자가 부채 등록(종류 `안내`, 폴더) |

거부 메시지에는 "왜 막혔는지"와 "풀려면 어느 설정(`FABLE_…`)을 바꾸는지"가 들어 있습니다. 모든 규칙은 **스크래치·임시 폴더에는 적용되지 않습니다.**

---

## 4. 설치 후 첫 사용 (OS 가이드의 설치를 마친 뒤)

자동 설치기를 썼거나 OS 가이드 5절의 아래 세 줄을 실행했으면 **기본이 켜진 상태**입니다(지휘 모드 on, 모델 전환 IDE·앱 적용, 프로젝트 게이트 활성). 건너뛰었다면 지금 실행합니다.

```
fable on          # 지휘 모드 켜기 (새 세션부터)
fable global on   # 서브에이전트 모델 전환을 IDE·앱에도 적용
fable status      # state: on · global: ON · project: 게이트 on, 나머지 전부 [ok]
```

1. 새 Claude Code 세션을 엽니다. `/model` 에서 **Fable 5.1** 을 고르고 effort 를 **medium** 으로 둡니다.
2. 간단한 요청으로 확인합니다: "a.py 와 b.py 에 주석 한 줄씩 추가하고, c.py 도 추가해줘" → 두 파일은 Fable 이 직접, 세 번째에서 거부 메시지와 함께 `implementer` 에게 맡기는 것을 보면 정상입니다.
3. 작은 작업에서 위임이 번거로우면 `fable off` 로 끕니다(메인이 Opus 5.5 로 평소처럼 일함). 특정 프로젝트에서만 게이트를 빼려면 그 프로젝트에서 `fable project off`, 되돌릴 때 `fable project on`.

---

## 5. 설치 후 권장 명령 (OS별)

처음 설치한 뒤 한 번, 그리고 새 프로젝트를 열 때마다 실행하기를 권하는 명령입니다. `fable` 명령 자체는 모든 OS 에서 같고, 셸과 옵션 표기만 다릅니다.

### 공통

```
fable status                        # 전부 [ok] · state: on · global: ON 인지. 아니면 OS 가이드 5절
fable log 20                        # 게이트가 막은 기록. 설치 직후에는 비어 있는 것이 정상
fable check <레포 경로> --dry-run    # 기존 레포라면 걸릴 항목 미리 보기 (아무것도 바꾸지 않음, 7절)
fable map <레포 경로>                # docs/ 가 있는 레포면 프로젝트 지도 생성 (9절)
```

- 새 프로젝트의 첫 세션: `/model` 에서 Fable 5.1 · effort medium → "kickoff.md 절차를 진행해줘". 기존 레포는 7절.
- `fable on|off`, `fable global`, 훅 등록은 **새 세션부터** 적용됩니다. 바꾼 뒤에는 Claude Code 를 다시 엽니다.
- 서브에이전트가 플랜의 모델(Max: Opus 5.5 / Pro: Sonnet 5.5, `fable status` 의 역할별 줄)로 도는지 한 번 확인합니다(서브에이전트 출력의 모델 표시). 아니면 `fable global on`.

### Windows (PowerShell)

```powershell
. $PROFILE                           # 설치한 창에서 바로 fable 을 쓰려면 (새 창을 열어도 됨)
py -3 --version                      # 3.8 이상. 훅은 py 런처로 실행됨
code .                               # IDE 는 PowerShell 에서 실행 (fable global on 이면 어디서 열어도 무관)
fable check . -DryRun                # --dry-run 표기도 그대로 받음
fable project require-md off -Local  # 안내 파일 필수(전역 기본 ON)를 이 프로젝트에서만 끄기 (settings.local.json)
```

- Windows PowerShell 5.1 과 PowerShell 7 은 `$PROFILE` 이 다릅니다. 둘 다 쓰면 각각에서 `fable status` 로 확인.
- 켜고 끄기가 파일 복사 방식이라 `fable.md` 를 고쳤으면 `fable on` 을 다시 실행해야 반영됩니다.
- WSL 안의 Claude Code 는 별개 설치입니다(Linux 가이드).

### macOS (zsh)

```bash
source ~/.zshrc                      # 설치한 창에서 바로 fable 을 쓰려면
python3 --version                    # 3.8 이상. 처음이면 개발자 도구 설치 창이 뜰 수 있음
code .                               # 또는 idea . — IDE 는 터미널에서 실행 (fable global on 이면 무관)
fable check . --dry-run
fable project require-md off --local # 안내 파일 필수(전역 기본 ON)를 이 프로젝트에서만 끄기
```

- `~/.zshrc` 에 `alias claude=…` 가 있으면 `fable` 의 `claude` 래퍼와 충돌합니다. 그 줄을 지우세요.
- `active.md` 가 `fable.md` 를 가리키는 심볼릭 링크라 `fable.md` 수정이 `fable on` 상태에서 바로 반영됩니다.

### Linux · WSL (bash)

```bash
source ~/.bashrc                     # 설치한 창에서 바로 fable 을 쓰려면 (zsh 면 ~/.zshrc)
command -v claude                    # /mnt/c/… 가 나오면 Windows 쪽 실행 파일 → WSL 안에 따로 설치
python3 --version                    # 3.8 이상
fable check . --dry-run
fable project require-md off --local # 안내 파일 필수(전역 기본 ON)를 이 프로젝트에서만 끄기
```

- WSL 과 Windows 는 홈이 달라 **설치·상태·로그가 따로**입니다. 프로젝트는 WSL 파일 시스템(`~/…`)에 두는 것을 권합니다.
- 로그인 셸만 쓰는 환경에서 `~/.bashrc` 가 읽히지 않으면 `~/.bash_profile` 에서 `~/.bashrc` 를 읽게 합니다(Linux 가이드 2절).

---

## 6. 자주 쓰는 명령

```
fable on | off              켜기/끄기 (다음 세션부터)
fable status                설치·상태·플랜(역할별 모델·effort)·부채 요약
fable log [n]               게이트가 막은 기록 최근 n줄
fable global on | off       IDE·앱에도 모델 전환 적용
fable global require-md on | off   안내 파일 필수를 전역 기본으로 (설치 기본 ON, 프로젝트 값이 우선)
fable global map on | off          세션 시작 때 docs/map.md 자동 갱신 (SessionStart 훅, 설치 기본 ON)
fable project on | off      이 프로젝트에서만 게이트 끄기/켜기
fable project require-md on | off   상위에 CLAUDE.md 없는 폴더의 새 코드 파일 생성 차단을 이 프로젝트에서 켜기/끄기 (off 는 "0" 기록)
fable check [경로] [--dry-run]       구조 점검 보고서 + 끝에 docs/map.md 갱신 (--dry-run: 도입 영향 조사, 지도는 안 씀)
fable map [경로]                     프로젝트 지도 docs/map.md 재생성 (경로 생략 = 현재 폴더, 바뀐 것이 있을 때만 씀)
fable debt list                      부채 목록 (종류 열)
fable debt add <경로> "<조건>" [--kind 줄수|안내|루트|구조]   부채 등록 (종류 생략 = 줄수, 조건에 '영구' 가능)
fable debt fix <경로> [--kind …]     부채 해제 → docs/tech-debt.md 에 "고친다"
fable debt keep <경로> "<조건>" [--kind …]   조건 갱신
fable debt drop <경로> [--kind …]    해결됨
fable debt enforce on | off          모든 부채를 무시하고 상한 적용 (정리 모드)
```

Windows(PowerShell)에서는 `--local` 대신 `-Local` 입니다. `fable check` 는 `-DryRun` 과 `--dry-run`·`--json` 을 모두 받습니다.

---

## 7. 기존 프로젝트에 처음 적용하기

이미 코드가 있는 레포는 규칙과 부딪히는 곳이 있습니다(루트의 스크립트, 500줄 넘는 파일 등). 순서:

1. 터미널에서 `fable check <레포 경로> --dry-run` 을 실행합니다. **아무것도 바꾸지 않고** 걸릴 항목을 표로 보여 줍니다.
2. 항목마다 셋 중 하나를 정합니다.
   - **고친다**: 나중에 리팩터링. (Claude 에게 "kickoff 기존 레포 적용" 을 요청하면 `docs/tech-debt.md` 에 정리해 줍니다)
   - **부채**: `fable debt add <경로> "<조건>" [--kind …]` — 그 파일·폴더는 해당 종류의 규칙에서 제외됩니다(종류는 8절).
   - **허용**: 레포의 `.claude/settings.json` 에 예외를 적습니다. 예: `{ "env": { "FABLE_ROOT_ALLOW": "run_*.py,tools.ps1" } }`
3. `fable on` 으로 켜고 Claude 에게 "kickoff.md 의 기존 레포 적용 절차를 진행해줘" 라고 하면 기준선 ADR 과 모듈 안내 파일을 만들어 줍니다.

조사를 건너뛰어도 됩니다. 그 경우 작업 중 막히는 시점마다 Claude 가 그 항목만 물어봅니다.

---

## 8. 부채 운영

- 부채는 **사용자만 등록**합니다(`fable debt add`). Claude(메인 포함)가 `CLAUDE.local.md` 의 `[부채]` 줄을 추가·수정·삭제하려 하면 게이트가 막습니다. Claude 는 실행할 명령을 안내만 합니다.
- 조건이나 기한을 꼭 적습니다. `영구` 도 조건입니다. `fable check` 가 기한 지난 항목을 알려 줍니다.
- 줄 형식(`fable debt add` 가 씁니다): `- [부채:종류] 경로 — 조건 (등록 날짜)`. 종류를 뺀 `[부채]` 는 `줄수` 로 읽혀 기존 줄도 그대로 동작합니다.

  ```
  - [부채] app/legacy.py — 2026-12 분할 (등록 2026-10-09)
  - [부채:줄수] vendor/ — 외부 코드, 손대지 않음 (등록 2026-10-09)
  - [부채:안내] scripts/ — 2026-11 모듈화 전까지 (등록 2026-10-09)
  - [부채:루트] run_dev.py — 진입점, 2026-11 bin/ 으로 (등록 2026-10-09)
  - [부채:구조] legacy/deep/ — 깊이 위반, 2027-01 정리 (등록 2026-10-09)
  ```

- 종류 네 가지 (`--kind`, 생략하면 `줄수`). **한 줄은 한 종류만 면제**합니다. 같은 경로에 종류가 다른 줄을 여러 개 둘 수 있습니다.

  | 종류 | 대상 | 게이트 | `fable check` |
  |---|---|---|---|
  | `줄수` | 파일·폴더 | 500줄 상한·+30줄 면제 | 큰 파일 위반에서 제외 |
  | `안내` | 폴더만 | 안내 파일 필수(옵트인) 면제 | 안내 파일 없음 위반에서 제외 |
  | `루트` | 파일만 | 루트 코드 파일 생성 허용 (`FABLE_ROOT_ALLOW` 도 그대로 인정) | 루트 코드 파일 위반에서 제외 |
  | `구조` | 폴더만 | 영향 없음 | 구조 위반(깊이·하위 `CLAUDE.md`)에서 제외 |

- **폴더 항목**: 경로 끝이 `/` 이거나 실제 폴더면 폴더 항목이 되어 그 폴더와 하위 전체에 적용됩니다.
- **경로 기준 매칭**: 경로는 그 `CLAUDE.local.md` 가 있는 폴더 기준 상대 경로(`/` 구분)입니다. 대상의 폴더에서 위로 올라가며 **루트의 `CLAUDE.local.md` 까지** 찾습니다. 루트 파일의 부채(예: `루트` 종류)는 루트 `CLAUDE.local.md` 에 들어갑니다. 등록 위치는 대상에서 위로 올라가 안내 파일이 있는 첫 폴더의 `CLAUDE.local.md` 입니다. Windows·macOS 는 대소문자를 구분하지 않습니다. (예전 줄처럼 `/` 없는 파일 이름만 적힌 항목은 그 폴더 아래 같은 이름의 파일과 일치합니다.)
- 같은 경로에 종류가 둘 이상이면 `fable debt keep|fix|drop` 에 `--kind` 를 꼭 붙입니다(오류 메시지에 후보가 나옵니다). `fable status` 는 종류별 개수를 보여 줍니다.
- `fable check` 는 종류에 맞는 위반을 **"등록된 부채 (위반 수에서 제외)"** 절로 따로 보여 주고 합계에서 뺍니다. 알 수 없는 종류(오타 등)의 줄은 보호는 되지만 아무것도 면제하지 않고 **"알 수 없는 종류의 부채 (경고: 아무것도 면제하지 않음)"** 절에 나옵니다 → `drop` 후 `--kind` 로 다시 등록합니다.
- `fable check` 의 **구조 위반** 절은 모듈 아래 폴더의 하위 `CLAUDE.md` 와 깊이 초과(루트 기준 경로 단계 수가 `FABLE_MAX_DEPTH`, 기본 8 을 넘는 코드 폴더)를 보고합니다. 상한은 프로젝트 `.claude/settings.json` 의 `env` 에 `"FABLE_MAX_DEPTH": "10"` 처럼 바꿉니다.
- 마음이 바뀌면 `fable debt fix <경로>` → 등록이 풀리고 `docs/tech-debt.md` 에 "고친다" 로(종류 표기) 남습니다.
- 한꺼번에 정리할 때는 `fable debt enforce on` → 모든 종류의 부채가 무시되어 규칙이 전부 적용됩니다. 끝나면 `off`.
- `CLAUDE.local.md` 는 이 구성에서 **커밋**합니다(두 기기에서 같은 예외를 보기 위해). `.gitignore` 에 넣지 마세요.

---

## 9. 폴더 안내 파일 (`CLAUDE.md`)

Claude Code 는 하위 폴더의 `CLAUDE.md` 를 그 폴더의 파일을 건드릴 때 자동으로 읽습니다. 이 구성은 모듈마다 30줄짜리 안내 파일을 두어 서브에이전트가 폴더 규칙(역할, 진입점, 의존 방향, 테스트 명령)을 바로 알게 합니다.

- 작성은 **메인(Fable)만**, 사용자와 짧은 인터뷰 후 합니다. 새 프로젝트는 kickoff 때 한꺼번에, 진행 중 새 모듈은 그때 한 번.
- `CLAUDE.local.md` 는 같은 폴더의 예외·부채·임시 안내입니다. `CLAUDE.md` 뒤에 읽혀 규약을 덮어씁니다.
- 루트 규칙은 `.claude/CLAUDE.md` 에 둡니다(루트 폴더를 깨끗이 유지). **규칙만** 두고 200줄(`FABLE_ROOT_NAV_LINES`) 안에 유지합니다. 모듈 목록·파일 표는 `docs/structure.md`(손으로 씀: 왜·의존 방향)로, 현황은 `docs/map.md`(자동: 지금 무엇이 어디에)로 보냅니다.

### 프로젝트 지도 `docs/map.md`

메인이 코드를 읽지 않고도 "지금 무엇이 어디에 있는지"를 한 파일로 보게 하는 자동 생성 문서입니다. 메인은 계획 때 `docs/map.md` → `docs/structure.md` → `docs/roadmap.md` → ADR 순으로 읽습니다.

- **만드는 때**: 세션 시작·재개·compact 직후(설치기가 등록하는 `SessionStart` 훅, 조용히 실행되고 최대 `FABLE_MAP_BUDGET_SEC` 초), `fable map [경로]` 를 실행할 때, 그리고 `fable check` 끝(`--dry-run`/`-DryRun`·`--json` 이면 만들지 않음). 수동 실행의 출력은 한 줄(`갱신됨: docs/map.md` / `변경 없음` / `건너뜀: <이유>`). 자동 갱신을 끄려면 전역 `fable global map off`, 프로젝트만이면 `.claude/settings.json` `env` 에 `FABLE_MAP_ON_START=0`(이 경우 지도만 건너뛰고 세션 메모 주입은 계속됨. `fable global map off` 는 훅 자체를 빼므로 메모 주입도 멈춤).
- **내용 절**(이 순서, 없으면 "없음"): 모듈(경로·역할·테스트 명령·파일 수·안내 줄 수) / 안내 파일 없는 폴더(루트 직속) / 문서(`structure.md` 유무, 로드맵 현재 단계, ADR 번호·제목·상태, `docs/requirements/`·`docs/tech-debt.md` 수) / 부채(종류별 개수와 항목) / 크기(코드 파일 수, 500줄 초과 파일 상위 10개, 루트 안내 파일 줄 수 / 200).
- **변경이 있을 때만 씁니다.** 내용이 같으면 파일을 건드리지 않고, 생성 시각도 넣지 않아 불필요한 diff 가 생기지 않습니다.
- **`docs/` 가 없으면 건너뜁니다**(kickoff 전 레포에 폴더를 만들지 않음). 루트에 `.claude/CLAUDE.md` 가 없는 레포도 Fable 프로젝트가 아니므로 건너뜁니다.
- **시간 예산**: 폴더 걷기는 `FABLE_MAP_BUDGET_SEC`(기본 2초)까지. 넘으면 그때까지 모은 것으로 쓰고 머리말에 "불완전(시간 초과)" 를 표시합니다. 큰 레포는 프로젝트 `.claude/settings.json` 의 `env` 에 `"FABLE_MAP_BUDGET_SEC": "5"` 처럼 늘립니다.
- 직접 고치지 마세요. 게이트가 에이전트의 쓰기를 막고, 다음 생성 때 덮어씁니다. 오류는 `~/.claude/fable/map.log` 에 남습니다.

### 세션 메모 `docs/mem.md`

"직전 세션이 어디까지 했고 무엇이 열려 있는가"를 담는 **20줄짜리 인수인계 메모**입니다. Claude Code 자동 메모리나 Codex Memories 는 사용자 홈에 생기는 생성 상태라 다른 기계·팀원·서브에이전트에 보이지 않는데, 이 파일은 레포에 커밋되어 모두에게 같은 자리에서 보입니다. 참고용이지 규칙의 원천이 아닙니다(규칙은 `CLAUDE.md`, 결정은 ADR, 현황은 `docs/map.md`).

- **읽는 때**: 지도를 갱신하는 `SessionStart` 훅(`project-map.py --quiet`)이 끝에 이 파일을 내보내 **메인 대화 맥락에만** 들어갑니다(세션 시작·재개·compact 뒤). 서브에이전트에는 전달되지 않습니다 — 지난 세션의 리마인드는 지휘자 몫이고, 서브가 알아야 할 함정은 `CLAUDE.md` 에 적습니다. 루트 안내 파일에 `@docs/mem.md` import 를 넣지 마세요(서브에게도 실려 갑니다). 훅을 껐으면(`fable global map off`) 메인이 계획 전에 직접 읽습니다. 메인은 계획 때 `docs/mem.md` → `docs/map.md` → `docs/structure.md` → `docs/roadmap.md` → ADR 순으로 읽습니다.
- **쓰는 때**: 작업 단위가 끝나 `/compact` 를 제안하기 전과 세션을 마무리할 때, 메인이 **전체를 다시 씁니다**. 첫 줄 `# 세션 메모 (갱신 <날짜> · 커밋 <해시> 기준)`, 절 4개 `끝낸 것`·`열린 것`·`다음에`·`함정`(각 1~4줄). 서브에이전트는 열린 일을 반환 요약의 open issues 로 넘기고, 메인이 반영합니다.
- **게이트**: 메인만, Write 만, `FABLE_MEM_LINES`(기본 20)줄 이하. Edit 로 한 줄씩 붙이면 쌓이기만 하므로 막습니다. 넘치면 지난 항목을 `CLAUDE.md`·ADR·`fable debt` 로 옮기고 지웁니다. 설치기 설정이나 스위치는 없습니다(훅 파일에 포함).
- **처음 만들기**: 새 프로젝트는 kickoff 가 만들고, 이미 있는 프로젝트는 메인이 첫 작업 단위 끝에 `git log` 를 보고 씁니다. 혼자 쓰는 레포에서 커밋이 싫으면 `.gitignore` 에 넣어도 되지만 기본은 커밋입니다.

---

## 10. 문제가 생기면

| 증상 | 확인 |
|---|---|
| 아무것도 막히지 않음 | `fable status` 가 `state: on` 인지, 훅이 `[ok]` 인지. 새 세션을 열었는지 |
| 정상 작업이 막힘 | `fable log 5` 로 어떤 규칙인지 확인 → 메시지의 `FABLE_…` 설정으로 예외 추가, 또는 `fable project off` |
| Claude 가 `general-purpose` 를 쓰려다 막힘 | 정상. `implementer` 를 쓰게 됨 |
| 서브에이전트가 Fable 로 실행됨 | `fable global on` (IDE·앱) 또는 터미널에서 `claude` 로 실행했는지 |
| 멈춘 서브에이전트에 메시지가 안 닿음 | `TaskStop` 후 새 이름으로 재발주 (Claude 가 자동으로 함) |
| Cowork 데스크톱 세션 | 사용자 CLAUDE.md 의 외부 import 를 건너뛰므로 지시문은 적용되지 않고 게이트만 동작 |

---

## 11. 설치 후 한 번 직접 확인할 것

- `/model` 에서 플랜의 모델(Fable 5.1 · Opus 5.5 · Sonnet 5.5 · Haiku 5.5)의 정확한 모델 ID. 다르면 설치기를 `--model-<역할> <ID>` 로 다시 실행하세요(잘못된 ID 는 설치가 아니라 첫 호출에서 오류가 납니다)
- 서브에이전트가 `fable status` 의 역할별 모델로 실행되는지 (서브에이전트 출력의 모델 표시)
- 하위 폴더 `CLAUDE.md` 가 서브에이전트에서도 읽히는지

---

## 12. 변경점 (V3 → V5)

| 항목 | V3 | V5 |
|---|---|---|
| 설치 | 가이드의 명령을 손으로 복붙 | 자동 설치기 `install.sh`/`install.ps1` (`--yes`·`--dry-run`·`--uninstall`). 기존 설치본 갱신도 재실행 한 번 |
| 배포·버전 | 레포 복사 | GitHub Releases 의 `package` zip, 태그 `v0.5.0` 부터. `package/VERSION` 을 설치기·`fable status` 가 표시 |
| 요금제·모델 | Max 전용, 모델 ID 가 파일 세 곳에 고정 | `--plan max\|pro` 프로필 + 설치 때 역할별 모델·effort 선택(대화형 또는 `--model-<역할>`·`--effort-<역할>`). 단일 출처 `~/.claude/fable/plan.env`, `fable.md` 가 `plan.md` import, `fable status` 표시 (v0.6.0) |
| 구현 에이전트 | 내장 `general-purpose` | 커스텀 `implementer` (코딩 규칙 내장, 연쇄 위임·스킬 금지) |
| 에이전트 | 2개 | 4개 (`architect` 추가, 파일로 배포) |
| 지시문 범위 | 서브에이전트에도 그대로 주입됨 | 범위 선언으로 메인 전용 명시 |
| 게이트 | 자기 보호·재작성·셸·턴 한도 | + 읽기 전용 에이전트, 지시 파일 보호, 안내 파일 30줄, 500줄 상한(+30·부채), 빈 catch, 루트·문서 위치, 안내 파일 필수(옵트인), `Agent(general-purpose)` 차단 |
| 절차 | 없음 | `kickoff.md` (인터뷰 → 요구사항 → ADR → 로드맵 → 구현), 기존 레포 적용 |
| 안내 파일 | 없음 | 모듈 `CLAUDE.md`·`CLAUDE.local.md` (메인만 작성) |
| 부채 | 없음 | `fable debt …`, `docs/tech-debt.md` |
| 부채 종류 | — | `줄수`·`안내`·`루트`·`구조` (`--kind`, 폴더 항목, 경로 기준 매칭, 루트 `CLAUDE.local.md` 포함). 공통 모듈 `fable_debt.py` |
| 점검 | 없음 | `folder-check.py`, `fable check` (구조 위반: 하위 `CLAUDE.md`·깊이 `FABLE_MAX_DEPTH`, "등록된 부채" 절) |
| 프로젝트 지도·루트 안내 | 없음 | `docs/map.md` 자동 생성(`project-map.py`, `fable map`·`fable check` 끝, `FABLE_MAP_BUDGET_SEC`) + 보호, 루트 안내 파일 200줄 게이트(`FABLE_ROOT_NAV_LINES`, 줄을 늘리지 않는 수정 허용) |
| 전역 기본값 (v0.8) | 옵트인 | 안내 파일 필수가 **설치 기본 전역 ON**(`~/.claude/settings.json`, 프로젝트 `"0"` 이 우선, `fable global require-md`), `docs/map.md` 는 **SessionStart 훅**으로 자동 갱신(`fable global map`, `FABLE_MAP_ON_START`). 설치기가 두 질문을 묻고 `--yes` 도 켬. 업그레이드 사용자에게는 설치 끝에 알림 |
| 세션 메모 (v0.9) | 없음(compact 요약·자동 메모리만) | `docs/mem.md` 20줄 인수인계 메모: SessionStart 훅(`project-map.py --quiet`)이 메인 맥락에만 주입(서브에이전트 제외), 메인만 Write, `FABLE_MEM_LINES` 게이트. 작업 단위 끝·세션 마무리 때 전체 재작성 |
| 충돌 | 없음 | 서브에이전트 `conflict` 보고 → 메인이 사용자와 결정·기록 |
| 스킬 | 참조 | `architecture-review`·`lean-scaffolding`·`code-conventions` 비활성화(또는 삭제) 전제. 기준은 패키지 안에 |

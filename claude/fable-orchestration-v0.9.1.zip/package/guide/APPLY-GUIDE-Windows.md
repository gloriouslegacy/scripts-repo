# Fable 오케스트레이션 V5 — Windows 설치 가이드 (처음 사용자용)

> **중요 — 프로젝트 안내 파일은 `.claude/CLAUDE.md` 에 둡니다.** Fable 은 프로젝트의 `.claude/CLAUDE.md` 를 기준으로 동작합니다. `/init` 은 루트 `CLAUDE.md` 에 쓰므로 실행 후 프로젝트 폴더의 PowerShell 에서 옮기세요: `New-Item -ItemType Directory -Force .claude; git mv CLAUDE.md .claude/CLAUDE.md`. 루트에만 있으면 Fable Orchestration 이 정상 구동되지 않습니다.

> 기준일 2026-10-10 · **Max·Pro 요금제**(설치 때 `--plan`, 역할별 모델·effort 선택 가능 — 공통 가이드 1절). 개념·규칙·사용법은 `APPLY-GUIDE.md` 를 먼저 읽으세요. 이 문서는 PowerShell 에서의 설치와 Windows 특유의 주의점만 다룹니다.
> WSL 안에서 Claude Code 를 쓴다면 이 문서가 아니라 `APPLY-GUIDE-Linux.md` 를 따르세요.
>
> 이미 V3·V4 를 설치해 쓰고 있어도 **0절의 자동 설치를 그대로 실행**하면 됩니다(바뀐 파일 백업, 훅 항목 교체, V3 잔재 정리까지 합니다). 손으로 갱신할 때만 1절 대신 7절.

---

## 0. 준비물

시작 메뉴에서 **PowerShell** 을 엽니다(Windows PowerShell 5.1, PowerShell 7 모두 됩니다). 아래를 한 줄씩 입력해 확인합니다.

| 확인 명령 | 기대 결과 | 안 될 때 |
|---|---|---|
| `claude --version` | `2.1.271` 이상 | `claude update` |
| `py -3 --version` | `3.8` 이상 | `winget install Python.Python.3.12` 후 PowerShell 을 다시 엽니다 |
| `Get-ExecutionPolicy -Scope CurrentUser` | `RemoteSigned` 또는 `Unrestricted` | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |

배포 파일은 레포의 `package` 폴더에 있습니다. 레포를 clone 하거나, GitHub **Releases** 에서 `fable-orchestration-v<버전>.zip` 을 받아 풉니다(풀면 `package` 폴더 하나가 나옵니다). 폴더 안은 설치 위치와 같은 모양입니다: 루트에 `install.ps1`·`install.sh`·`VERSION`, 그리고 `guide\`(이 문서들)·`installer\`(설치기 본체)·`fable\`(→ `~\.claude\fable\`)·`agents\`(→ `~\.claude\agents\`)·`hooks\`(→ `~\.claude\fable\hooks\`). PowerShell 에서 그 폴더로 이동합니다(아래 경로는 예시이니 받은 위치로 바꾸세요).

```powershell
cd "$HOME\claudeOrchestration\package"   # 예시. 레포 위치에 맞게 수정
```

### 자동 설치 (권장)

```powershell
.\install.ps1            # 질문에 답하며 설치
.\install.ps1 --yes      # 질문 없이 설치 (Python·claude 가 없으면 자동 설치)
.\install.ps1 --plan pro --yes                       # Pro 요금제 프로필(구현 Sonnet 5.5). --yes 없이 실행하면 역할별 모델·effort 를 대화형으로 선택
.\install.ps1 --model-runner claude-haiku-5-5 --effort-architect medium --yes   # 역할별로 지정 (--model-<역할> ID · --effort-<역할> low|medium|high|xhigh|max|default)
.\install.ps1 --dry-run  # 무엇을 할지만 출력
```

아래 1~5절을 전부 수행하고 **켜진 상태**(`fable on`·`fable global on`)로 끝납니다. Python 이 없으면 winget 으로, Claude Code 가 없거나 2.1.271 미만이면 공식 설치 스크립트·`claude update` 로 확보합니다. 기존 설치본이 있으면 바뀌는 파일만 `~\.claude\fable\bak-<시각>\` 에 백업하고, `settings.json` 의 기존 게이트 항목은 교체합니다(`settings.json.bak`). 실행 중인 Claude Code 세션은 종료하지 않고 개수만 알려 주며, 새 설정은 세션을 다시 열어야 적용됩니다. 끝나면 **새 PowerShell 창**에서 `fable status`. 제거는 `.\install.ps1 --uninstall`.

1~5절은 설치기가 하는 일을 손으로 하는 절차입니다. 설치기가 실패했거나 단계를 직접 보고 싶을 때만 따라 하세요.

> Windows 에서는 Git Bash 로 `install.sh` 를 쓰지 마세요. Git Bash 의 `python3` 는 Microsoft Store 스텁이라 실패합니다. 실행 정책 때문에 막히면 `powershell -ExecutionPolicy Bypass -File .\install.ps1`.

### macOS·Linux 와 다른 점 (알아 두기)

| 항목 | macOS/Linux | Windows |
|---|---|---|
| 켜고 끄기 | 심볼릭 링크 | **파일 복사** (관리자 권한·개발자 모드 불필요). 그래서 `fable.md` 를 고치면 `fable on` 을 다시 해야 반영 |
| 에이전트 설치 | 복사 | 복사 |
| 훅 실행 | `python3 "$HOME/…"` | `py` + 인자 방식 (Git Bash 가 있든 없든 동일) |
| 차단 대상 셸 | Bash | Bash + **PowerShell 도구** |
| 옵션 표기 | `--dry-run`, `--local` | `-DryRun`, `-Local` (`fable check` 는 `--dry-run`·`--json` 도 그대로 받음) |

---

## 1. 새로 설치 (복사해서 한 번에 실행)

```powershell
$C = Join-Path $HOME '.claude'
$F = Join-Path $C 'fable'
New-Item -ItemType Directory -Force -Path "$F\hooks", "$F\state", "$C\agents" | Out-Null

Copy-Item .\fable\fable.md, .\fable\kickoff.md, .\fable\coding-rules.md, .\fable\env.ps1, .\VERSION $F -Force
Copy-Item .\hooks\orchestration-gate.py, .\hooks\gate_common.py, .\hooks\fable_debt.py, .\hooks\fable_switches.py, .\hooks\fable-settings.py, .\hooks\progress-watch.py, .\hooks\folder-check.py, .\hooks\project-map.py "$F\hooks" -Force
foreach ($a in 'implementer', 'architect', 'deep-reasoner', 'runner') { Copy-Item ".\agents\agent-$a.md" "$C\agents\$a.md" -Force }

# 켜고 끄는 스위치 파일 (BOM 없는 빈 파일)
function Write-Utf8($Path, $Text) { [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding $false)) }
Write-Utf8 "$F\empty.md"  ''
Write-Utf8 "$F\active.md" ''
Set-Content -Path "$C\.fable-state" -Value 'off' -NoNewline -Encoding ascii
```

> 에이전트 파일은 복사본입니다. 나중에 `agent-*.md` 를 고치면 `foreach` 줄을 다시 실행하세요.

---

## 2. PowerShell 명령 `fable` 연결

```powershell
if (-not (Test-Path $PROFILE)) { New-Item -ItemType File -Force -Path $PROFILE | Out-Null }
if (-not (Select-String -Path $PROFILE -Pattern 'fable\env.ps1' -SimpleMatch -Quiet)) {
  Add-Content -Path $PROFILE -Value "`n. `"`$HOME\.claude\fable\env.ps1`""
}
. $PROFILE
```

> Windows PowerShell 5.1 과 PowerShell 7 은 `$PROFILE` 이 다릅니다. 둘 다 쓰면 각각에서 한 번씩 실행하세요.

---

## 3. Claude 가 지시문을 읽게 하기

```powershell
$M = "$C\CLAUDE.md"
if (-not ((Test-Path $M) -and (Select-String -Path $M -Pattern 'fable/active.md' -SimpleMatch -Quiet))) {
  Add-Content -Path $M -Value "`n@~/.claude/fable/active.md" -Encoding utf8
}
```

> import 가 인식되지 않으면 절대 경로(슬래시)로 바꿉니다: `@C:/Users/<사용자>/.claude/fable/active.md`

---

## 4. 게이트(훅) 등록 (기존 설정을 보존하며 자동 병합)

```powershell
$S = "$C\settings.json"
$gate = ("$F\hooks\orchestration-gate.py") -replace '\\', '/'
$cfg = if (Test-Path $S) { Get-Content $S -Raw -Encoding utf8 | ConvertFrom-Json } else { [pscustomobject]@{} }
if (-not $cfg.PSObject.Properties['hooks']) { $cfg | Add-Member hooks ([pscustomobject]@{}) }
if (-not $cfg.hooks.PSObject.Properties['PreToolUse']) { $cfg.hooks | Add-Member PreToolUse @() }
$entry = [pscustomobject]@{
  matcher = 'Write|Edit|MultiEdit|NotebookEdit|Bash|PowerShell|Agent'
  hooks   = @([pscustomobject]@{ type = 'command'; command = 'py'; args = @('-3', $gate); timeout = 10 })
}
$cfg.hooks.PreToolUse = @($cfg.hooks.PreToolUse | Where-Object { ($_ | ConvertTo-Json -Depth 10) -notmatch 'orchestration-gate' }) + $entry
Copy-Item $S "$S.bak" -ErrorAction SilentlyContinue
Write-Utf8 $S ($cfg | ConvertTo-Json -Depth 20)
```

> `py` 런처가 없으면 `command = 'python'`, `args = @($gate)` 로 바꿉니다.

### 4-1. 전역 기본값 — 지도 자동 갱신 훅·안내 파일 필수 (설치기는 기본 ON)

설치기 대신 수동 설치했으면 두 줄로 같은 상태를 만듭니다. `SessionStart` 훅(`startup|resume|compact`, `project-map.py . --quiet`)과 `env.FABLE_REQUIRE_FOLDER_MD="1"` 이 `settings.json` 에 들어갑니다.

```powershell
py -3 "$F\hooks\fable-settings.py" global map on
py -3 "$F\hooks\fable-settings.py" global require-md on
```

---

## 5. 확인

새 PowerShell 창을 열고:

```powershell
fable status
```

모든 줄이 `[ok]` 면 파일 설치는 끝입니다. `[!!]` 가 있으면 그 항목의 절로 돌아가세요. 이어서 켭니다:

```powershell
fable on          # 지휘 모드 켜기 (새 세션부터)
fable global on   # 서브에이전트 모델 전환을 IDE·앱·cmd·Git Bash 에도 적용
fable status      # state: on · global: ON · project: 게이트 on 이면 정상
```

`fable project on` 은 따로 실행하지 않습니다. 프로젝트 게이트는 기본이 켜진 상태이고, `fable project off` 로 껐던 프로젝트를 되돌릴 때만 씁니다.

새 Claude Code 세션을 열고 `/model` 에서 **Fable 5.1**, effort **medium** 을 고릅니다. 첫 사용 확인은 공통 가이드 4절.

---

## 6. Windows 에서 주의할 점

**시작 메뉴·IDE 에서 실행한 Claude Code 에는 모델 전환이 적용되지 않습니다.** `fable` 의 모델 전환은 PowerShell 에서 실행한 `claude` 에만 붙습니다(cmd, Git Bash, VS Code 확장, 데스크톱 앱은 해당 없음). 게이트와 지시문은 어디서든 동작합니다. 해결:

- PowerShell 에서 `code .` 로 VS Code 를 실행하거나,
- **`fable global on`** 이 실행돼 있으면 됩니다(5절에서 이미 실행). `~\.claude\settings.json` 에 기록되어 IDE·앱·cmd·Git Bash 모두에 적용됩니다. `fable status` 의 global 항목으로 확인.

**게이트 설정값은 `settings.json` 의 `env` 로**: 훅이 셸을 거치지 않아 명령 앞에 변수를 붙일 수 없습니다. 프로젝트별 조정은 그 프로젝트의 `.claude\settings.json` 에 넣습니다. 예:

```json
{ "env": { "FABLE_MAX_LINES": "700", "FABLE_ROOT_ALLOW": "run_*.py,tools.ps1" } }
```

**백신·EDR**: 도구 호출마다 `py` 가 실행됩니다. 느려서 10초를 넘기면 통과(fail-open)되므로, `fable log` 에 기록이 없는데 차단이 안 되면 4절의 `timeout` 을 30 으로 올리세요.

**한글**: 게이트와 스크립트는 입출력을 UTF-8 로 고정해 cp949 콘솔에서도 안전합니다. `env.ps1` 은 BOM 포함 UTF-8 로 저장돼 있으니 다른 편집기로 저장할 때 인코딩을 유지하세요.

---

## 7. 기존 설치본(V3) 갱신 (손으로 할 때)

손 절차는 **Max 기본값**(`agent-*.md` 의 `model:` 그대로)만 설치합니다. Pro 프로필이나 역할별 모델·effort 선택, `plan.env`·`plan.md` 생성은 자동 설치기만 합니다.

**권장은 0절의 `.\install.ps1` 재실행**입니다. 바뀐 파일 백업, 훅 항목 교체(matcher 에 `Agent` 추가), V3 의 `general-purpose.md` 삭제, `fable on` 까지 한 번에 끝납니다. 아래는 같은 일을 손으로 하는 절차입니다. 레포의 `package` 폴더에서(0절의 `cd` 와 같음):

```powershell
$C = Join-Path $HOME '.claude'; $F = Join-Path $C 'fable'
function Write-Utf8($Path, $Text) { [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding $false)) }
Copy-Item "$F\active.md" "$F\active.md.bak-v3" -Force -ErrorAction SilentlyContinue   # 직접 고친 내용 백업
Copy-Item .\fable\fable.md, .\fable\kickoff.md, .\fable\coding-rules.md, .\fable\env.ps1, .\VERSION $F -Force
Copy-Item .\hooks\orchestration-gate.py, .\hooks\gate_common.py, .\hooks\fable_debt.py, .\hooks\fable_switches.py, .\hooks\fable-settings.py, .\hooks\progress-watch.py, .\hooks\folder-check.py, .\hooks\project-map.py "$F\hooks" -Force
foreach ($a in 'implementer', 'architect', 'deep-reasoner', 'runner') { Copy-Item ".\agents\agent-$a.md" "$C\agents\$a.md" -Force }
Remove-Item "$C\agents\general-purpose.md" -Force -ErrorAction SilentlyContinue   # V3 의 커스텀 general-purpose 제거
```

그다음 **4절의 훅 등록을 다시 실행**합니다(matcher 에 `Agent` 가 추가됨. 같은 항목을 교체하므로 중복되지 않습니다). 마지막으로:

```powershell
. $PROFILE
fable on          # active.md 를 새 fable.md 로 교체
fable status
```

> 앞으로 지시문은 `active.md` 가 아니라 **`fable.md` 를 고친 뒤 `fable on`** 으로 반영하세요. Windows 에서는 켜고 끌 때 `active.md` 가 덮어써집니다.

---

## 8. 제거

자동 설치로 넣었으면 `.\install.ps1 --uninstall`. 손으로 할 때:

```powershell
fable global off; fable off
# ~\.claude\CLAUDE.md 에서 '@~/.claude/fable/active.md' 줄 삭제
# ~\.claude\settings.json 에서 orchestration-gate 훅 항목 삭제 (settings.json.bak 참고)
Remove-Item "$HOME\.claude\agents\implementer.md", "$HOME\.claude\agents\architect.md", "$HOME\.claude\agents\deep-reasoner.md", "$HOME\.claude\agents\runner.md" -ErrorAction SilentlyContinue
# $PROFILE 에서 '. "$HOME\.claude\fable\env.ps1"' 줄 삭제
Remove-Item -Recurse -Force "$HOME\.claude\fable", "$HOME\.claude\.fable-state"
```

---

## 9. 문제 해결

| 증상 | 조치 |
|---|---|
| "스크립트를 실행할 수 없습니다" | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| `fable` 을 찾을 수 없음 | `. $PROFILE` 또는 새 PowerShell 창. 5.1/7 중 어느 쪽 프로필에 넣었는지 확인 |
| 설치기 7단계 `[!!] 프로필 연결 실패 … FileNotFoundError` (Documents 아래 경로) | Windows Defender **제어된 폴더 액세스**가 Python 의 `Documents` 쓰기를 막는 것(`Get-MpPreference` 의 `EnableControlledFolderAccess` 가 1). 설치는 계속 진행되니 해당 셸에서 직접 한 줄 추가: `Add-Content $PROFILE '. "$HOME\.claude\fable\env.ps1"'`. 또는 Windows 보안 → 랜섬웨어 방지 → "제어된 폴더 액세스를 통해 앱 허용"에 `python.exe` 등록 후 재실행 |
| `fable status` 에 `[!!] claude …` | `claude update` 로 2.1.271 이상 |
| 차단이 전혀 안 됨 | `fable status` 의 state/hook 확인, `py -3 --version`, 새 세션인지 |
| `gate.log` 에 `WARN prompt_id 없음` | Claude Code 가 오래됨. `claude update` |
| 서브에이전트가 Fable 로 돎 | 6절 (`fable global on`) |
| 한글이 깨짐 | `env.ps1` 을 BOM 포함 UTF-8 로 다시 저장 |

# Fable 오케스트레이션 V5 — macOS 설치 가이드 (처음 사용자용)

> **중요 — 프로젝트 안내 파일은 `.claude/CLAUDE.md` 에 둡니다.** Fable 은 프로젝트의 `.claude/CLAUDE.md` 를 기준으로 동작합니다. `/init` 은 루트 `CLAUDE.md` 에 쓰므로 실행 후 프로젝트 폴더에서 옮기세요: `mkdir -p .claude && git mv CLAUDE.md .claude/CLAUDE.md`. 루트에만 있으면 Fable Orchestration 이 정상 구동되지 않습니다.

> 기준일 2026-10-10 · **Max·Pro 요금제**(설치 때 `--plan`, 역할별 모델·effort 선택 가능 — 공통 가이드 1절). 개념·규칙·사용법은 `APPLY-GUIDE.md` 를 먼저 읽으세요. 이 문서는 설치와 macOS 특유의 주의점만 다룹니다.
>
> 이미 V3·V4 를 설치해 쓰고 있어도 **0절의 자동 설치를 그대로 실행**하면 됩니다(바뀐 파일 백업, 훅 항목 교체, V3 잔재 정리까지 합니다). 손으로 갱신할 때만 1절 대신 7절.
>
> **Windows 에서 쓰던 설치본을 옮기는 경우에도** Windows 의 `~/.claude/fable` 폴더를 복사하지 말고 이 배포 폴더로 새로 설치하세요. Windows 의 `settings.json`(훅이 `py` + `C:/…` 경로), `env.ps1`, `state/`, `gate.log`, `.fable-state` 는 맥에서 쓸 수 없습니다.

---

## 0. 준비물

터미널을 엽니다(Spotlight 에서 "터미널" 검색). 아래를 한 줄씩 입력해 확인합니다.

| 확인 명령 | 기대 결과 | 안 될 때 |
|---|---|---|
| `claude --version` | `2.1.271` 이상 | `claude update` |
| `python3 --version` | `3.8` 이상 | 처음이면 "명령어 라인 개발자 도구 설치" 창이 뜹니다. 설치 후 다시 실행. 또는 `brew install python` |
| `echo $SHELL` | `/bin/zsh` | bash 면 아래에서 `~/.zshrc` 를 `~/.bash_profile` 로 바꿔 읽으세요 |

배포 파일은 레포의 `package` 폴더에 있습니다. 레포를 clone 하거나, GitHub **Releases** 에서 `fable-orchestration-v<버전>.zip` 을 받아 풉니다(풀면 `package` 폴더 하나가 나옵니다). 폴더 안은 설치 위치와 같은 모양입니다: 루트에 `install.sh`·`install.ps1`·`VERSION`, 그리고 `guide/`(이 문서들)·`installer/`(설치기 본체)·`fable/`(→ `~/.claude/fable/`)·`agents/`(→ `~/.claude/agents/`)·`hooks/`(→ `~/.claude/fable/hooks/`). 아래 `SRC` 는 예시이니 받은 위치로 바꾸세요.

### 자동 설치 (권장)

```bash
bash ~/claudeOrchestration/package/install.sh            # 질문에 답하며 설치 (경로는 예시)
bash ~/claudeOrchestration/package/install.sh --yes      # 질문 없이 설치
bash ~/claudeOrchestration/package/install.sh --plan pro --yes   # Pro 요금제 프로필(구현 Sonnet 5.5). --yes 없이 실행하면 역할별 모델·effort 를 대화형으로 선택
bash ~/claudeOrchestration/package/install.sh --model-runner claude-haiku-5-5 --effort-architect medium --yes   # 역할별 지정 (--model-<역할> ID · --effort-<역할> low|medium|high|xhigh|max|default)
bash ~/claudeOrchestration/package/install.sh --dry-run  # 무엇을 할지만 출력
```

아래 1~5절을 전부 수행하고 **켜진 상태**(`fable on`·`fable global on`)로 끝납니다. `python3` 가 없으면 Homebrew 로, Claude Code 가 없거나 2.1.271 미만이면 공식 설치 스크립트·`claude update` 로 확보합니다. 기존 설치본이 있으면 바뀌는 파일만 `~/.claude/fable/bak-<시각>/` 에 백업하고, `settings.json` 의 기존 게이트 항목은 교체합니다(`settings.json.bak`). 실행 중인 Claude Code 세션은 종료하지 않고 개수만 알려 주며, 새 설정은 세션을 다시 열어야 적용됩니다. 끝나면 **새 터미널**에서 `fable status`. 제거는 `--uninstall`.

1~5절은 설치기가 하는 일을 손으로 하는 절차입니다. 설치기가 실패했거나 단계를 직접 보고 싶을 때만 따라 하세요.

---

## 1. 파일 설치 (복사해서 한 번에 실행)

```bash
SRC=~/claudeOrchestration/package   # 예시. 레포 위치에 맞게 수정
F=~/.claude/fable

mkdir -p $F/hooks $F/state ~/.claude/agents
cp "$SRC"/fable/fable.md "$SRC"/fable/kickoff.md "$SRC"/fable/coding-rules.md "$SRC"/fable/env.sh "$SRC"/VERSION $F/
cp "$SRC"/hooks/orchestration-gate.py "$SRC"/hooks/gate_common.py "$SRC"/hooks/fable_debt.py "$SRC"/hooks/fable_switches.py "$SRC"/hooks/fable-settings.py "$SRC"/hooks/progress-watch.py "$SRC"/hooks/folder-check.py "$SRC"/hooks/project-map.py $F/hooks/
chmod +x $F/hooks/*.py
for a in implementer architect deep-reasoner runner; do cp "$SRC"/agents/agent-$a.md ~/.claude/agents/$a.md; done

# Windows 에서 받은 파일이면 줄바꿈(CRLF)·BOM 정리 (이미 정상이면 변화 없음)
for f in $F/fable.md $F/kickoff.md $F/coding-rules.md $F/env.sh $F/hooks/*.py ~/.claude/agents/*.md; do
  sed -i '' -e $'s/\r$//' -e $'1s/^\xEF\xBB\xBF//' "$f"
done

# 켜고 끄는 스위치 파일
: > $F/empty.md
echo off > ~/.claude/.fable-state
ln -sfn $F/empty.md $F/active.md
```

> 에이전트 파일은 복사본입니다. 나중에 `agent-*.md` 를 고치면 위 `for a in …` 줄을 다시 실행하세요.

---

## 2. 터미널 명령 `fable` 연결

```bash
grep -q 'fable/env.sh' ~/.zshrc 2>/dev/null || echo '[ -f "$HOME/.claude/fable/env.sh" ] && source "$HOME/.claude/fable/env.sh"' >> ~/.zshrc
source ~/.zshrc
```

> `~/.zshrc` 에 `alias claude=…` 가 이미 있으면 함수 정의와 충돌합니다. 그 줄을 지우거나, 위 줄보다 앞에 `unalias claude 2>/dev/null` 을 넣으세요.

---

## 3. Claude 가 지시문을 읽게 하기

```bash
grep -q 'fable/active.md' ~/.claude/CLAUDE.md 2>/dev/null || echo '@~/.claude/fable/active.md' >> ~/.claude/CLAUDE.md
```

---

## 4. 게이트(훅) 등록

`~/.claude/settings.json` 에 아래 내용이 들어가야 합니다. 파일이 없으면 그대로 만들고, 이미 있으면 `hooks.PreToolUse` 배열에 항목을 추가합니다.

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit|NotebookEdit|Bash|Agent",
        "hooks": [
          { "type": "command", "command": "python3 \"$HOME/.claude/fable/hooks/orchestration-gate.py\"", "timeout": 10 }
        ]
      }
    ]
  }
}
```

손으로 고치기 번거로우면 `jq` 로 자동 병합할 수 있습니다(`brew install jq` 가 필요).

```bash
f=~/.claude/settings.json; [ -f "$f" ] || echo '{}' > "$f"
jq '(.hooks.PreToolUse // []) as $h | .hooks.PreToolUse = ([$h[] | select((.hooks[0].command // "") | test("orchestration-gate") | not)] + [{"matcher":"Write|Edit|MultiEdit|NotebookEdit|Bash|Agent","hooks":[{"type":"command","command":"python3 \"$HOME/.claude/fable/hooks/orchestration-gate.py\"","timeout":10}]}])' "$f" > "$f.tmp" && mv "$f.tmp" "$f"
```

### 4-1. 전역 기본값 — 지도 자동 갱신 훅·안내 파일 필수 (설치기는 기본 ON)

설치기 대신 수동 설치했으면 두 줄로 같은 상태를 만듭니다. `SessionStart` 훅(`startup|resume|compact`, `project-map.py . --quiet`)과 `env.FABLE_REQUIRE_FOLDER_MD="1"` 이 `~/.claude/settings.json` 에 들어갑니다.

```bash
python3 ~/.claude/fable/hooks/fable-settings.py global map on
python3 ~/.claude/fable/hooks/fable-settings.py global require-md on
```

---

## 5. 확인

```bash
fable status
```

모든 줄이 `[ok]` 면 파일 설치는 끝입니다. `[!!]` 가 있으면 그 항목의 절로 돌아가세요. 이어서 켭니다:

```bash
fable on          # 지휘 모드 켜기 (새 세션부터)
fable global on   # 서브에이전트 모델 전환을 IDE·앱에도 적용
fable status      # state: on · global: ON · project: 게이트 on 이면 정상
```

`fable project on` 은 따로 실행하지 않습니다. 프로젝트 게이트는 기본이 켜진 상태이고, `fable project off` 로 껐던 프로젝트를 되돌릴 때만 씁니다.

새 Claude Code 세션을 열고 `/model` 에서 **Fable 5.1**, effort **medium** 을 고릅니다. 첫 사용 확인은 공통 가이드 4절.

---

## 6. macOS 에서 주의할 점

**Dock·Spotlight 로 실행한 IDE·데스크톱 앱에는 모델 전환이 적용되지 않습니다.** `fable` 명령의 모델 전환은 터미널에서 실행한 `claude` 에만 붙습니다. 게이트와 지시문은 어디서든 동작하고, 영향을 받는 것은 "서브에이전트가 플랜의 구현 모델(`fable status` 의 역할별 줄)로 실행되는지" 하나입니다. 해결:

- 터미널에서 `code .` / `idea .` 로 IDE 를 실행하거나,
- **`fable global on`** 이 실행돼 있으면 됩니다(5절에서 이미 실행). `~/.claude/settings.json` 에 기록되어 IDE·앱에도 적용됩니다. (`fable off` 여도 서브에이전트 모델은 유지되지만, 기본 모드의 메인도 Opus 5.5 라 손해는 없습니다.)

**대소문자**: macOS 파일 시스템은 대소문자를 구분하지 않습니다. 게이트는 `App.py` 와 `app.py` 를 같은 파일로 셉니다.

**zsh 와 `$HOME`**: Claude 에게 주는 경로는 `$HOME/.claude/fable/…` 형태입니다. `~` 는 Claude 의 도구가 해석하지 못할 수 있습니다.

---

## 7. 기존 설치본(V3) 갱신 (손으로 할 때)

손 절차는 **Max 기본값**(`agent-*.md` 의 `model:` 그대로)만 설치합니다. Pro 프로필이나 역할별 모델·effort 선택, `plan.env`·`plan.md` 생성은 자동 설치기만 합니다.

**권장은 0절의 `install.sh` 재실행**입니다. 바뀐 파일 백업, 훅 항목 교체(matcher 에 `Agent` 추가), V3 의 `general-purpose.md` 삭제, `fable on` 까지 한 번에 끝납니다. 아래는 같은 일을 손으로 하는 절차입니다.

```bash
SRC=~/claudeOrchestration/package; F=~/.claude/fable   # 예시. 레포 위치에 맞게 수정
cp "$SRC"/fable/fable.md "$SRC"/fable/kickoff.md "$SRC"/fable/coding-rules.md "$SRC"/fable/env.sh "$SRC"/VERSION $F/
cp "$SRC"/hooks/orchestration-gate.py "$SRC"/hooks/gate_common.py "$SRC"/hooks/fable_debt.py "$SRC"/hooks/fable_switches.py "$SRC"/hooks/fable-settings.py "$SRC"/hooks/progress-watch.py "$SRC"/hooks/folder-check.py "$SRC"/hooks/project-map.py $F/hooks/
chmod +x $F/hooks/*.py
for a in implementer architect deep-reasoner runner; do cp "$SRC"/agents/agent-$a.md ~/.claude/agents/$a.md; done
rm -f ~/.claude/agents/general-purpose.md 2>/dev/null
# Windows 에서 받은 파일이면 줄바꿈(CRLF)·BOM 정리 (이미 정상이면 변화 없음)
for f in $F/fable.md $F/kickoff.md $F/coding-rules.md $F/env.sh $F/hooks/*.py ~/.claude/agents/*.md; do
  sed -i '' -e $'s/\r$//' -e $'1s/^\xEF\xBB\xBF//' "$f"
done
source ~/.zshrc
```

그리고 4절의 훅 등록을 다시 합니다(matcher 에 `Agent` 가 추가됨). `active.md` 는 `fable.md` 를 가리키는 심볼릭 링크라 `fable on` 상태면 바로 반영됩니다. `fable status` 로 확인.

---

## 8. 제거

자동 설치로 넣었으면 `bash <패키지 경로>/install.sh --uninstall`. 손으로 할 때:

```bash
fable global off; fable off
# ~/.claude/CLAUDE.md 에서 '@~/.claude/fable/active.md' 줄 삭제
# ~/.claude/settings.json 에서 orchestration-gate.py 훅 항목 삭제
rm -f ~/.claude/agents/{implementer,architect,deep-reasoner,runner}.md
# ~/.zshrc 에서 'source "$HOME/.claude/fable/env.sh"' 줄 삭제
rm -rf ~/.claude/fable ~/.claude/.fable-state
```

프로젝트 안에 만든 `docs/`, 모듈 `CLAUDE.md`, `CLAUDE.local.md`, `.claude/settings.json` 의 `FABLE_…` 항목은 그대로 두어도 해가 없습니다.

---

## 9. 문제 해결

| 증상 | 조치 |
|---|---|
| `fable: command not found` | `source ~/.zshrc` 또는 새 터미널 |
| `python3` 실행 시 개발자 도구 설치 창 | 설치 후 다시 시도. 설치 전에는 게이트가 동작하지 않습니다 |
| `fable status` 에 `[!!] claude …` | `claude update` 로 2.1.271 이상 |
| 차단이 전혀 안 됨 | `fable status` 의 state/hook 확인, 새 세션인지 확인 |
| `gate.log` 에 `ERROR` | `fable log 20` 메시지를 확인해 공유 |
| 서브에이전트가 Fable 로 돎 | 6절 (`fable global on`) |

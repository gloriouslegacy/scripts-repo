"""gate_common.py — orchestration-gate.py 공통부 (고정 설정·정규식·공통 유틸).

orchestration-gate.py 가 같은 폴더에서 import 한다. 규칙 A~F 와 진입점은 게이트에 있다.
Python 3.8 호환, 표준 라이브러리만(+ 같은 폴더의 fable_debt).
"""
import json
import os
import re
import sys
import tempfile
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
try:
    import fable_debt  # 같은 폴더. 부채 줄 파싱·경로 매칭(docs/design-debt-kinds.md)
    _DEBT_IMPORT_ERR = None
except Exception as _e:  # 복구: 모듈이 없거나 깨져도 게이트는 "부채 없음"으로 동작(fail-open), 첫 사용 때 WARN
    fable_debt = None
    _DEBT_IMPORT_ERR = "%s: %s" % (type(_e).__name__, _e)

# ── 고정 설정 ─────────────────────────────────────────────────────────
HOME = os.path.expanduser("~")
FABLE_HOME = os.path.join(HOME, ".claude", "fable")
STATE_FILE = os.path.join(HOME, ".claude", ".fable-state")
COUNTER_DIR = os.path.join(FABLE_HOME, "state")
LOG_FILE = os.path.join(FABLE_HOME, "gate.log")
LOG_MAX_BYTES = 1_000_000

CODE_EXTS = (
    ".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".vue", ".svelte",
    ".java", ".kt", ".kts", ".scala", ".go", ".rs", ".c", ".h", ".cc", ".cpp",
    ".hpp", ".cs", ".swift", ".m", ".mm", ".rb", ".php", ".lua", ".dart",
    ".sh", ".bash", ".zsh", ".sql", ".r", ".jl", ".ex", ".exs", ".erl",
    ".clj", ".hs", ".ml", ".fs", ".pl", ".pm", ".ipynb",
    ".html", ".css", ".scss", ".sass", ".less", ".ps1", ".psm1", ".bat", ".cmd",
)
SHELL_TOOLS = {"Bash", "PowerShell"}
EDIT_TOOLS = {"Write", "Edit", "MultiEdit", "NotebookEdit"}
CASE_INSENSITIVE_FS = sys.platform in ("win32", "darwin")
REDIRECT_OK_EXTS = (".html", ".css", ".sql")
GENERATED_SEGMENTS = {"build", "generated", "node_modules", ".gradle", "dist", "out",
                      "target", "__pycache__", ".venv", "venv", ".next", "coverage"}
DATA_MD_SEGMENTS = {"fixtures", "assets", "resources", "testdata", "test-data", "snapshots"}
ROOT_MD_ALLOW = {"readme.md", "claude.md", "claude.local.md", "agents.md", "changelog.md",
                 "license.md", "contributing.md", "security.md", "code_of_conduct.md"}
ROOT_CODE_ALLOW = {"build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
                   "setup.py", "conftest.py", "manage.py", "gradlew.bat", "index.html",
                   "gulpfile.js", "webpack.config.js", "rollup.config.js", "karma.conf.js"}
ROOT_CODE_ALLOW_GLOBS = ("*.config.js", "*.config.ts", "*.config.mjs", "*.config.cjs",
                         "*.conf.js", "*.conf.ts", ".*")
DEFAULT_READONLY = "architect,deep-reasoner,runner"
DEFAULT_MEM_LINES = 20  # 세션 메모 docs/mem.md 줄 수 상한 기본값 (FABLE_MEM_LINES)

# ── 정규식 ────────────────────────────────────────────────────────────
_EXT_ALT = "|".join(re.escape(e.lstrip(".")) for e in CODE_EXTS)
_CODE_PATH = r"""['"]?[^\s'";|&<>]+\.(?:%s)['"]?(?=\s|$|[;|&)])""" % _EXT_ALT
_CODE_PATH_RE = re.compile(_CODE_PATH, re.IGNORECASE)
_INSTR_PATH = r"""['"]?[^\s'";|&<>]*(?:CLAUDE\.local\.md|CLAUDE\.md|\.claude[\\/]rules[\\/][^\s'";|&<>]*\.md)['"]?"""
_INSTR_PATH_RE = re.compile(_INSTR_PATH, re.IGNORECASE)

_SCRATCH_PREFIX_RE = re.compile(
    r"""^(\$\{?(TEMP|TMP|TMPDIR)\}?|%(TEMP|TMP)%|\$env:(TEMP|TMP))([\\/]|$)|^(/tmp|/private/tmp|/var/folders)/""",
    re.IGNORECASE,
)
_SCRATCH_SEGMENT_RE = re.compile(r"[\\/](scratchpad|AppData[\\/]Local[\\/]Temp)[\\/]", re.IGNORECASE)

# 셸 차단 패턴 — mode: content(항상) / target(코드 경로가 스크래치뿐이면 허용) /
# redirect(target + REDIRECT_OK_EXTS 허용) / dest(cp·mv: 목적지 기준)
_INPLACE = r"\s(?:-[a-zA-Z]*i\b|--in-place)[^|;&]*"
_COMMON_PATTERNS = [
    (r"\bpy(?:thon[0-9.]*)?(?:\.exe)?\s+(?:-[0-9.]+\s+)?-c\b.*(open\([^,)]*,\s*(?:mode\s*=\s*)?['\"][^'\"]*[wax+]|write_text|write_bytes)", "python -c 파일 쓰기", "content"),
    (r"\bnode\s+(-e|--eval|-p)\b.*(writeFile|appendFile|createWriteStream)", "node -e 파일 쓰기", "content"),
    (r"\bgit\s+apply\b", "git apply", "content"),
    (r"(?<![0-9&])>>?\|?\s*" + _CODE_PATH, "코드 파일로 리다이렉트", "redirect"),
]
BASH_BLOCK_PATTERNS = _COMMON_PATTERNS + [
    (r"\bsed\b[^|;&]*" + _INPLACE + _CODE_PATH, "sed -i", "target"),
    (r"\bperl\b[^|;&]*" + _INPLACE + _CODE_PATH, "perl -i", "target"),
    (r"\bruby\b[^|;&]*" + _INPLACE + _CODE_PATH, "ruby -i", "target"),
    (r"(^|[;&|]\s*)patch\s+-", "patch", "content"),
    (r"\btee\b(\s+-[a-zA-Z]+)*\s+" + _CODE_PATH, "tee 코드 파일", "target"),
    (r"(?:^|[;&|\n]\s*)(?:cp|mv|install|rsync)\s[^;&|<>\n]*", "cp/mv 로 코드 파일 덮어쓰기", "dest"),
    (r"\bdd\b[^;&|]*\bof=" + _CODE_PATH, "dd of=", "target"),
    (r"(?:^|[;&|\n]\s*)truncate\s[^;&|]*" + _CODE_PATH, "truncate", "target"),
    (r"\bcat\b[^;&|]*<<-?\s*['\"]?\w+['\"]?[^;&|]*>\s*" + _CODE_PATH, "heredoc 코드 파일 생성", "target"),
]
POWERSHELL_BLOCK_PATTERNS = _COMMON_PATTERNS + [
    (r"\b(Set-Content|Add-Content|Out-File|sc|ac)\b[^;|]*" + _CODE_PATH, "PowerShell 파일 쓰기", "target"),
    (r"\bNew-Item\b[^;|]*" + _CODE_PATH + r"[^;|]*-Value\b", "New-Item -Value", "target"),
    (r"(?:^|[;|\n]\s*)(?:Copy-Item|Move-Item|cpi|mi|copy|move)\s[^;|<>\n]*", "Copy/Move-Item 로 코드 파일 덮어쓰기", "dest"),
    (r"\[(System\.)?IO\.File\]::(Write|Append)", "[IO.File]::Write*", "content"),
]
_SHELL_RE = {
    "Bash": [(re.compile(p, re.IGNORECASE | re.DOTALL), n, m) for p, n, m in BASH_BLOCK_PATTERNS],
    "PowerShell": [(re.compile(p, re.IGNORECASE | re.DOTALL), n, m) for p, n, m in POWERSHELL_BLOCK_PATTERNS],
}
_SQ_RE = re.compile(r"'([^']*)'")
_SQ_KEEP_RE = re.compile(r"[^\s;|&'\"]+\.[A-Za-z0-9]+")
_MESSAGE_ARG_RE = re.compile(
    r"""(?:(?<=\s)|^)(-m|--message|-b|--body|-t|--title|--description)(\s+|=)(?:"(?:[^"\\]|\\.)*"|'[^']*')""",
    re.DOTALL,
)
# 자기 보호 (메인·서브 모두): 상태 파일·스위치 변수 언급, 셸 함수 fable on/off/global/project/debt,
# fable-settings.py 뒤 어디든 project/debt/global (옵션 선행 포함)
_SELF_SHELL_RE = re.compile(
    r"""\.fable-state|FABLE_(?:GATE_OFF|IGNORE_DEBT|REQUIRE_FOLDER_MD)"""
    r"""|(?:^|[;&|\n(`{])\s*fable\s+(?:on|off|global|project|debt)\b"""
    r"""|fable-settings\.py\b.*?\b(?:project|debt|global)\b"""
    # 설치기 실행: install(_*).py/.ps1/.sh 파일명, -m install(_*), import/from install(_*)
    r"""|\binstall(?:_\w+)?\.(?:py|ps1|sh)\b|-m\s+install(?:_\w+)?\b|\b(?:import|from)\s+install(?:_\w+)?\b""",
    re.IGNORECASE | re.DOTALL,
)
# 지시 파일을 대상으로 하는 셸 쓰기 (서브에이전트 전부, 메인은 모듈 안내 파일만)
_INSTR_SHELL_WRITE_RE = re.compile(
    r"""(?:(?<![0-9&])>>?\|?\s*|\b(?:tee|rm|del|mv|cp|install|rsync|truncate|Set-Content|Add-Content|Out-File|Remove-Item|Move-Item|Copy-Item|New-Item)\b[^;&|\n]*?|\b(?:sed|perl|ruby)\b[^|;&]*""" + _INPLACE + r""")""" + _INSTR_PATH,
    re.IGNORECASE,
)
# 빈 catch
_EMPTY_CATCH_RES = [
    re.compile(r"\bcatch\b\s*(?:\([^)]*\))?\s*\{\s*\}"),                      # Kotlin/Java/JS/C#/Swift
    re.compile(r"^[ \t]*except\b[^\n:]*:[ \t]*(?:pass|\.\.\.)[ \t]*$", re.M),      # Python inline
    re.compile(r"^[ \t]*except\b[^\n:]*:[ \t]*\n[ \t]*(?:pass|\.\.\.)[ \t]*$", re.M),  # Python 다음 줄
    re.compile(r"\brescue\b[^\n]*\n\s*end\b"),                                   # Ruby
]
# fable_debt 를 못 불러올 때만 쓰는 줄 보호 판정 (fable_debt._PROTECT_RE 와 같은 식)
_DEBT_PROTECT_FALLBACK_RE = re.compile(r"^\s*-\s*\[부채(?::[^\]]*)?\]")
_TRUE = {"1", "true", "yes", "on"}


# ── 공통 유틸 ─────────────────────────────────────────────────────────
def log(level, msg, **ctx):
    try:
        os.makedirs(FABLE_HOME, exist_ok=True)
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_BYTES:
            os.replace(LOG_FILE, LOG_FILE + ".1")
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "level": level, "msg": msg, **ctx}
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def allow():
    sys.exit(0)


def deny(reason, **ctx):
    log("DENY", reason, **ctx)
    payload = json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse", "permissionDecision": "deny",
        "permissionDecisionReason": reason}}, ensure_ascii=True)
    sys.stdout.write(payload + "\n")
    sys.stdout.flush()
    sys.exit(0)


def read_input():
    return json.loads(sys.stdin.buffer.read().decode("utf-8-sig"))


def fable_on():
    try:
        with open(STATE_FILE, encoding="utf-8-sig") as f:
            return f.read().strip().lower() == "on"
    except FileNotFoundError:
        return False


def _truthy(v):
    return str(v or "").strip().lower() in _TRUE


_PROJECT_ENV_CACHE = {}


GLOBAL_SETTINGS = os.path.join(HOME, ".claude", "settings.json")


def _merge_env(p, merged):
    """p 의 env 중 FABLE_ 키를 아직 없는 것만 merged 에 넣는다 (먼저 잡힌 값 유지)."""
    if not os.path.isfile(p):
        return
    try:
        with open(p, encoding="utf-8-sig") as f:
            env = (json.load(f) or {}).get("env") or {}
        for k, v in env.items():
            if k.startswith("FABLE_") and k not in merged:
                merged[k] = v
    except Exception as e:  # 복구: 깨진 설정 파일은 건너뛴다(fail-open)
        log("WARN", f"설정 읽기 실패: {p}: {e}")


def project_env(cwd):
    """settings env 합치기. 순서: 프로젝트 settings.local.json > settings.json (cwd 에서 위로, 가까운 쪽 우선)
    > 전역 ~/.claude/settings.json (홈 밖 프로젝트도 명시적 fallback). 먼저 잡힌 값 유지 → "0" 도 명시적 off."""
    key = os.path.abspath(cwd or os.getcwd())
    if key in _PROJECT_ENV_CACHE:
        return _PROJECT_ENV_CACHE[key]
    merged = {}
    glob_norm = os.path.normcase(os.path.abspath(GLOBAL_SETTINGS))
    d = key
    for _ in range(32):
        for name in ("settings.local.json", "settings.json"):
            p = os.path.join(d, ".claude", name)
            if os.path.normcase(os.path.abspath(p)) == glob_norm:
                continue  # 전역 파일은 아래에서 맨 마지막 층으로만 읽는다
            _merge_env(p, merged)
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    _merge_env(GLOBAL_SETTINGS, merged)
    _PROJECT_ENV_CACHE[key] = merged
    return merged


# fable-settings.py 가 프로젝트 settings 에만 쓰는 스위치. Claude Code 가 settings 의 env 를 프로세스 환경에
# 심은 뒤에는 키를 지워도 환경변수가 남으므로(세션 중 project off→on), 이 키들은 파일에서만 읽는다.
_FILE_ONLY_KEYS = ("FABLE_GATE_OFF", "FABLE_REQUIRE_FOLDER_MD", "FABLE_IGNORE_DEBT")


def setting(name, cwd, default=""):
    """환경변수 → 프로젝트 settings env → 전역 settings env → 기본값. 스위치 키는 settings 파일만 본다."""
    v = None if name in _FILE_ONLY_KEYS else os.environ.get(name)
    if v is None or v == "":
        v = project_env(cwd).get(name)
    return default if v is None or str(v) == "" else str(v)


def setting_int(name, cwd, default):
    try:
        return int(setting(name, cwd, str(default)))
    except ValueError:
        return default


def is_code(path):
    return bool(path) and path.lower().endswith(CODE_EXTS)


def resolve(path, cwd):
    if not path:
        return ""
    path = os.path.expanduser(path)
    if not os.path.isabs(path):
        path = os.path.join(cwd or os.getcwd(), path)
    return os.path.normpath(path)


def file_key(path):
    return _norm(path)  # realpath 기준: 8.3 단축명·심볼릭 링크도 같은 파일로 센다


def _norm(p):
    try:
        p = os.path.realpath(p)
    except Exception:
        pass
    p = os.path.normcase(os.path.normpath(p))
    return p.lower() if CASE_INSENSITIVE_FS else p


def _scratch_roots(data):
    roots = [data.get("scratchpad_dir"), tempfile.gettempdir(),
             os.environ.get("TEMP"), os.environ.get("TMP"), os.environ.get("TMPDIR"),
             os.path.join(HOME, ".claude", "jobs")]
    return [_norm(r) for r in roots if r]


def is_scratch(path, cwd, data):
    raw = (path or "").strip("'\"")
    if not raw:
        return False
    if _SCRATCH_PREFIX_RE.search(raw) or _SCRATCH_SEGMENT_RE.search(raw.replace("/", os.sep)) \
            or _SCRATCH_SEGMENT_RE.search(raw):
        return True
    full = _norm(resolve(raw, cwd))
    return any(full == r or full.startswith(r.rstrip("\\/") + os.sep) for r in _scratch_roots(data))


def is_generated(path):
    parts = {p.lower() for p in re.split(r"[\\/]", path)}
    return bool(parts & GENERATED_SEGMENTS)


def count_lines(path):
    n = 0
    with open(path, "rb") as f:
        for _ in f:
            n += 1
    return n


def text_lines(s):
    if not s:
        return 0
    return s.count("\n") + (0 if s.endswith("\n") else 1)


def read_text(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.read()


def find_root(start):
    """프로젝트 루트. 우선순위: 가장 가까운 .git → 가장 가까운 .claude/CLAUDE.md → 가장 위쪽의 CLAUDE.md.
    모듈 폴더의 CLAUDE.md 는 루트가 아니므로 마지막 기준은 '가장 위쪽'을 쓴다."""
    d = os.path.abspath(start)
    if os.path.isfile(d):
        d = os.path.dirname(d)
    home = _norm(HOME)
    git = dot = None
    top_claude = None
    for _ in range(64):
        if _norm(d) == home:
            break
        if git is None and os.path.exists(os.path.join(d, ".git")):
            git = d
        if dot is None and os.path.isfile(os.path.join(d, ".claude", "CLAUDE.md")):
            dot = d
        if os.path.isfile(os.path.join(d, "CLAUDE.md")):
            top_claude = d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return git or dot or top_claude


def _under(path, base):
    p, b = _norm(path), _norm(base)
    return p == b or p.startswith(b.rstrip("\\/") + os.sep)


def _rel_parts(path, root):
    rel = os.path.relpath(path, root)
    return [p for p in re.split(r"[\\/]", rel) if p and p != "."]


def is_instruction_file(path):
    base = os.path.basename(path).lower()
    if base in ("claude.md", "claude.local.md"):
        return True
    return bool(re.search(r"[\\/]\.claude[\\/]rules[\\/].*\.md$", path, re.IGNORECASE))


def is_module_nav(path, root):
    """모듈 안내 파일: 프로젝트 안, .claude/ 나 ~/.claude 아래가 아닌 CLAUDE(.local).md.
    루트 직속은 CLAUDE.local.md 만 해당 (루트 CLAUDE.md 는 프로젝트 전체 규칙이라 제외)"""
    base = os.path.basename(path).lower()
    if base not in ("claude.md", "claude.local.md"):
        return False
    if _under(path, os.path.join(HOME, ".claude")):
        return False
    d = os.path.dirname(path)
    if root is None or not _under(path, root):
        return False
    if (_norm(d) == _norm(root) and base == "claude.md") or os.path.basename(d).lower() == ".claude":
        return False
    return True


def is_root_nav(path, root):
    """루트 안내 파일: 프로젝트 루트의 CLAUDE.md 와 .claude/CLAUDE.md. ~/.claude 아래(전역)는 제외."""
    if root is None or not path or _under(path, os.path.join(HOME, ".claude")):
        return False
    return _norm(path) in (_norm(os.path.join(root, "CLAUDE.md")), _norm(os.path.join(root, ".claude", "CLAUDE.md")))


def _is_root_docs_file(path, root, name):
    """루트 기준 docs/<name> 인지 (realpath·대소문자 무시)."""
    if root is None or not path or not _under(path, root):
        return False
    rel = os.path.relpath(_norm(path), _norm(root))
    return [p.lower() for p in re.split(r"[\\/]", rel) if p and p != "."] == ["docs", name]


def is_project_map(path, root):
    """자동 생성 프로젝트 지도: 루트 기준 docs/map.md (대소문자 무시)."""
    return _is_root_docs_file(path, root, "map.md")


def is_session_memo(path, root):
    """세션 메모: 루트 기준 docs/mem.md (대소문자 무시). 메인만 Write 로 쓴다(docs/design-session-memory.md)."""
    return _is_root_docs_file(path, root, "mem.md")


_debt_warned = []


def _warn_no_debt_module():
    if not _debt_warned:
        _debt_warned.append(1)
        log("WARN", "fable_debt 모듈을 불러오지 못해 부채 없음으로 동작", err=_DEBT_IMPORT_ERR)


def debt_find(path, root, cwd, kind):
    """path 와 일치하는 kind 종류 부채(fable_debt.Debt) 또는 None. 폴더는 끝에 os.sep 를 붙여 넘긴다.
    무시 스위치(fable debt enforce on)가 켜져 있거나 fable_debt 를 못 불러오면 None(부채 없음)."""
    if _truthy(setting("FABLE_IGNORE_DEBT", cwd)):
        return None
    if fable_debt is None:
        _warn_no_debt_module()
        return None
    try:
        return fable_debt.find(path, root, kind)
    except Exception as e:  # 복구: 조회 실패는 부채 없음으로(fail-open 규칙이 더 엄격해지는 쪽), 기록
        log("WARN", "부채 조회 실패 — 부채 없음으로 처리", path=path, kind=kind, err=f"{type(e).__name__}: {e}")
        return None


def debt_line_set(text):
    """줄 보호용 [부채…] 줄 집합(종류 불문). fable_debt 가 없으면 같은 식의 대체 정규식으로 판정."""
    if fable_debt is not None:
        return fable_debt.debt_line_set(text)
    _warn_no_debt_module()
    return {ln.strip() for ln in (text or "").splitlines() if _DEBT_PROTECT_FALLBACK_RE.match(ln)}


def count_empty_catch(s):
    return sum(len(rx.findall(s)) for rx in _EMPTY_CATCH_RES) if s else 0


def edit_path(inp, cwd):
    return resolve(inp.get("file_path") or inp.get("notebook_path") or "", cwd)


def _occurrences(hay, needle):
    return hay.count(needle) if needle else 0


def projected_lines(tool, inp, path):
    """수정 결과 줄 수 (None 이면 계산 불가)."""
    current = count_lines(path) if os.path.isfile(path) else 0
    if tool == "Write":
        return current, text_lines(inp.get("content", ""))
    text = read_text(path) if os.path.isfile(path) else ""
    edits = inp.get("edits") if tool == "MultiEdit" else [inp]
    delta = 0
    for e in edits or []:
        old, new = e.get("old_string", ""), e.get("new_string", "")
        n = max(1, _occurrences(text, old)) if e.get("replace_all") else 1
        delta += n * (new.count("\n") - old.count("\n"))
    return current, current + delta


"""
fable_switches.py — 전역 스위치의 settings.json 조각 (fable-settings.py 가 import, 설치기도 같은 항목을 쓴다)

파일 읽기·쓰기는 하지 않는다. settings 딕셔너리를 받아 바꾼 결과를 돌려주는 순수 함수만 둔다.
설계: docs/design-global-defaults.md C 절 (SessionStart 의 project-map 항목, require-md 전역 표시)
"""
import json
import os
import shutil
import sys

MAP_MARK = "project-map.py"  # SessionStart 항목 식별 표식
MAP_MATCHER = "startup|resume|compact"
REQUIRE_KEY = "FABLE_REQUIRE_FOLDER_MD"
TRUE_VALUES = ("1", "true", "yes", "on")


def _slash(p):
    return p.replace("\\", "/")


def map_entry(hooks_dir=None, is_win=None, has_py=None):
    """SessionStart 에 넣을 project-map 항목(설치기 gate_entry 와 같은 틀).

    hooks_dir 생략 시 이 파일의 폴더, is_win 생략 시 현재 OS, has_py 생략 시 PATH 의 `py` 유무.
    """
    is_win = (os.name == "nt") if is_win is None else is_win
    if is_win:
        script = _slash(os.path.join(hooks_dir or os.path.dirname(os.path.abspath(__file__)), MAP_MARK))
        has_py = bool(shutil.which("py")) if has_py is None else has_py
        cmd, args = ("py", ["-3", script, ".", "--quiet"]) if has_py else (_slash(sys.executable), [script, ".", "--quiet"])
        return {"matcher": MAP_MATCHER,
                "hooks": [{"type": "command", "command": cmd, "args": args, "timeout": 10}]}
    return {"matcher": MAP_MATCHER,
            "hooks": [{"type": "command",
                       "command": 'python3 "$HOME/.claude/fable/hooks/project-map.py" . --quiet',
                       "timeout": 10}]}


def _is_map(entry):
    return MAP_MARK in json.dumps(entry, ensure_ascii=False)


def _session_start(data):
    hooks = data.get("hooks")
    start = hooks.get("SessionStart") if isinstance(hooks, dict) else None
    return start if isinstance(start, list) else []


def set_map(data, on, entry=None):
    """data(settings 딕셔너리)의 hooks.SessionStart 에서 project-map 항목을 정리하고 on 이면 1개 추가.

    빈 배열·빈 hooks 는 키째 제거(설치기 set_gate 와 같은 정리). 반환: (data, 정리한 기존 항목 수).
    """
    hooks = data.get("hooks") if isinstance(data.get("hooks"), dict) else {}
    start = _session_start(data)
    keep = [e for e in start if not _is_map(e)]
    removed = len(start) - len(keep)
    if on:
        keep.append(entry or map_entry())
    if keep:
        hooks["SessionStart"] = keep
    else:
        hooks.pop("SessionStart", None)
    if hooks:
        data["hooks"] = hooks
    else:
        data.pop("hooks", None)
    return data, removed


def has_map(data):
    """settings 딕셔너리의 SessionStart 에 project-map 항목이 있는가."""
    return any(_is_map(e) for e in _session_start(data))


def require_label(env):
    """env 딕셔너리의 REQUIRE_KEY 값 표시: ON | off | 미설정."""
    if not isinstance(env, dict) or REQUIRE_KEY not in env:
        return "미설정"
    return "ON" if str(env.get(REQUIRE_KEY, "")).strip().lower() in TRUE_VALUES else "off"

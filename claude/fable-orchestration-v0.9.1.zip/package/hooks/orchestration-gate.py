#!/usr/bin/env python3
"""
orchestration-gate.py — Fable 오케스트레이션 PreToolUse 게이트 (V5)

V3 까지의 변경 이유는 APPLY-GUIDE.md 의 변경점 표를 참고. V4 에서 추가된 것:
  - 읽기 전용 에이전트(architect·deep-reasoner·runner)의 셸 우회·코드 쓰기 차단
  - 지시 파일(CLAUDE.md, CLAUDE.local.md, .claude/rules/*.md) 서브에이전트 전면 차단
  - 모듈 안내 파일은 메인 Write 만, 30줄 초과 차단
  - 파일 줄 수 상한 500 (기존 초과 파일은 작업당 +30줄까지, [부채] 등록 파일 제외)
  - 빈 catch 차단 (새로 생기는 것만)
  - 루트 새 파일 생성 금지(코드·.md, 허용 목록), .md 는 docs/ 아래만, 안내 파일 없는 폴더에
    코드 생성 금지(기본 전역 ON(설치기), 프로젝트별 off 가능)
  - Agent(general-purpose) 호출 차단 → implementer 유도

규칙 적용 순서 (main() 참조)
  0. fable off / 프로젝트 off → 전부 허용. 스크래치·임시 경로 파일은 모든 규칙 면제
  A. [전체] 자기 보호 (.fable-state, FABLE_ 스위치, fable on/off/project/debt, CLAUDE.local.md [부채] 줄)
     + 설치기(install.py/.ps1/.sh, install_*.py, -m install, import install*) 셸 실행 차단 — 설치는 사용자가 터미널에서
  B. [서브] 지시 파일 쓰기 전면 차단 / [메인] 모듈 안내 파일은 Write 만 + 30줄
     / [메인] 루트 안내 파일 200줄(줄이는 수정은 허용) / [전체] docs/map.md 쓰기 차단(자동 생성)
     / docs/mem.md 는 [서브] 쓰기 차단, [메인] Write 만 + FABLE_MEM_LINES(20)줄
  C. [서브] 읽기 전용 에이전트: 코드·지시 파일 쓰기와 셸 우회 차단 (architect 는 docs/ 허용)
  D. [전체] 기존 코드 파일 Write 재작성 차단
  E. [전체] 파일 줄 수 상한 / 빈 catch / 루트 생성 / .md 위치 / 안내 파일 필수
  F. [메인] Agent(general-purpose) 차단 / 셸 우회 차단 / 턴당 코드 파일 2개

설정 — 환경변수 또는 프로젝트 .claude/settings(.local).json > 전역 ~/.claude/settings.json 의 "env"
  FABLE_GATE_LIMIT=2          메인 턴당 코드 파일 수정 한도
  FABLE_REWRITE_LINES=50      이 줄 수를 넘는 기존 파일의 Write 차단
  FABLE_MAX_LINES=500         코드 파일 줄 수 상한
  FABLE_OVER_GROWTH=30        이미 상한을 넘은 파일에 작업당 허용하는 증가분
  FABLE_NAV_LINES=30          모듈 CLAUDE.md / CLAUDE.local.md 줄 수 상한
  FABLE_ROOT_NAV_LINES=200    루트 CLAUDE.md / .claude/CLAUDE.md 줄 수 상한 (줄이는 수정은 허용)
  FABLE_MEM_LINES=20          세션 메모 docs/mem.md 줄 수 상한 (메인 Write 만)
  FABLE_READONLY_AGENTS       읽기 전용 에이전트 이름 (쉼표). 기본 architect,deep-reasoner,runner
  FABLE_ROOT_ALLOW            루트에 생성을 허용할 파일 패턴 추가 (쉼표, fnmatch)
  FABLE_MD_ALLOW              docs/ 밖에 .md 생성을 허용할 경로 패턴 추가 (쉼표, fnmatch)
  FABLE_REQUIRE_FOLDER_MD=1   상위에 모듈 안내 파일이 없는 곳의 코드 생성 차단 (기본 전역 ON(설치기), 프로젝트별 "0" 으로 off)
  FABLE_IGNORE_DEBT=1         모든 종류의 [부채] 제외를 무시 (fable debt enforce on)

부채 종류(fable_debt.py, docs/design-debt-kinds.md): 줄수 → 줄 수 상한, 루트 → 루트 생성,
안내 → 안내 파일 필수 면제. 공통부(설정·정규식·유틸)는 gate_common.py.
  FABLE_GATE_OFF=1            이 프로젝트에서 게이트 비활성 (fable project off)

의존: Python 3.8+, Claude Code v2.1.271+ (prompt_id)
"""
import fnmatch
import json
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 같은 폴더의 gate_common·fable_debt
from gate_common import (  # noqa: E402  공통부(고정 설정·정규식·유틸)는 gate_common.py
    HOME, COUNTER_DIR, SHELL_TOOLS, EDIT_TOOLS, REDIRECT_OK_EXTS, DATA_MD_SEGMENTS,
    ROOT_MD_ALLOW, ROOT_CODE_ALLOW, ROOT_CODE_ALLOW_GLOBS, DEFAULT_READONLY, DEFAULT_MEM_LINES,
    _CODE_PATH_RE, _INSTR_PATH_RE, _SHELL_RE, _SQ_RE, _SQ_KEEP_RE, _MESSAGE_ARG_RE,
    _SELF_SHELL_RE, _INSTR_SHELL_WRITE_RE,
    log, allow, deny, read_input, fable_on, _truthy, setting, setting_int, is_code, resolve,
    file_key, _norm, is_scratch, is_generated, count_lines, text_lines, read_text, find_root,
    _under, _rel_parts, is_instruction_file, is_module_nav, is_root_nav, is_project_map, is_session_memo, debt_find, debt_line_set,
    count_empty_catch, edit_path, projected_lines,
)


# ── 규칙 A: 자기 보호 ──────────────────────────────────────────────────
def rule_self_protect(tool, inp, cwd, who):
    msg = ("[fable-gate] 게이트 스위치(.fable-state, FABLE_GATE_OFF 등)와 부채 등록은 에이전트가 바꿀 수 없습니다. "
           "필요하면 사용자에게 `fable off`, `fable project off`, `fable debt …` 실행을 요청하세요. "
           "설치기(install.py·install_*.py 와 그 모듈 실행·import)는 사용자가 터미널에서 실행합니다. "
           "설치기 파일을 볼 때는 셸 대신 Read 도구를 쓰세요. "
           "(이 규칙을 푸는 FABLE_ 설정은 없습니다)")
    if tool in SHELL_TOOLS:
        cmd = inp.get("command", "") or ""
        if _SELF_SHELL_RE.search(cmd):
            deny(msg, rule="self_protect", who=who, tool=tool, cmd=cmd[:300])
    elif tool in EDIT_TOOLS:
        path = edit_path(inp, cwd)
        base = os.path.basename(path).lower()
        if base == ".fable-state":
            deny(msg, rule="self_protect", who=who, path=path)
        if base == "claude.local.md" and tool != "NotebookEdit":  # I9(b): [부채] 줄은 사용자 터미널 명령만
            cur = read_text(path) if os.path.isfile(path) else ""
            new = inp.get("content", "") if tool == "Write" else cur
            for e in [] if tool == "Write" else (inp.get("edits") or []) if tool == "MultiEdit" else [inp]:
                new = new.replace(e.get("old_string", ""), e.get("new_string", ""), -1 if e.get("replace_all") else 1)
            if debt_line_set(cur) != debt_line_set(new):  # 종류 불문([부채], [부채:줄수] 등)
                deny("[fable-gate] [부채] 줄은 에이전트가 바꿀 수 없습니다. 사용자가 터미널에서 "
                     "fable debt add|keep|fix|drop <경로> [--kind 줄수|안내|루트|구조] 를 실행합니다. "
                     "(이 규칙을 푸는 FABLE_ 설정은 없습니다)",
                     rule="debt_lines", who=who, path=path)
        if base in ("settings.json", "settings.local.json") \
                and os.path.basename(os.path.dirname(path)).lower() == ".claude" \
                and re.search(r"FABLE_(GATE_OFF|IGNORE_DEBT|REQUIRE_FOLDER_MD)", json.dumps(inp, ensure_ascii=False)):
            deny(msg, rule="self_protect", who=who, path=path)


# ── 규칙 B: 지시 파일 ──────────────────────────────────────────────────
def rule_instruction_files(tool, inp, cwd, data, is_sub, who, root):
    nav_lines = setting_int("FABLE_NAV_LINES", cwd, 30)
    if tool in SHELL_TOOLS:
        cmd = inp.get("command", "") or ""
        for m in _INSTR_SHELL_WRITE_RE.finditer(cmd):
            target = _INSTR_PATH_RE.search(m.group(0))
            tpath = resolve(target.group(0).strip("'\""), cwd) if target else ""
            if is_sub:
                deny("[fable-gate] 서브에이전트는 지시 파일(CLAUDE.md, CLAUDE.local.md, .claude/rules)을 "
                     "수정할 수 없습니다. 갱신이 필요하면 반환 요약의 open issues 에 적으세요.",
                     rule="instr_sub_shell", who=who, cmd=cmd[:300])
            if tpath and is_module_nav(tpath, root):
                deny("[fable-gate] 모듈 안내 파일은 셸이 아니라 Write 도구로 전체를 다시 써야 합니다 "
                     f"({nav_lines}줄 이하).", rule="nav_shell", who=who, cmd=cmd[:300])
        return
    if tool not in EDIT_TOOLS:
        return
    path = edit_path(inp, cwd)
    whole = tool in ("Write", "Edit", "MultiEdit")
    if whole and is_project_map(path, root):
        deny("[fable-gate] docs/map.md 는 자동 생성 파일입니다. 직접 고치지 말고 fable map 으로 재생성하세요.",
             rule="map_protect", who=who, path=path)
    if whole and is_session_memo(path, root):
        rule_session_memo(tool, inp, cwd, is_sub, who, path)
    if not is_instruction_file(path):
        return
    if is_sub:
        deny("[fable-gate] 서브에이전트는 지시 파일(CLAUDE.md, CLAUDE.local.md, .claude/rules)을 "
             "수정할 수 없습니다. 갱신이 필요하면 반환 요약의 open issues 에 적으세요.",
             rule="instr_sub", who=who, path=path)
    if whole and is_root_nav(path, root):
        limit = setting_int("FABLE_ROOT_NAV_LINES", cwd, 200)
        cur, new = projected_lines(tool, inp, path)
        if new > limit and new > cur:  # 늘어나지 않는 수정(줄이기·같은 줄 수)은 항상 허용
            deny(f"[fable-gate] 루트 안내 파일은 {limit}줄 이하여야 합니다 (지금 {cur}줄 → 수정 후 {new}줄). "
                 "규칙만 남기고 모듈 목록·파일 표는 docs/structure.md 로 옮기세요. 현황은 docs/map.md. "
                 "줄을 늘리지 않는 수정은 항상 허용됩니다. (FABLE_ROOT_NAV_LINES)",
                 rule="root_nav_lines", who=who, path=path, lines=new, limit=limit)
    if is_module_nav(path, root):
        if tool != "Write":
            deny("[fable-gate] 모듈 안내 파일(CLAUDE.md / CLAUDE.local.md)은 Edit 가 아니라 Write 로 "
                 "전체를 다시 씁니다. 지난 내용을 정리한 뒤 전체를 Write 하세요.",
                 rule="nav_write_only", who=who, path=path)
        n = text_lines(inp.get("content", ""))
        if n > nav_lines:
            deny(f"[fable-gate] 모듈 안내 파일은 {nav_lines}줄 이하여야 합니다 (지금 {n}줄). "
                 "오래된 항목을 지우거나 로드맵·docs/ 로 옮기세요. (FABLE_NAV_LINES)",
                 rule="nav_lines", who=who, path=path, lines=n)


def rule_session_memo(tool, inp, cwd, is_sub, who, path):
    if is_sub:
        deny("[fable-gate] docs/mem.md 는 메인만 쓴다. 열린 일·함정은 반환 요약의 open issues 로 전달하라.",
             rule="mem_sub", who=who, path=path)
    limit = setting_int("FABLE_MEM_LINES", cwd, DEFAULT_MEM_LINES)
    msg = (f"[fable-gate] docs/mem.md 는 메인이 {limit}줄 안으로 전체 재작성만 한다. "
           "지난 항목은 CLAUDE.md·ADR·fable debt 로 옮기고 지운다. (FABLE_MEM_LINES)")
    if tool != "Write":
        deny(msg, rule="mem_write_only", who=who, path=path)
    n = text_lines(inp.get("content", ""))
    if n > limit:
        deny(f"{msg} (지금 {n}줄)", rule="mem_lines", who=who, path=path, lines=n, limit=limit)


# ── 규칙 C: 읽기 전용 에이전트 ─────────────────────────────────────────
def rule_readonly_agent(tool, inp, cwd, data, agent_type, root):
    names = {s.strip() for s in setting("FABLE_READONLY_AGENTS", cwd, DEFAULT_READONLY).split(",") if s.strip()}
    if agent_type not in names:
        return
    who = f"sub:{agent_type}"
    if tool in SHELL_TOOLS:
        rule_shell(tool, inp.get("command", "") or "", cwd, data, who,
                   f"{agent_type} 는 읽기 전용 에이전트라 셸로 파일을 수정할 수 없습니다")
        return
    if tool in EDIT_TOOLS:
        path = edit_path(inp, cwd)
        if is_scratch(path, cwd, data):
            return
        if agent_type == "architect" and root and _under(path, os.path.join(root, "docs")) \
                and not is_instruction_file(path):
            return
        deny(f"[fable-gate] {agent_type} 는 읽기 전용 에이전트입니다. 파일을 수정하지 말고 결과만 반환하세요"
             + (" (architect 는 docs/ 아래만 쓸 수 있습니다)." if agent_type == "architect" else "."),
             rule="readonly_agent", who=who, path=path)


# ── 규칙 D: 재작성 차단 ────────────────────────────────────────────────
def rule_full_rewrite(tool, inp, cwd, who, data):
    if tool != "Write":
        return
    path = resolve(inp.get("file_path", ""), cwd)
    if not is_code(path) or not os.path.isfile(path) or is_scratch(path, cwd, data):
        return
    lines = count_lines(path)
    if lines > setting_int("FABLE_REWRITE_LINES", cwd, 50):
        deny(f"[fable-gate] {os.path.basename(path)}({lines}줄)는 이미 존재하는 코드 파일입니다. "
             "Write로 전체를 다시 쓰지 말고 Edit로 바뀌는 부분만 수정하세요.",
             rule="full_rewrite", who=who, path=path, lines=lines)


# ── 규칙 E: 크기·품질·위치 ─────────────────────────────────────────────
def rule_line_limit(tool, inp, cwd, who, data, root):
    if tool not in ("Write", "Edit", "MultiEdit"):
        return
    path = edit_path(inp, cwd)
    if not is_code(path) or is_scratch(path, cwd, data) or is_generated(path):
        return
    max_lines = setting_int("FABLE_MAX_LINES", cwd, 500)
    growth = setting_int("FABLE_OVER_GROWTH", cwd, 30)
    try:
        current, result = projected_lines(tool, inp, path)
    except Exception as e:
        log("WARN", f"줄 수 계산 실패(허용): {path}: {e}")
        return
    if result <= max_lines:
        return
    if debt_find(path, root, cwd, "줄수"):  # 파일 또는 폴더 항목 [부채] / [부채:줄수]
        return
    name = os.path.basename(path)
    if current <= max_lines:
        deny(f"[fable-gate] {name} 이(가) {result}줄이 되어 상한 {max_lines}줄을 넘습니다. "
             "이 파일을 키우지 말고 새 책임은 새 파일로 두세요. 분할이 필요하면 작업을 계속하고 "
             "open issues 에 적으세요. (FABLE_MAX_LINES / 사용자 승인 시 fable debt add <파일> --kind 줄수)",
             rule="line_limit", who=who, path=path, current=current, result=result)
    if result > current + growth:
        deny(f"[fable-gate] {name} 은(는) 이미 {current}줄로 상한을 넘은 파일입니다. 작업당 +{growth}줄까지만 "
             f"허용됩니다 (지금 +{result - current}). 새 코드는 새 파일로 두고, 분할은 open issues 에 적으세요. "
             "(FABLE_OVER_GROWTH / 사용자 승인 시 fable debt add <파일> --kind 줄수)",
             rule="line_growth", who=who, path=path, current=current, result=result)


def rule_empty_catch(tool, inp, cwd, who, data):
    if tool not in ("Write", "Edit", "MultiEdit"):
        return
    path = edit_path(inp, cwd)
    if not is_code(path) or is_scratch(path, cwd, data) or is_generated(path):
        return
    if tool == "Write":
        new = count_empty_catch(inp.get("content", ""))
        old = count_empty_catch(read_text(path)) if os.path.isfile(path) else 0
    else:
        edits = inp.get("edits") if tool == "MultiEdit" else [inp]
        new = sum(count_empty_catch(e.get("new_string", "")) for e in edits or [])
        old = sum(count_empty_catch(e.get("old_string", "")) for e in edits or [])
    if new > old:
        deny("[fable-gate] 빈 catch/except 는 금지입니다. 복구·번역·종단 중 하나로 처리하거나, "
             "정말 무시해야 하면 이유를 주석으로 적고 DEBUG 로그를 남기세요.",
             rule="empty_catch", who=who, path=path)


def _creating(path):
    return not os.path.exists(path)


def rule_root_create(tool, inp, cwd, who, data, root):
    if tool != "Write" or root is None:
        return
    path = edit_path(inp, cwd)
    if not _creating(path) or is_scratch(path, cwd, data):
        return
    if _norm(os.path.dirname(path)) != _norm(root):
        return
    base = os.path.basename(path)
    low = base.lower()
    extra = [p.strip() for p in setting("FABLE_ROOT_ALLOW", cwd).split(",") if p.strip()]
    if any(fnmatch.fnmatch(base, g) or fnmatch.fnmatch(low, g.lower()) for g in extra):
        return
    if is_code(path) and debt_find(path, root, cwd, "루트"):  # [부채:루트] 파일 항목 (코드 파일만, 설계 문서)
        return
    if low.endswith(".md"):
        if low in ROOT_MD_ALLOW:
            return
        deny(f"[fable-gate] 루트에 문서를 만들지 않습니다 ({base}). 문서는 docs/ 아래(요구사항은 docs/requirements/, "
             "결정은 docs/adr/)에 두세요. (FABLE_ROOT_ALLOW 로 예외 추가)",
             rule="root_md", who=who, path=path)
    if is_code(path):
        if low in ROOT_CODE_ALLOW or any(fnmatch.fnmatch(low, g) for g in ROOT_CODE_ALLOW_GLOBS):
            return
        deny(f"[fable-gate] 루트에 코드 파일을 만들지 않습니다 ({base}). 모듈 폴더(또는 scripts/) 안에 두세요. "
             "루트 설정 파일이면 사용자에게 FABLE_ROOT_ALLOW 추가를, 임시 예외면 "
             f"fable debt add {base} \"<조건>\" --kind 루트 실행을 요청하세요.",
             rule="root_code", who=who, path=path)


def rule_md_location(tool, inp, cwd, who, data, root):
    if tool != "Write" or root is None:
        return
    path = edit_path(inp, cwd)
    if not path.lower().endswith(".md") or not _creating(path) or is_scratch(path, cwd, data):
        return
    if not _under(path, root) or _norm(os.path.dirname(path)) == _norm(root):
        return
    if os.path.basename(path).lower() in ("claude.md", "claude.local.md"):
        return
    parts = _rel_parts(path, root)
    if parts and parts[0].lower() == "docs":
        return
    if any(p.startswith(".") for p in parts[:-1]):
        return
    if any(p.lower() in DATA_MD_SEGMENTS for p in parts[:-1]):
        return
    rel = "/".join(parts)
    extra = [p.strip() for p in setting("FABLE_MD_ALLOW", cwd).split(",") if p.strip()]
    if any(fnmatch.fnmatch(rel, g) for g in extra):
        return
    deny(f"[fable-gate] 문서는 docs/ 아래에 둡니다 ({rel}). 모듈 설명은 그 폴더의 CLAUDE.md(메인만 작성) 또는 "
         "docs/modules/<이름>.md 로. (FABLE_MD_ALLOW 로 예외 추가)",
         rule="md_location", who=who, path=path)


def rule_nav_required(tool, inp, cwd, who, data, root):
    if tool != "Write" or root is None or not _truthy(setting("FABLE_REQUIRE_FOLDER_MD", cwd)):
        return
    path = edit_path(inp, cwd)
    if not is_code(path) or not _creating(path) or is_scratch(path, cwd, data) or is_generated(path):
        return
    if not _under(path, root) or _norm(os.path.dirname(path)) == _norm(root):
        return
    parts = _rel_parts(path, root)
    if parts and parts[0].startswith("."):
        return
    d = os.path.dirname(path)
    while _norm(d) != _norm(root):
        if os.path.isfile(os.path.join(d, "CLAUDE.md")) or os.path.isfile(os.path.join(d, "CLAUDE.local.md")):
            return
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    if debt_find(os.path.dirname(path) + os.sep, root, cwd, "안내"):  # [부채:안내] 폴더 항목(상위 포함)
        return
    folder = os.path.relpath(os.path.dirname(path), root).replace("\\", "/")
    deny(f"[fable-gate] {folder}/ 와 그 상위(루트 제외)에 모듈 안내 파일(CLAUDE.md)이 없습니다. "
         "상위 폴더 중 하나에 CLAUDE.md 한 장을 두면 하위 폴더 전부가 통과합니다. "
         "메인이 1라운드 인터뷰 후 Write 하거나(서브에이전트는 '새 모듈 필요: 이유' 를 반환), "
         f"사용자 승인 시 fable debt add {folder}/ \"<조건>\" --kind 안내.",
         rule="nav_required", who=who, path=path)


# ── 규칙 F: 메인 전용 ──────────────────────────────────────────────────
def rule_agent_tool(tool, inp):
    if tool != "Agent":
        return
    st = str(inp.get("subagent_type", "") or "")
    if st.strip().lower() in ("", "general-purpose"):  # 생략하면 general-purpose 로 실행됨
        deny("[fable-gate] general-purpose 대신 `implementer` 서브에이전트를 쓰세요 "
             "(코딩 규칙·진행 로그·반환 형식이 정의돼 있고 연쇄 위임·스킬 호출이 막혀 있습니다).",
             rule="agent_type", subagent_type=st)


def _dest_blocked(text, cwd, data):
    toks = [t for t in text.lstrip(";&| \t\r\n").split()[1:]
            if not t.startswith("-") and t.strip("'\"")]
    if len(toks) < 2:
        return False
    dest, srcs = toks[-1], toks[:-1]
    if is_scratch(dest, cwd, data):
        return False
    return is_code(dest.strip("'\"")) or any(is_code(s.strip("'\"")) for s in srcs)


def rule_shell(tool, cmd, cwd, data, who="main", why="메인 에이전트는 셸로 코드 파일을 수정할 수 없습니다"):
    scan = _MESSAGE_ARG_RE.sub(r"\1\2''", cmd)
    scan_q = _SQ_RE.sub(lambda m: m.group(0) if _SQ_KEEP_RE.fullmatch(m.group(1)) else "''", scan)
    for rx, name, mode in _SHELL_RE.get(tool, ()):
        if mode == "content":
            hit = rx.search(scan)
        else:
            hit = None
            for m in rx.finditer(scan_q):
                if mode == "dest":
                    bad = _dest_blocked(m.group(0), cwd, data)
                else:
                    targets = [t.group(0) for t in _CODE_PATH_RE.finditer(m.group(0))]
                    if mode == "redirect":
                        targets = [t for t in targets if not t.strip("'\"").lower().endswith(REDIRECT_OK_EXTS)]
                    bad = any(not is_scratch(t, cwd, data) for t in targets)
                if bad:
                    hit = m
                    break
        if hit:
            deny(f"[fable-gate] {why}({name}). 구현 작업은 implementer 서브에이전트에 위임하세요.",
                 rule="shell", who=who, tool=tool, pattern=name, cmd=cmd[:300])


def rule_turn_limit(tool, inp, cwd, data):
    path = edit_path(inp, cwd)
    if not is_code(path) or is_scratch(path, cwd, data) or is_generated(path):
        return
    prompt_id = data.get("prompt_id")
    if not prompt_id:
        log("WARN", "prompt_id 없음 — 턴 한도 미적용(fail-open). Claude Code v2.1.271+ 필요", tool=tool, path=path)
        return
    limit = setting_int("FABLE_GATE_LIMIT", cwd, 2)
    session = re.sub(r"[^A-Za-z0-9_-]", "_", data.get("session_id", "default"))
    os.makedirs(COUNTER_DIR, exist_ok=True)
    counter = os.path.join(COUNTER_DIR, f"turn-{session}.json")
    state = {"prompt_id": None, "files": []}
    if os.path.exists(counter):
        with open(counter, encoding="utf-8") as f:
            state = json.load(f)
    if state.get("prompt_id") != prompt_id:
        state = {"prompt_id": prompt_id, "files": []}
    if file_key(path) in (file_key(p) for p in state["files"]):
        return
    if len(state["files"]) >= limit:
        done = ", ".join(os.path.basename(p) for p in state["files"])
        deny(f"[fable-gate] 이번 턴에 메인이 수정할 수 있는 코드 파일 {limit}개를 모두 사용했습니다({done}). "
             f"{os.path.basename(path)} 수정을 포함한 나머지 구현은 implementer 서브에이전트에 위임하세요.",
             rule="turn_limit", path=path, used=state["files"])
    state["files"].append(path)
    tmp = counter + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f)
    os.replace(tmp, counter)


def cleanup_counters(max_age_sec=7 * 86400):
    try:
        now = time.time()
        for name in os.listdir(COUNTER_DIR):
            p = os.path.join(COUNTER_DIR, name)
            if now - os.path.getmtime(p) > max_age_sec:
                os.remove(p)
    except Exception:
        pass


# ── 진입점 ────────────────────────────────────────────────────────────
def main():
    if not fable_on():
        allow()
    data = read_input()
    tool = data.get("tool_name", "")
    inp = data.get("tool_input", {}) or {}
    cwd = data.get("cwd", "")
    if _truthy(setting("FABLE_GATE_OFF", cwd)):
        allow()
    is_sub = bool(data.get("agent_id"))
    agent_type = str(data.get("agent_type", "") or "")
    who = f"sub:{agent_type or '?'}" if is_sub else "main"

    target = edit_path(inp, cwd) if tool in EDIT_TOOLS else ""
    base = target or cwd or os.getcwd()
    home_claude = _under(base, os.path.join(HOME, ".claude"))  # ~/.claude 는 어느 프로젝트에도 속하지 않음
    root = None if home_claude else find_root(base)
    if root is None and not home_claude:
        log("WARN", "프로젝트 루트를 찾지 못해 루트·문서 위치·안내 파일 규칙을 건너뜀", cwd=cwd, target=target)

    # A. 전체 공통
    rule_self_protect(tool, inp, cwd, who)
    # B. 지시 파일
    rule_instruction_files(tool, inp, cwd, data, is_sub, who, root)
    # C. 읽기 전용 에이전트
    if is_sub:
        rule_readonly_agent(tool, inp, cwd, data, agent_type, root)
    # D·E. 전체 공통 (코드 품질·위치)
    rule_full_rewrite(tool, inp, cwd, who, data)
    rule_line_limit(tool, inp, cwd, who, data, root)
    rule_empty_catch(tool, inp, cwd, who, data)
    rule_root_create(tool, inp, cwd, who, data, root)
    rule_md_location(tool, inp, cwd, who, data, root)
    rule_nav_required(tool, inp, cwd, who, data, root)

    if is_sub:
        allow()

    # F. 메인 전용
    rule_agent_tool(tool, inp)
    if tool in SHELL_TOOLS:
        rule_shell(tool, inp.get("command", "") or "", cwd, data)
    elif tool in EDIT_TOOLS:
        rule_turn_limit(tool, inp, cwd, data)
        if int(time.time()) % 50 == 0:
            cleanup_counters()
    allow()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:  # fail-open: 게이트 오류로 작업이 멈추지 않게 하되 반드시 기록
        log("ERROR", f"{type(e).__name__}: {e}")
        sys.exit(0)

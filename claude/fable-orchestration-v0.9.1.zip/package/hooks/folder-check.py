#!/usr/bin/env python3
"""
folder-check.py — 프로젝트 구조 점검 (V5). 메인은 이 결과만 읽는다.

  python3 "$HOME/.claude/fable/hooks/folder-check.py" [프로젝트 경로] [--dry-run] [--json]

검사 항목
  1. 안내 파일 없는 모듈 폴더  (코드 파일이 있는데 상위 어디에도 CLAUDE.md / CLAUDE.local.md 가 없음)
  2. 안내 파일 줄 수 초과        (모듈 CLAUDE.md / CLAUDE.local.md > FABLE_NAV_LINES, 루트 CLAUDE.md > FABLE_ROOT_NAV_LINES=200)
  3. .local.md 만 있는 폴더       (정식 CLAUDE.md 로 승격 필요)
  4. 루트 위반                    (루트 직속의 코드 파일·허용 목록 밖 .md)
  5. 문서 위치 위반               (docs/·점 폴더·fixtures 류 밖의 .md)
  6. 부채                         (종류·기한 지난 항목 / 영구 항목 / 조건 없는 항목, 알 수 없는 종류는 경고)
  7. 큰 파일                      (FABLE_MAX_LINES 초과, [부채] 미등록) — --dry-run 에서는 변경 빈도(git) 함께
  8. 빈 catch                     (--dry-run 전용: V5 에서 "새로 생기는 것만" 막으므로 참고용)
  9. 구조 위반                    (하위 CLAUDE.md: 모듈 아래 폴더의 CLAUDE.md / 깊이: 코드 폴더가 FABLE_MAX_DEPTH 초과)

부채 종류별 제외(docs/design-debt-kinds.md, 매칭은 fable_debt.py): 줄수 → 7, 안내 → 1, 루트 → 4 의 코드 파일,
구조 → 9. 제외된 항목은 "등록된 부채" 절에 따로 보이고 위반 수에서 빠진다. 부채 무시 스위치가 켜지면 제외 없음.
--dry-run : V5 도입 전 영향 조사. 7·8 을 포함해 전부 보고하고, 각 항목에 처리 선택지(고친다/부채/허용)를 표시
--json    : 기계용 출력
아무것도 바꾸지 않는다. 게이트와 같은 기준(루트 판정, 허용 목록)을 쓴다.
"""
import datetime
import fnmatch
import json
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fable_debt  # noqa: E402  같은 폴더의 공통 모듈(설치: ~/.claude/fable/hooks/)
try:
    import gate_common  # noqa: E402  게이트와 같은 settings 읽기 순서(프로젝트 local > 프로젝트 > 전역)
except Exception as _e:  # 복구: 게이트처럼 WARN 후 프로젝트 settings 만 읽는 기존 로직으로 동작
    gate_common = None
    sys.stderr.write("folder-check: WARN gate_common import 실패, 전역 settings fallback 없음: %s: %s\n"
                     % (type(_e).__name__, _e))

CODE_EXTS = (".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".vue", ".svelte", ".java", ".kt", ".kts",
             ".scala", ".go", ".rs", ".c", ".h", ".cc", ".cpp", ".hpp", ".cs", ".swift", ".m", ".mm", ".rb",
             ".php", ".lua", ".dart", ".sh", ".bash", ".zsh", ".sql", ".r", ".jl", ".ex", ".exs", ".erl",
             ".clj", ".hs", ".ml", ".fs", ".pl", ".pm", ".ipynb", ".html", ".css", ".scss", ".sass", ".less",
             ".ps1", ".psm1", ".bat", ".cmd")
SKIP_DIRS = {"node_modules", ".git", "build", ".gradle", "venv", ".venv", "dist", "target", "__pycache__",
             "generated", "out", ".next", "coverage", ".idea", ".vscode"}
DATA_MD_SEGMENTS = {"fixtures", "assets", "resources", "testdata", "test-data", "snapshots"}
ROOT_MD_ALLOW = {"readme.md", "claude.md", "claude.local.md", "agents.md", "changelog.md", "license.md",
                 "contributing.md", "security.md", "code_of_conduct.md"}
ROOT_CODE_ALLOW = {"build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "setup.py",
                   "conftest.py", "manage.py", "gradlew.bat", "index.html", "gulpfile.js", "webpack.config.js",
                   "rollup.config.js", "karma.conf.js"}
ROOT_CODE_ALLOW_GLOBS = ("*.config.js", "*.config.ts", "*.config.mjs", "*.config.cjs", "*.conf.js", "*.conf.ts", ".*")
MAX_DEPTH = 8  # 코드 폴더 깊이(루트 기준 경로 단계 수) 상한 기본값. FABLE_MAX_DEPTH 로 조정
IGNORE_DEBT_KEY = "FABLE_IGNORE_DEBT"  # 스위치: 프로젝트 settings 파일에서만 읽는다(게이트와 같음)
TRUE_VALUES = {"1", "true", "yes", "on"}
EMPTY_CATCH_RES = [
    re.compile(r"\bcatch\b\s*(?:\([^)]*\))?\s*\{\s*\}"),
    re.compile(r"^[ \t]*except\b[^\n:]*:[ \t]*(?:pass|\.\.\.)[ \t]*$", re.M),
    re.compile(r"^[ \t]*except\b[^\n:]*:[ \t]*\n[ \t]*(?:pass|\.\.\.)[ \t]*$", re.M),
]


def find_root(start):
    d = os.path.abspath(start)
    home = os.path.expanduser("~")
    git = dot = top = None
    for _ in range(64):
        if os.path.normcase(d) == os.path.normcase(home):
            break
        if git is None and os.path.exists(os.path.join(d, ".git")):
            git = d
        if dot is None and os.path.isfile(os.path.join(d, ".claude", "CLAUDE.md")):
            dot = d
        if os.path.isfile(os.path.join(d, "CLAUDE.md")):
            top = d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return git or dot or top


def project_env(root):
    if gate_common is not None:
        env = dict(gate_common.project_env(root))  # 프로젝트 local > 프로젝트(위로) > 전역 ~/.claude/settings.json
    else:
        env = _project_files_env(root)
    file_switch = env.get(IGNORE_DEBT_KEY)
    for k, v in os.environ.items():
        if k.startswith("FABLE_"):
            env[k] = v
    # 스위치는 settings 파일 값만 인정(세션 중 심어진 환경변수는 지워도 남으므로 무시)
    env.pop(IGNORE_DEBT_KEY, None)
    if file_switch is not None:
        env[IGNORE_DEBT_KEY] = file_switch
    return env


def _project_files_env(root):
    """gate_common 을 못 읽을 때의 기존 로직: 루트 .claude/settings(.local).json 의 env 만."""
    env = {}
    for name in ("settings.json", "settings.local.json"):
        p = os.path.join(root, ".claude", name)
        if os.path.isfile(p):
            try:
                with open(p, encoding="utf-8-sig") as f:
                    env.update((json.load(f) or {}).get("env") or {})
            except Exception:
                pass
    return env


def env_int(env, name, default):
    try:
        return int(env.get(name, default))
    except (TypeError, ValueError):  # 복구: 잘못된 값은 기본값
        return default


def debt_status(cond, today):
    st = "유효"
    d = re.search(r"(20\d{2}-\d{2}-\d{2})", cond)
    if "영구" in cond:
        st = "영구"
    elif not cond:
        st = "조건 없음"
    elif d:
        try:
            if datetime.date.fromisoformat(d.group(1)) < today:
                st = "기한 지남"
        except ValueError:  # 복구: 달력에 없는 날짜는 보고 상태로 번역
            st = "날짜 오류"
    return st


def count_lines(p):
    try:
        with open(p, "rb") as f:
            return sum(1 for _ in f)
    except OSError:
        return -1


def read_text(p):
    try:
        with open(p, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


def rel(p, root):
    return os.path.relpath(p, root).replace(os.sep, "/")


def git_change_counts(root):
    try:
        out = subprocess.run(["git", "log", "--format=", "--name-only", "-n", "500"], cwd=root,
                             capture_output=True, text=True, timeout=20).stdout
    except Exception:
        return {}
    counts = {}
    for line in out.splitlines():
        line = line.strip()
        if line:
            counts[line] = counts.get(line, 0) + 1
    return counts


def main():
    # Windows 콘솔(cp949)에서 '—'·'→' 출력이 UnicodeEncodeError 로 죽는 것을 막는다(10/9).
    for _s in (sys.stdout, sys.stderr):
        if hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    dry = "--dry-run" in sys.argv
    as_json = "--json" in sys.argv
    start = args[0] if args else os.getcwd()
    root = find_root(start)
    if not root:
        print("프로젝트 루트(.git / CLAUDE.md / .claude/CLAUDE.md)를 찾지 못했습니다:", start)
        return 2
    env = project_env(root)
    nav_lines = int(env.get("FABLE_NAV_LINES", 30))
    max_lines = int(env.get("FABLE_MAX_LINES", 500))
    root_allow = [g.strip() for g in str(env.get("FABLE_ROOT_ALLOW", "")).split(",") if g.strip()]
    md_allow = [g.strip() for g in str(env.get("FABLE_MD_ALLOW", "")).split(",") if g.strip()]
    max_depth = env_int(env, "FABLE_MAX_DEPTH", MAX_DEPTH)
    root_nav_lines = env_int(env, "FABLE_ROOT_NAV_LINES", 200)  # 게이트 규칙 B 와 같은 설정
    ignore_debt = str(env.get(IGNORE_DEBT_KEY) or "").strip().lower() in TRUE_VALUES

    rep = {"root": root, "debt_ignored": ignore_debt, "no_nav": [], "nav_lines": [], "local_only": [],
           "root_violation": [], "md_location": [], "debt": [], "debt_unknown_kind": [], "big_files": [],
           "structure": [], "registered_debt": [], "empty_catch": []}
    today = datetime.date.today()
    changes = git_change_counts(root) if dry else {}

    # 루트 .claude/CLAUDE.md / CLAUDE.md 줄 수
    for rc in (os.path.join(root, ".claude", "CLAUDE.md"), os.path.join(root, "CLAUDE.md")):
        if os.path.isfile(rc) and count_lines(rc) > root_nav_lines:
            rep["nav_lines"].append((rel(rc, root), count_lines(rc), root_nav_lines))

    nav_md_dirs = set()  # CLAUDE.md 가 있는 루트 밖 폴더(normcase)
    depth_raw = []
    for dp, dn, fn in os.walk(root):
        dn[:] = sorted(x for x in dn if x not in SKIP_DIRS and not x.startswith("."))
        is_root = os.path.normcase(dp) == os.path.normcase(root)
        has_nav = "CLAUDE.md" in fn
        has_local = "CLAUDE.local.md" in fn
        if has_local:  # 루트 CLAUDE.local.md 의 부채도 조회 대상(설계 문서 '경로 매칭')
            md = os.path.join(dp, "CLAUDE.local.md")
            for debt in fable_debt.parse_md(md):
                rep["debt"].append((rel(dp, root), debt.kind, debt.token, debt.cond,
                                    debt_status(debt.cond, today)))
                if not debt.known:
                    rep["debt_unknown_kind"].append((rel(md, root), debt.line_no + 1, debt.kind, debt.token))
        if not is_root and (has_nav or has_local):
            for name in ("CLAUDE.md", "CLAUDE.local.md"):
                p = os.path.join(dp, name)
                if os.path.isfile(p) and count_lines(p) > nav_lines:
                    rep["nav_lines"].append((rel(p, root), count_lines(p), nav_lines))
            if has_local and not has_nav:
                rep["local_only"].append(rel(dp, root))
        if not is_root and has_nav:
            up = os.path.dirname(dp)
            while os.path.normcase(up) != os.path.normcase(root) and up != os.path.dirname(up):
                if os.path.normcase(up) in nav_md_dirs:
                    rep["structure"].append((rel(dp, root), f"하위 CLAUDE.md (상위 모듈 {rel(up, root)})"))
                    break
                up = os.path.dirname(up)
            nav_md_dirs.add(os.path.normcase(dp))
        code_files = [f for f in fn if f.lower().endswith(CODE_EXTS)]
        for f in fn:
            p = os.path.join(dp, f)
            low = f.lower()
            if is_root:
                if low.endswith(".md") and low not in ROOT_MD_ALLOW and not any(fnmatch.fnmatch(low, g.lower()) for g in root_allow):
                    rep["root_violation"].append((f, "문서 → docs/"))
                elif low.endswith(CODE_EXTS) and low not in ROOT_CODE_ALLOW \
                        and not any(fnmatch.fnmatch(low, g) for g in ROOT_CODE_ALLOW_GLOBS) \
                        and not any(fnmatch.fnmatch(low, g.lower()) for g in root_allow):
                    rep["root_violation"].append((f, "코드 → 모듈/scripts 폴더 또는 FABLE_ROOT_ALLOW"))
                continue
            parts = rel(p, root).split("/")
            if low.endswith(".md") and low not in ("claude.md", "claude.local.md"):
                if parts[0] != "docs" and not any(x.startswith(".") for x in parts[:-1]) \
                        and not any(x.lower() in DATA_MD_SEGMENTS for x in parts[:-1]) \
                        and not any(fnmatch.fnmatch("/".join(parts), g) for g in md_allow):
                    rep["md_location"].append(rel(p, root))
            if low.endswith(CODE_EXTS):
                n = count_lines(p)
                if n > max_lines:
                    rep["big_files"].append((rel(p, root), n, changes.get(rel(p, root), 0)))
                if dry:
                    c = sum(len(rx.findall(read_text(p))) for rx in EMPTY_CATCH_RES)
                    if c:
                        rep["empty_catch"].append((rel(p, root), c))
        if not is_root and code_files:
            depth = len(rel(dp, root).split("/"))
            if depth > max_depth:
                depth_raw.append((rel(dp, root), f"깊이 {depth} > {max_depth}"))
            d = dp
            covered = False
            while os.path.normcase(d) != os.path.normcase(root):
                if os.path.isfile(os.path.join(d, "CLAUDE.md")) or os.path.isfile(os.path.join(d, "CLAUDE.local.md")):
                    covered = True
                    break
                d = os.path.dirname(d)
            if not covered:
                rep["no_nav"].append((rel(dp, root), len(code_files)))

    # 종류별 부채 제외 → "등록된 부채"(위반 수 제외). 무시 스위치가 켜지면 아무것도 빼지 않는다.
    real_root = os.path.realpath(root)  # fable_debt 는 realpath(8.3 단축명 해소) 경로를 돌려준다

    def exempt(rows, kind, path_of, desc_of, applies=lambda r: True):
        kept = []
        for r in rows:
            debt = None
            if not ignore_debt and applies(r):
                debt = fable_debt.find(os.path.join(root, path_of(r)), root, kind)
            if debt is None:
                kept.append(r)
            else:
                rep["registered_debt"].append((kind, path_of(r), desc_of(r),
                                               f"{rel(debt.md_path, real_root)}:{debt.line_no + 1} {debt.token}"))
        return kept

    rep["big_files"] = exempt(rep["big_files"], "줄수", lambda r: r[0], lambda r: f"{r[1]}줄 > {max_lines}")
    rep["no_nav"] = exempt(rep["no_nav"], "안내", lambda r: r[0], lambda r: f"안내 파일 없음 (코드 {r[1]}개)")
    rep["root_violation"] = exempt(rep["root_violation"], "루트", lambda r: r[0], lambda r: "루트 코드 파일",
                                   applies=lambda r: r[0].lower().endswith(CODE_EXTS))
    rep["structure"] = exempt(rep["structure"], "구조", lambda r: r[0], lambda r: r[1])
    # 모듈 단위로 묶기: 상위가 이미 보고됐으면 하위는 생략
    def top_only(rows):
        out = []
        for row in sorted(rows):
            if not any(row[0].startswith(x[0] + "/") for x in out):
                out.append(row)
        return out
    rep["no_nav"] = top_only(rep["no_nav"])
    rep["structure"] += top_only(exempt(depth_raw, "구조", lambda r: r[0], lambda r: r[1]))

    if as_json:
        print(json.dumps(rep, ensure_ascii=False, indent=1))
        return 0

    print(f"# folder-check {'(dry-run: V5 도입 영향 조사)' if dry else ''} — {root}")
    def section(title, rows, fmt, hint=""):
        print(f"\n## {title}: {len(rows)}건" + (f"  — {hint}" if hint and rows else ""))
        for r in rows[:40]:
            print("  " + fmt(r))
        if len(rows) > 40:
            print(f"  … 외 {len(rows) - 40}건")
    section("안내 파일 없는 모듈 폴더", rep["no_nav"], lambda r: f"{r[0]}  (코드 {r[1]}개)",
            "메인이 인터뷰 후 CLAUDE.md Write, 당장 어려우면 CLAUDE.local.md [임시 안내]")
    section("안내 파일 줄 수 초과", rep["nav_lines"], lambda r: f"{r[0]}  {r[1]}줄 > {r[2]}", "정리해서 상한 이하로")
    section(".local.md 만 있는 폴더", rep["local_only"], lambda r: r, "정식 CLAUDE.md 로 승격")
    section("루트 위반", rep["root_violation"], lambda r: f"{r[0]}  → {r[1]}",
            "옮기거나 FABLE_ROOT_ALLOW 에 추가 (기존 파일 수정은 막히지 않음)")
    section("문서 위치 위반", rep["md_location"], lambda r: r, "docs/ 로 옮기거나 FABLE_MD_ALLOW 에 추가")
    if ignore_debt:
        print("\n(부채 무시 ON: 모든 [부채] 제외를 적용하지 않음)")
    section("부채", rep["debt"], lambda r: f"{r[0]}  {r[1]:<2}  {r[2]}  [{r[4]}]  {r[3]}",
            "기한 지남 → fix/keep/drop, 조건 없음 → keep 으로 조건 추가")
    section("알 수 없는 종류의 부채 (경고: 아무것도 면제하지 않음)", rep["debt_unknown_kind"],
            lambda r: f"{r[0]}:{r[1]}  [부채:{r[2]}] {r[3]}",
            "종류는 " + "·".join(fable_debt.KINDS) + " 중 하나. drop 후 --kind 로 다시 등록")
    section(f"{max_lines}줄 초과 파일 (부채 미등록)", rep["big_files"],
            lambda r: f"{r[0]}  {r[1]}줄" + (f"  변경 {r[2]}회/최근 500커밋" if dry else ""),
            "선택: 고친다(docs/tech-debt.md) / 부채(fable debt add) / 그대로(+30줄까지만 허용)")
    section("구조 위반", rep["structure"], lambda r: f"{r[0]}  {r[1]}",
            "정리하거나 부채(--kind 구조, 폴더)로 등록")
    if dry:
        section("빈 catch (참고)", rep["empty_catch"], lambda r: f"{r[0]}  {r[1]}개",
                "V5 는 새로 생기는 것만 막음. 기존 것은 고칠 때 함께 정리")
    section("등록된 부채 (위반 수에서 제외)", rep["registered_debt"],
            lambda r: f"{r[0]:<2}  {r[1]}  {r[2]}  ← {r[3]}")
    total = sum(len(v) for k, v in rep.items() if isinstance(v, list) and k != "registered_debt")
    print(f"\n합계 {total}건. {'항목별로 고친다/부채/허용을 정한 뒤 설치하세요.' if dry else ''}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

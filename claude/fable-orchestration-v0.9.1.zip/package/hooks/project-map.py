"""project-map.py — 프로젝트 지도 docs/map.md 생성기 (V5).

CLI 전용: project-map.py <루트> [--stdout] [--check] [--quiet] — `fable map`·`fable check` 래퍼가 호출.
stdout 1줄(갱신됨/변경 없음/건너뜀: 이유), --stdout 은 지도 본문. 종료 0, --check 다름만 1. 기록: ~/.claude/fable/map.log
--quiet: SessionStart 훅(startup·resume·compact)용. stderr 무출력, stdout 은 세션 메모만(맥락에 주입됨). stdin 무시.
  지도 처리와 무관하게 마지막에 루트 docs/mem.md 가 있으면 머리 1줄 + 내용을 stdout 에 낸다(FABLE_MEM_LINES 2배 초과분은 생략).
FABLE_MAP_ON_START: "0"·"false"·"off" 면 --quiet 실행은 지도를 건너뛴다(세션 메모 출력은 그대로, 기본 on, gate_common.setting 으로 읽음).
설계: docs/design-project-map.md. Python 3.8, 표준 라이브러리 + 같은 폴더의 gate_common·fable_debt.
"""
import json
import os
import posixpath
import re
import sys
import time
from types import SimpleNamespace

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
try:
    import fable_debt  # 같은 폴더. 부채 줄 파싱·제외 폴더
    import gate_common as gc  # 같은 폴더. find_root·is_code·count_lines·setting
    _IMPORT_ERR = None
except Exception as _e:  # 번역: 오류도 종료 0 이므로 main 에서 기록하고 끝낸다
    fable_debt = gc = None
    _IMPORT_ERR = "%s: %s" % (type(_e).__name__, _e)

HOME = os.path.expanduser("~")
CLAUDE_HOME = os.path.join(HOME, ".claude")
MAP_LOG = os.path.join(CLAUDE_HOME, "fable", "map.log")
LOG_MAX_BYTES = 1000000
NAV = "CLAUDE.md"
MAP_REL = ("docs", "map.md")
MEM_REL = ("docs", "mem.md")
MEM_HEAD = "[fable] 세션 메모 docs/mem.md (메인 참고용 — 서브에이전트에는 전달되지 않음)"
HEADER = "# 프로젝트 지도 (자동 생성 — 수정하지 말 것. `fable map` 으로 재생성)"
ROLE_MAX = 120
BIG_TOP = 10
TRUE = {"1", "true", "yes", "on"}
OFF = {"0", "false", "off"}
STATUS_RE = re.compile(r"^\s*(?:[-*]\s*)?(?:\*\*)?상태(?:\*\*)?\s*[:：]\s*(?:\*\*)?\s*(.*?)\s*(?:\*\*)?\s*$")
ADR_TITLE_PREFIX_RE = re.compile(r"^(?:ADR[-\s]*)?\d+\s*[.:)\-—]?\s*", re.IGNORECASE)
LIST_ITEM_RE = re.compile(r"^(?:[-*]|\d+\.)\s+\S")


def log(level, event, **kv):
    """map.log 에 key=value 1줄. ~/.claude/fable 이 없으면 아무것도 하지 않는다(폴더를 만들지 않음)."""
    if not os.path.isdir(os.path.dirname(MAP_LOG)):
        return
    parts = [time.strftime("%Y-%m-%dT%H:%M:%S"), "level=" + level, "event=" + event]
    for k, v in kv.items():
        s = str(v)
        parts.append("%s=%s" % (k, json.dumps(s, ensure_ascii=False) if (not s or re.search(r'[\s"=]', s)) else s))
    try:
        if os.path.isfile(MAP_LOG) and os.path.getsize(MAP_LOG) > LOG_MAX_BYTES:
            os.replace(MAP_LOG, MAP_LOG + ".1")
        with open(MAP_LOG, "a", encoding="utf-8") as f:
            f.write(" ".join(parts) + "\n")
    except OSError:  # 종단: 로그를 못 남겨도 지도 생성은 계속한다
        return


def under_claude_home(p):
    k, h = (os.path.normcase(os.path.realpath(os.path.abspath(x))) for x in (p, CLAUDE_HOME))
    return k == h or k.startswith(h.rstrip("\\/") + os.sep)


def rel(p, root):
    r = os.path.relpath(p, root).replace("\\", "/")
    return "" if r == "." else r


def lines_of(p):
    try:
        return gc.count_lines(p)
    except OSError:  # 복구: 읽을 수 없는 파일은 0줄로 센다
        return 0


def read_lines(p):
    """텍스트 줄 목록. 없거나 읽기 실패면 None."""
    try:
        with open(p, encoding="utf-8-sig", errors="replace") as f:
            return f.read().splitlines()
    except OSError:  # 복구: 없음으로 처리(호출하는 쪽이 "없음" 표시)
        return None


def cell(s):
    return (s or "-").replace("|", "\\|")


def scan(root, budget):
    """한 번의 os.walk 로 모듈·코드 파일·부채를 모은다. budget 초를 넘기면 멈추고 incomplete.
    modules: rel → [CLAUDE.md 경로, 코드 수] / loose: 루트 직속 폴더 → 모듈 밖 코드 수 / code: (rel, 줄 수, 경로)"""
    sc = SimpleNamespace(modules={}, loose={}, debts=[], code=[], incomplete=False)
    owner = {}  # 폴더 절대 경로 → 가장 가까운 모듈 rel (없으면 None)
    t0 = time.perf_counter()
    for dp, dn, fn in os.walk(root):
        if time.perf_counter() - t0 > budget:
            sc.incomplete = True
            break
        dn[:] = sorted(x for x in dn if x not in fable_debt.SKIP_DIRS and not x.startswith("."))
        r = rel(dp, root)
        if r and NAV in fn:
            sc.modules[r] = [os.path.join(dp, NAV), 0]
            cur = r
        else:
            cur = owner.get(os.path.dirname(dp)) if r else None
        owner[dp] = cur
        if fable_debt.LOCAL_MD in fn:
            sc.debts.extend(fable_debt.parse_md(os.path.join(dp, fable_debt.LOCAL_MD)))
        for f in sorted(fn):
            if not gc.is_code(f):
                continue
            p = os.path.join(dp, f)
            sc.code.append((rel(p, root), lines_of(p), p))
            if cur is not None:
                sc.modules[cur][1] += 1
            elif r:
                top = r.split("/")[0]
                sc.loose[top] = sc.loose.get(top, 0) + 1
    return sc


def nav_info(path):
    """(역할, 테스트, 줄 수). 역할 = 첫 비어 있지 않은 본문 줄(# 제목 제외) 120자 이내,
    테스트 = '테스트' 가 들어간 줄의 첫 코드 스팬."""
    lines = read_lines(path) or []
    role = next((ln.strip() for ln in lines if ln.strip() and not ln.lstrip().startswith("#")), "")
    if len(role) > ROLE_MAX:
        role = role[:ROLE_MAX - 1] + "…"
    test = "-"
    for ln in lines:
        m = re.search(r"`([^`]+)`", ln) if "테스트" in ln else None
        if m:
            test = "`%s`" % m.group(1)
            break
    return role, test, len(lines)


def sec_modules(sc):
    if not sc.modules:
        return ["없음"]
    out = ["| 경로 | 역할 | 테스트 | 파일 수 | 안내 줄 수 |", "|---|---|---|---|---|"]
    for r in sorted(sc.modules):
        path, n = sc.modules[r]
        role, test, nav_n = nav_info(path)
        out.append("| %s | %s | %s | %d | %d |" % (cell(r), cell(role), cell(test), n, nav_n))
    return out


def debt_target(d, root):
    base = rel(d.md_dir, root)
    t = posixpath.normpath(posixpath.join(base, d.token.rstrip("/")) if base else d.token.rstrip("/") or ".")
    return t + "/" if d.is_dir else t


def has_debt(sc, root, kind, path, ignore):
    if ignore:
        return False
    return any(d.kind == kind and fable_debt.matches(d, path) for d in sc.debts)


def sec_loose(sc, root, ignore):
    out = []
    for top in sorted(sc.loose):
        note = " (부채 등록)" if has_debt(sc, root, "안내", os.path.join(root, top) + os.sep, ignore) else ""
        out.append("- %s/ (코드 %d개)%s" % (top, sc.loose[top], note))
    return out or ["없음"]


def roadmap_stage(path):
    lines = read_lines(path)
    if lines is None:
        return "없음"
    heads = [ln[3:].strip() for ln in lines if ln.startswith("## ")]
    cur = next((h for h in heads if "[진행]" in h or "(진행)" in h), None)
    return cur or (heads[0] if heads else "없음")


def adr_lines(adr_dir):
    try:
        names = sorted(n for n in os.listdir(adr_dir) if n.lower().endswith(".md"))
    except OSError:  # 복구: ADR 폴더 없음
        return []
    out = []
    for n in names:
        lines = read_lines(os.path.join(adr_dir, n)) or []
        m = re.match(r"(\d+)", n)
        num = m.group(1) if m else "-"
        title = next((ln[2:].strip() for ln in lines if ln.startswith("# ")), "")
        title = ADR_TITLE_PREFIX_RE.sub("", title) if title else re.sub(r"^\d+[-_ ]*", "", n[:-3]).replace("-", " ")
        status = next((sm.group(1) for sm in map(STATUS_RE.match, lines) if sm and sm.group(1)), "-")
        out.append("%s %s — %s" % (num, title or "-", status))
    return out


def sec_docs(root):
    d = os.path.join(root, "docs")
    out = ["- docs/structure.md: " + ("있음" if os.path.isfile(os.path.join(d, "structure.md")) else "없음"),
           "- docs/roadmap.md 현재 단계: " + roadmap_stage(os.path.join(d, "roadmap.md"))]
    adrs = adr_lines(os.path.join(d, "adr"))
    out += (["- ADR:"] + ["  - " + a for a in adrs]) if adrs else ["- ADR: 없음"]
    req = os.path.join(d, "requirements")
    if os.path.isdir(req):
        n = sum(len(fs) for _, _, fs in os.walk(req))
        out.append("- docs/requirements/: 파일 %d개" % n)
    else:
        out.append("- docs/requirements/: 없음")
    td = read_lines(os.path.join(d, "tech-debt.md"))
    out.append("- docs/tech-debt.md: " + ("없음" if td is None else
                                         "항목 %d개" % sum(1 for ln in td if LIST_ITEM_RE.match(ln))))
    return out


def sec_debts(sc, root):
    if not sc.debts:
        return ["없음"]
    counts = {}
    for d in sc.debts:
        counts[d.kind] = counts.get(d.kind, 0) + 1
    order = [k for k in fable_debt.KINDS if k in counts] + sorted(k for k in counts if k not in fable_debt.KINDS)
    out = ["- 종류별: " + " · ".join("%s %d" % (k, counts[k]) for k in order), "",
           "| 대상 | 종류 | 조건 | 등록일 | 등록 위치 |", "|---|---|---|---|---|"]
    rows = sorted((debt_target(d, root), d.kind, d.cond, d.date, "%s:%d" % (rel(d.md_path, root), d.line_no + 1))
                  for d in sc.debts)
    out += ["| %s |" % " | ".join(cell(c) for c in row) for row in rows]
    return out


def sec_size(sc, root, max_lines, nav_limit, ignore):
    big = sorted(((n, r) for r, n, p in sc.code if n > max_lines and not has_debt(sc, root, "줄수", p, ignore)),
                 key=lambda x: (-x[0], x[1]))
    out = ["- 코드 파일: %d개" % len(sc.code)]
    if big:
        more = " (전체 %d개)" % len(big) if len(big) > BIG_TOP else ""
        out.append("- %d줄 초과 (부채 미등록, 상위 %d개)%s:" % (max_lines, BIG_TOP, more))
        out += ["  - %s %d줄" % (r, n) for n, r in big[:BIG_TOP]]
    else:
        out.append("- %d줄 초과 (부채 미등록): 없음" % max_lines)
    navs = [p for p in (".claude/CLAUDE.md", "CLAUDE.md") if os.path.isfile(os.path.join(root, p))]
    for p in navs:
        out.append("- 루트 안내 파일: %s %d / %d" % (p, lines_of(os.path.join(root, p)), nav_limit))
    if not navs:
        out.append("- 루트 안내 파일: 없음")
    return out


def build(root):
    """(지도 내용, 불완전 여부)."""
    try:
        budget = max(float(gc.setting("FABLE_MAP_BUDGET_SEC", root, "2")), 0.0)
    except ValueError:  # 복구: 잘못된 값은 기본 2초
        budget = 2.0
    max_lines = gc.setting_int("FABLE_MAX_LINES", root, 500)
    nav_limit = gc.setting_int("FABLE_ROOT_NAV_LINES", root, 200)
    ignore = gc.setting("FABLE_IGNORE_DEBT", root).strip().lower() in TRUE
    sc = scan(root, budget)
    out = [HEADER, ""]
    if sc.incomplete:
        out += ["> 불완전(시간 초과): 걷기 예산 %g초 안에 끝나지 않아 일부만 반영" % budget, ""]
    for title, body in (("모듈", sec_modules(sc)), ("안내 파일 없는 폴더", sec_loose(sc, root, ignore)),
                        ("문서", sec_docs(root)), ("부채", sec_debts(sc, root)),
                        ("크기", sec_size(sc, root, max_lines, nav_limit, ignore))):
        out += ["## " + title, ""] + body + [""]
    return "\n".join(out).rstrip("\n") + "\n", sc.incomplete


def current_map(root):
    """기존 docs/map.md (줄바꿈은 \\n 로 정규화). 없으면 None."""
    try:
        with open(os.path.join(root, *MAP_REL), encoding="utf-8-sig") as f:
            return f.read()
    except FileNotFoundError:
        return None


def write_if_changed(root, content):
    """'written' / 'same' / 'nodocs'. docs/ 가 없으면 만들지 않는다."""
    if not os.path.isdir(os.path.join(root, MAP_REL[0])):
        return "nodocs"
    if current_map(root) == content:
        return "same"
    path = os.path.join(root, *MAP_REL)
    with open(path + ".tmp", "w", encoding="utf-8", newline="\n") as f:
        f.write(content)
    os.replace(path + ".tmp", path)
    return "written"


_QUIET = False


def _out(text):
    if _QUIET:
        return
    sys.stdout.buffer.write(text.encode("utf-8"))
    sys.stdout.flush()


def emit_memo(argv):
    """--quiet 전용: Fable 프로젝트 루트의 docs/mem.md 를 머리 1줄과 함께 stdout 에. 없거나 비면 무출력."""
    args = [a for a in argv if not a.startswith("--")]
    start = os.path.abspath(args[0] if args else ".")
    if not os.path.isdir(start):
        return
    root = gc.find_root(start) or start
    if under_claude_home(root) or not os.path.isfile(os.path.join(root, ".claude", NAV)):
        return
    path = os.path.join(root, *MEM_REL)
    if not os.path.isfile(path):
        return
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            text = f.read()
    except OSError as e:  # 종단: 메모를 못 읽어도 세션 시작은 막지 않는다(stdout 비움)
        log("ERROR", "mem_read_failed", root=root, err="%s: %s" % (type(e).__name__, e))
        return
    if not text.strip():
        return
    limit = gc.setting_int("FABLE_MEM_LINES", root, getattr(gc, "DEFAULT_MEM_LINES", 20))
    lines = text.rstrip("\n").split("\n")
    if limit > 0 and len(lines) > limit * 2:
        lines = lines[:limit * 2] + ["(이하 생략 — docs/mem.md 가 %d줄, 상한 %d줄)" % (len(lines), limit)]
    sys.stdout.buffer.write(("\n".join([MEM_HEAD] + lines) + "\n").encode("utf-8"))
    sys.stdout.flush()


def run_cli(argv):
    flags = {a for a in argv if a.startswith("--")}
    args = [a for a in argv if not a.startswith("--")]
    if flags - {"--stdout", "--check", "--quiet"} or len(args) > 1:
        raise ValueError("usage: project-map.py <루트> [--stdout] [--check] [--quiet]")
    start = os.path.abspath(args[0] if args else ".")
    if not os.path.isdir(start):
        raise ValueError("폴더가 아님: %s" % start)
    root = gc.find_root(start) or start
    if "--quiet" in flags and gc.setting("FABLE_MAP_ON_START", root, "1").strip().lower() in OFF:
        return 0
    flags.discard("--quiet")
    skip = ("~/.claude 아래" if under_claude_home(root) else
            ".claude/CLAUDE.md 없음(Fable 프로젝트 아님)" if not os.path.isfile(os.path.join(root, ".claude", NAV))
            else "docs/ 없음" if not os.path.isdir(os.path.join(root, MAP_REL[0])) else None)
    if skip:
        _out("건너뜀: %s\n" % skip)
        return 0
    t0 = time.perf_counter()
    content, inc = build(root)
    if "--stdout" in flags:
        _out(content)
    if flags:
        return (0 if current_map(root) == content else 1) if "--check" in flags else 0
    res = write_if_changed(root, content)
    if res == "written" or inc:
        log("WARN" if inc else "INFO", "map_" + res, root=root, incomplete=inc,
            ms=int((time.perf_counter() - t0) * 1000))
    note = " (불완전: 시간 초과)" if inc else ""
    _out({"written": "갱신됨: docs/map.md", "same": "변경 없음", "nodocs": "건너뜀: docs/ 없음"}[res] + note + "\n")
    return 0


def main(argv):
    global _QUIET
    _QUIET = "--quiet" in argv
    if _IMPORT_ERR:
        log("ERROR", "map_import_failed", err=_IMPORT_ERR)
        if not _QUIET:
            sys.stderr.write("project-map: 오류 %s\n" % _IMPORT_ERR)
        return 0
    try:
        rc = run_cli(argv)
    except Exception as e:  # 종단: 진입점. 로그 1줄 + stderr 안내, 종료 0(오류는 1 로 내지 않는다)
        log("ERROR", "map_failed", argv=" ".join(argv), err="%s: %s" % (type(e).__name__, e))
        if not _QUIET:
            sys.stderr.write("project-map: 오류 %s: %s\n" % (type(e).__name__, e))
        rc = 0
    if _QUIET:
        try:
            emit_memo(argv)
        except Exception as e:  # 종단: 메모 주입 실패는 map.log 만, stdout·stderr 무출력
            log("ERROR", "mem_failed", argv=" ".join(argv), err="%s: %s" % (type(e).__name__, e))
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

#!/usr/bin/env python3
"""
fable-settings.py — settings.json 스위치 (전체 적용 / 프로젝트별 끄기)

env.sh / env.ps1 의 `fable global …`, `fable project …` 가 호출한다.
JSON 편집을 한 곳에 모아 macOS·Linux·Windows 에서 같은 동작을 보장한다.

  global on      ~/.claude/settings.json 의 env 에 서브에이전트 모델 변수 2개 기록
                 → 터미널·IDE 확장·데스크톱 앱 어디서 실행해도 플랜의 실행 모델로 전환 적용
  global off     위 변수 2개 제거 (셸 래퍼만 남음)
  global require-md on|off   전역 settings.json env 에 FABLE_REQUIRE_FOLDER_MD="1"|"0" 기록(off 도 "0", 제거 안 함)
  global map on|off          hooks.SessionStart 에 project-map.py --quiet 항목 추가(교체)/제거
  project require-md off     프로젝트 env 에 "0" 기록(명시적 off — 전역값보다 우선)
  project off    <현재 폴더>/.claude/settings.json 의 env 에 FABLE_GATE_OFF=1 기록
                 → 이 프로젝트에서는 게이트가 전부 허용
  project on     FABLE_GATE_OFF 제거
  project require-md on|off   모듈 안내 파일 없는 곳의 코드 생성 차단 옵트인 (FABLE_REQUIRE_FOLDER_MD)
  status         전체/프로젝트 상태 출력
  debt list                  모든 CLAUDE.local.md 의 [부채] (종류 열) + docs/tech-debt.md 표
  debt add <경로> "<조건>" [--kind 줄수|안내|루트|구조]
                             [부채] 등록 (가장 가까운 상위 모듈의 CLAUDE.local.md). 종류 생략은 줄수.
                             경로 끝 '/' 또는 실제 폴더면 폴더 항목. 안내·구조 는 폴더만, 루트 는 파일만
  debt fix <경로> [--kind]    [부채] 삭제 → docs/tech-debt.md 에 "고친다" 항목(종류 표기)
  debt keep <경로> "<조건>" [--kind]  조건·기한 갱신
  debt drop <경로> [--kind]   해결됨 → 항목 제거. 같은 경로에 종류가 둘 이상이면 --kind 필수
  debt enforce on|off         FABLE_IGNORE_DEBT (프로젝트 env). on 이면 모든 [부채] 제외 무시
  (파싱·매칭·등록 위치는 같은 폴더의 fable_debt.py 공통 모듈. 설계: docs/design-debt-kinds.md)

옵션
  --local        project 명령을 settings.local.json 에 적용 (git 에 커밋되지 않음)
  --model ID     global on 에 쓸 모델 (기본: ~/.claude/fable/plan.env 의 FABLE_EXEC_MODEL, 없으면 claude-opus-5-5)
  --dir PATH     project 명령의 대상 폴더 (기본 현재 폴더)
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fable_debt  # noqa: E402  (같은 폴더의 공통 모듈)
import fable_switches  # noqa: E402  (전역 스위치 조각: SessionStart map 항목·require-md 표시)

PLAN_ROLES = ("implementer", "architect", "deep-reasoner", "runner")


def plan_path():
    return os.path.join(os.path.expanduser("~"), ".claude", "fable", "plan.env")


def plan_value(key, default=None):
    """설치본 plan.env 에서 `KEY=` 로 시작하는 첫 줄의 나머지(실행하지 않고 파싱만). 파일·키가 없으면 default."""
    try:
        with open(plan_path(), encoding="utf-8-sig") as fh:
            for line in fh:
                parts = line.rstrip("\r\n").split("=", 1)  # \r 제거, BOM 은 utf-8-sig 가 걷어 낸다
                if len(parts) == 2 and parts[0] == key:
                    return parts[1]
    except OSError:  # 파일 없음·읽기 불가 = 플랜 이전 설치본 → 기본값(복구)
        return default
    return default


DEFAULT_MODEL = plan_value("FABLE_EXEC_MODEL") or "claude-opus-5-5"
GLOBAL_KEYS = ("CLAUDE_CODE_SUBAGENT_MODEL", "ANTHROPIC_DEFAULT_SONNET_MODEL")
PROJECT_KEY = "FABLE_GATE_OFF"
REQUIRE_KEY = "FABLE_REQUIRE_FOLDER_MD"
IGNORE_DEBT_KEY = "FABLE_IGNORE_DEBT"
NAV_LINES = int(os.environ.get("FABLE_NAV_LINES", "30"))


def load(path):
    if not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8-sig") as f:
        text = f.read().strip()
    data = json.loads(text) if text else {}
    if not isinstance(data, dict):
        print(f"경고: {path} 최상위가 JSON 객체가 아니라 빈 설정으로 취급합니다", file=sys.stderr)
        return {}
    return data


def save(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        with open(path, "rb") as src:
            raw = src.read()
        # .bak 은 직전 상태, .fable-orig.bak 은 이 스크립트가 처음 손대기 전 원본(1회만 생성)
        orig = path + ".fable-orig.bak"
        if not os.path.exists(orig):
            with open(orig, "wb") as dst:
                dst.write(raw)
        with open(path + ".bak", "wb") as dst:
            dst.write(raw)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def set_env(path, updates, remove=()):
    data = load(path)
    env = data.get("env")
    if not isinstance(env, dict):
        env = {}
    env.update(updates)
    for k in remove:
        env.pop(k, None)
    if env:
        data["env"] = env
    else:
        data.pop("env", None)
    save(path, data)


def global_path():
    return os.path.join(os.path.expanduser("~"), ".claude", "settings.json")


def project_path(d, local):
    name = "settings.local.json" if local else "settings.json"
    return os.path.join(os.path.abspath(d), ".claude", name)


def installed_version():
    """설치본 ~/.claude/fable/VERSION 의 값(strip). 없거나 비면 None."""
    p = os.path.join(os.path.expanduser("~"), ".claude", "fable", "VERSION")
    try:
        with open(p, encoding="utf-8-sig") as fh:
            return fh.read().strip() or None
    except OSError:  # 파일 없음·읽기 불가는 "설치본 없음"으로 표시(복구)
        return None


def status(d):
    v = installed_version()
    print(f"version    : {v + ' (설치본)' if v else '설치본 없음 (VERSION 파일 없음 — 설치기 재실행)'}")
    if not os.path.isfile(plan_path()):
        print("plan       : max (plan.env 없음 — 기본값, 설치기 재실행 권장)")
    else:
        custom = plan_value("FABLE_CUSTOM", "")
        print(f"plan       : {plan_value('FABLE_PLAN') or '?'}{' (사용자 변경: ' + custom + ')' if custom else ''}")
        for r in PLAN_ROLES:
            k = r.upper().replace("-", "_")
            print(f"{r:<11}: {plan_value('FABLE_MODEL_' + k) or '?'} ({plan_value('FABLE_EFFORT_' + k) or '모델 기본 medium'})")
    gd = load(global_path())
    g = gd.get("env", {}) or {}
    gm = g.get("CLAUDE_CODE_SUBAGENT_MODEL")
    print(f"global     : {'ON  (' + gm + ')' if gm else 'off (셸 래퍼만 적용)'}")
    print(f"require-md(전역): {fable_switches.require_label(g)}")
    print(f"map on start : {'ON' if fable_switches.has_map(gd) else 'off'}")
    # 게이트와 같은 기준: 현재 폴더에서 위로 올라가며 값이 참(1/true/yes/on)인지 확인
    cur = os.path.abspath(d)
    for _ in range(32):
        for local in (True, False):
            p = project_path(cur, local)
            try:
                e = load(p).get("env", {}) or {}
            except Exception:
                e = {}
            if str(e.get(PROJECT_KEY, "")).strip().lower() in ("1", "true", "yes", "on"):
                print(f"project    : 게이트 OFF ({p})")
                return
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    print("project    : 게이트 on")
    root = find_root(d)
    counts = dict.fromkeys(fable_debt.KINDS, 0)
    unknown = 0
    for debt in all_debts(root):
        if debt.known:
            counts[debt.kind] += 1
        else:
            unknown += 1
    summary = " · ".join(f"{k} {counts[k]}" for k in fable_debt.KINDS)
    if unknown:
        summary += f" · 알 수 없음 {unknown}"
    rl = fable_switches.require_label({**(load(project_path(root, False)).get("env") or {}), **(load(project_path(root, True)).get("env") or {})})
    rl = rl if rl != "미설정" else ("ON" if fable_switches.require_label(g) == "ON" else "off") + " (전역 따름)"
    print(f"require-md : {rl}   부채: {summary}{'  (enforce ON)' if _flag(root, IGNORE_DEBT_KEY) else ''}")


# ── 부채 관리 ──────────────────────────────────────────────────────────
import re
import datetime

# 부채 탐색에서 건너뛸 폴더(기존 동작 유지: fable_debt.SKIP_DIRS 보다 좁다)
DEBT_WALK_SKIP = {"node_modules", ".git", "build", ".gradle", "venv", ".venv", "dist", "target", "__pycache__"}


def find_root(start):
    d = os.path.abspath(start)
    home = os.path.expanduser("~")
    git = dot = top = None
    for _ in range(64):
        if os.path.normcase(d) == os.path.normcase(home):
            break
        if git is None and os.path.exists(os.path.join(d, ".git")):
            git = d
        if dot is None and os.path.isfile(os.path.join(d, ".claude", "CLAUDE.md")):
            dot = d
        if os.path.isfile(os.path.join(d, "CLAUDE.md")):
            top = d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return git or dot or top or os.path.abspath(start)


def read_lines(p):
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig") as f:
        return [l.rstrip("\n") for l in f]


def write_lines(p, lines):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(lines).rstrip("\n") + "\n")


def all_debts(root):
    """루트 아래 모든 CLAUDE.local.md 의 [부채] 줄(fable_debt.Debt)."""
    for md in fable_debt.iter_all_local_mds(root, DEBT_WALK_SKIP):
        for debt in fable_debt.parse_md(md):
            yield debt


def _key(p):
    p = os.path.normcase(os.path.realpath(os.path.abspath(p)))
    return p.lower() if fable_debt.CASE_INSENSITIVE_FS else p


def debt_target(debt):
    """부채 토큰이 가리키는 절대 경로(폴더 항목도 끝 '/' 없이)."""
    return os.path.join(debt.md_dir, debt.token.rstrip("/") or ".")


def same_entry(debt, path, is_dir):
    """같은 경로를 가리키는 항목인가(폴더/파일 구분 일치). 파일은 fable_debt.matches(호환 규칙 포함)."""
    if debt.is_dir != is_dir:
        return False
    if is_dir:
        return _key(debt_target(debt)) == _key(path)
    return fable_debt.matches(debt, path)


def debt_line(kind, tok, cond, date):
    label = "[부채]" if kind == fable_debt.DEFAULT_KIND else f"[부채:{kind}]"
    return f"- {label} {tok} — {cond} (등록 {date})"


def count_file_lines(p):
    try:
        with open(p, "rb") as f:
            return sum(1 for _ in f)
    except OSError:
        return -1


def _flag(root, key):
    e = load(project_path(root, False)).get("env", {}) or {}
    el = load(project_path(root, True)).get("env", {}) or {}
    return str(el.get(key, e.get(key, ""))).lower() in ("1", "true", "yes", "on")


def debt_list(root):
    today = datetime.date.today()
    rows, unknown = [], []
    for debt in all_debts(root):
        target = debt_target(debt)
        if debt.is_dir:
            n = "폴더"
        else:
            n = str(count_file_lines(target) if os.path.isfile(target) else -1)
        cond = debt.cond
        st = "영구" if "영구" in cond else "유효"
        m = re.search(r"(20\d{2}-\d{2}-\d{2})", cond)
        if m and datetime.date.fromisoformat(m.group(1)) < today:
            st = "기한 지남"
        loc = os.path.relpath(debt.md_path, root)
        rows.append((loc, debt.kind, debt.token, n, cond, debt.date, st))
        if not debt.known:
            unknown.append(f"{loc}:{debt.line_no + 1} [부채:{debt.kind}] {debt.token}")
    print(f"부채 enforce : {'ON (모든 [부채] 제외 무시 중)' if _flag(root, IGNORE_DEBT_KEY) else 'off'}")
    if not rows:
        print("[부채] 항목 없음")
    else:
        print(f"{'위치':<26} {'종류':<4} {'경로':<26} {'줄수':>5}  {'상태':<6} 조건 (등록일)")
        for loc, kind, tok, n, cond, date, st in rows:
            print(f"{loc:<26} {kind:<4} {tok:<26} {n:>5}  {st:<6} {cond} ({date or '-'})")
    if unknown:
        print(f"경고: 알 수 없는 종류의 [부채] {len(unknown)}개 — 보호만 되고 아무것도 면제하지 않습니다 "
              f"(종류: {', '.join(fable_debt.KINDS)})")
        for u in unknown:
            print(f"  {u}")
    td = os.path.join(root, "docs", "tech-debt.md")
    if os.path.exists(td):
        items = [l for l in read_lines(td) if l.strip().startswith("- ")]
        print(f"docs/tech-debt.md : 고친다 항목 {len(items)}개")


def _fail(msg):
    print(f"오류: {msg}", file=sys.stderr)
    sys.exit(1)


def _kind_order(k):
    return (fable_debt.KINDS.index(k) if k in fable_debt.KINDS else len(fable_debt.KINDS), k)


def pick_debt(root, path, is_dir, kind):
    """keep/fix/drop 대상 한 줄. 같은 경로에 종류가 둘 이상이면 kind 필수."""
    cands = [d for d in all_debts(root) if same_entry(d, path, is_dir)]
    if kind:
        cands = [d for d in cands if d.kind == kind]
    if not cands:
        _fail(f"[부채{':' + kind if kind else ''}] 항목을 찾지 못했습니다: {path}")
    kinds = sorted({d.kind for d in cands}, key=_kind_order)
    if len(kinds) > 1:
        _fail(f"{path} 에 종류가 다른 [부채] 가 {len(kinds)}개 있습니다. --kind 로 고르세요: {' | '.join(kinds)}")
    return cands[0]


def debt_add(root, path, cond, kind=None, is_dir=False, keep=False):
    today = datetime.date.today().isoformat()
    if keep:
        found = pick_debt(root, path, is_dir, kind)
    else:
        kind = kind or fable_debt.DEFAULT_KIND
        if kind not in fable_debt.KINDS:
            _fail(f"알 수 없는 종류 '{kind}'. 가능한 종류: {' | '.join(fable_debt.KINDS)}")
        if kind in ("안내", "구조") and not is_dir:
            _fail(f"종류 '{kind}' 는 폴더만 등록할 수 있습니다(경로 끝에 '/'): {path}")
        if kind == "루트" and is_dir:
            _fail(f"종류 '루트' 는 파일만 등록할 수 있습니다: {path}")
        found = next((d for d in all_debts(root) if d.kind == kind and same_entry(d, path, is_dir)), None)
    if found:  # 같은 경로·같은 종류 항목은 조건만 갱신(등록일 유지)
        lp, kind, tok = found.md_path, found.kind, found.token
        out = read_lines(lp)
        out[found.line_no] = debt_line(kind, tok, cond, found.date or today)
    else:
        lp = fable_debt.local_md_for(path, root)
        tok = fable_debt.rel_token(lp, path, is_dir)
        out = read_lines(lp)
        if not out:
            out.append(f"# {os.path.basename(os.path.dirname(lp))}/ 예외·임시 (CLAUDE.local.md)")
        out.append(debt_line(kind, tok, cond, today))
    if len(out) > NAV_LINES:  # 게이트·folder-check 와 같은 기준: 빈 줄 포함 전체 줄 수
        _fail(f"{lp} 가 {NAV_LINES}줄을 넘습니다. 지난 부채를 fix/drop 으로 정리한 뒤 다시 등록하세요.")
    write_lines(lp, out)
    print(f"{'keep' if keep else 'add'}: {lp}")
    print(f"  {debt_line(kind, tok, cond, found.date if found and found.date else today)}")


def debt_remove(root, path, to_fix, kind=None, is_dir=False):
    found = pick_debt(root, path, is_dir, kind)
    p, tok, cond, kind = found.md_path, found.token, found.cond, found.kind
    lines = read_lines(p)
    del lines[found.line_no]
    if all(l.strip().startswith("#") or not l.strip() for l in lines):
        os.remove(p)
        print(f"{os.path.relpath(p, root)} 에 남은 항목이 없어 파일을 삭제했습니다")
    else:
        write_lines(p, lines)
    if to_fix:
        td = os.path.join(root, "docs", "tech-debt.md")
        tl = read_lines(td) or ["# 기술 부채 (고친다로 결정된 항목)", "",
                                "로드맵이 생기면 단계로 흡수한다. 형식: - [종류] <경로> — <이전 조건> (결정 YYYY-MM-DD)", ""]
        rel = os.path.relpath(debt_target(found), root).replace(os.sep, "/") + ("/" if found.is_dir else "")
        tl.append(f"- [{kind}] {rel} — {cond} (결정 {datetime.date.today().isoformat()})")
        write_lines(td, tl)
        if kind == fable_debt.DEFAULT_KIND:
            print("fix : [부채] 제거 → docs/tech-debt.md 에 추가. 줄 수 상한이 다시 적용됩니다 "
                  f"(+{os.environ.get('FABLE_OVER_GROWTH', '30')}줄까지만).")
        else:
            print(f"fix : [부채:{kind}] 제거 → docs/tech-debt.md 에 추가. '{kind}' 면제가 해제됩니다.")
    else:
        print(f"drop: [부채:{kind}] 제거 ({tok})")


def debt_enforce(root, on):
    p = project_path(root, True)
    if on:
        set_env(p, {IGNORE_DEBT_KEY: "1"})
        print(f"enforce ON : {p} 에 {IGNORE_DEBT_KEY}=1 — 모든 [부채] 제외를 무시합니다 (새 세션부터)")
    else:
        for lp in (project_path(root, False), project_path(root, True)):
            if os.path.exists(lp) and IGNORE_DEBT_KEY in (load(lp).get("env") or {}):
                set_env(lp, {}, remove=(IGNORE_DEBT_KEY,))
        print("enforce off: [부채] 제외가 다시 적용됩니다 (새 세션부터)")


def debt_main(argv):
    ap = argparse.ArgumentParser(prog="fable debt")
    ap.add_argument("cmd", choices=["list", "add", "fix", "keep", "drop", "enforce"])
    ap.add_argument("target", nargs="?")
    ap.add_argument("cond", nargs="?")
    ap.add_argument("--kind", help="|".join(fable_debt.KINDS) + f" (add 기본 {fable_debt.DEFAULT_KIND})")
    ap.add_argument("--dir", default=os.getcwd())
    a = ap.parse_args(argv)
    root = find_root(a.dir)
    if a.cmd == "list":
        debt_list(root)
    elif a.cmd == "enforce":
        if a.target not in ("on", "off"):
            ap.error("enforce 에는 on|off 가 필요합니다")
        debt_enforce(root, a.target == "on")
    else:
        if not a.target:
            ap.error(f"{a.cmd} 에는 파일 경로가 필요합니다")
        path = os.path.abspath(a.target if os.path.isabs(a.target) else os.path.join(a.dir, a.target))
        is_dir = a.target.endswith(("/", "\\")) or os.path.isdir(path)  # 끝 '/' 또는 실제 폴더 = 폴더 항목
        if a.cmd in ("add", "keep"):
            if not a.cond:
                ap.error(f"{a.cmd} 에는 조건(또는 '영구')이 필요합니다")
            debt_add(root, path, a.cond, kind=a.kind, is_dir=is_dir, keep=(a.cmd == "keep"))
        else:
            debt_remove(root, path, to_fix=(a.cmd == "fix"), kind=a.kind, is_dir=is_dir)


def main():
    # Windows 콘솔·파이프(cp949)에서 '—'·'→' 출력이 UnicodeEncodeError 로 죽는 것을 막는다(10/9).
    for _s in (sys.stdout, sys.stderr):
        if hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    if len(sys.argv) > 1 and sys.argv[1] == "debt":
        return debt_main(sys.argv[2:])
    ap = argparse.ArgumentParser()
    ap.add_argument("scope", choices=["global", "project", "status"])
    ap.add_argument("action", nargs="?", choices=["on", "off", "require-md", "map"])
    ap.add_argument("value", nargs="?", choices=["on", "off"])
    ap.add_argument("--local", action="store_true")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--dir", default=os.getcwd())
    a = ap.parse_args()

    if a.scope == "status":
        status(a.dir)
        return
    if not a.action:
        ap.error(f"{a.scope} 에는 on|off 가 필요합니다")

    if a.action in ("require-md", "map") and not a.value:
        ap.error(f"{a.action} 에는 on|off 가 필요합니다")
    if a.action == "map" and a.scope != "global":
        ap.error("map 은 global 에서만 씁니다 (프로젝트별 끄기는 FABLE_MAP_ON_START=0)")
    if a.scope == "global":
        p = global_path()
        if a.action == "require-md":  # off 도 "0" 기록(제거하면 다음 재설치에서 다시 켜진다)
            set_env(p, {REQUIRE_KEY: "1" if a.value == "on" else "0"})
            print(f"global require-md {a.value.upper() if a.value == 'on' else 'off'}: {p} 에 {REQUIRE_KEY}={'1' if a.value == 'on' else '0'} 기록 (새 세션부터)")
        elif a.action == "map":
            data, removed = fable_switches.set_map(load(p), a.value == "on")
            save(p, data)
            print(f"global map {'ON : SessionStart 에 project-map 항목 등록' if a.value == 'on' else 'off: project-map 항목 ' + str(removed) + '개 제거'} ({p}, 새 세션부터)")
        elif a.action == "on":
            set_env(p, {k: a.model for k in GLOBAL_KEYS})
            print(f"global ON : {p} 에 서브에이전트 모델={a.model} 기록 (새 세션부터, IDE·앱 포함)")
        else:
            set_env(p, {}, remove=GLOBAL_KEYS)
            print(f"global off: {p} 에서 모델 변수 제거 (셸 래퍼만 적용)")
    elif a.action == "require-md":
        root = find_root(a.dir)  # 하위 폴더에서 실행해도 프로젝트 루트의 .claude/ 에 기록(debt enforce 와 같은 기준)
        p = project_path(root, a.local)
        if a.value == "on":
            set_env(p, {REQUIRE_KEY: "1"})
            print(f"require-md ON : {p} 에 {REQUIRE_KEY}=1 — 안내 파일 없는 폴더의 코드 생성 차단 (새 세션부터)")
        else:  # 제거가 아니라 "0" — 전역 ON 보다 우선하는 명시적 off
            for lp in {p} | {q for q in (project_path(root, False), project_path(root, True)) if REQUIRE_KEY in (load(q).get("env") or {})}:
                set_env(lp, {REQUIRE_KEY: "0"})
            print(f"require-md off: {p} 에 {REQUIRE_KEY}=0 기록 — 전역값과 무관하게 이 프로젝트는 off (새 세션부터)")
    else:
        root = find_root(a.dir)  # 하위 폴더에서 실행해도 프로젝트 루트의 .claude/ 에 기록
        p = project_path(root, a.local)
        if a.action == "off":
            set_env(p, {PROJECT_KEY: "1"})
            print(f"project OFF: {p} 에 {PROJECT_KEY}=1 기록 — 이 프로젝트에서 게이트 비활성 (새 세션부터)")
        else:
            for lp in (project_path(root, False), project_path(root, True)):
                if os.path.exists(lp) and PROJECT_KEY in (load(lp).get("env") or {}):
                    set_env(lp, {}, remove=(PROJECT_KEY,))
                    print(f"project on : {lp} 에서 {PROJECT_KEY} 제거")
            print("project on : 게이트 활성 (새 세션부터)")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"오류: {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)

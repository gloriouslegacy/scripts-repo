"""부채([부채]) 줄 파싱·경로 매칭 공통 모듈 (V5).

orchestration-gate.py · fable-settings.py · folder-check.py 가 같은 폴더에서 import 한다.
Python 3.8 호환, 표준 라이브러리만. 설계: docs/design-debt-kinds.md
부채 무시 스위치(enforce on → 모든 종류 무시) 판정은 호출하는 쪽이 한다.
"""
import logging
import os
import re
import sys

KINDS = ("줄수", "안내", "루트", "구조")
DEFAULT_KIND = "줄수"
LOCAL_MD = "CLAUDE.local.md"
NAV_MDS = ("CLAUDE.md", LOCAL_MD)
DEBT_RE = re.compile(
    r"^\s*-\s*\[부채(?::([^\]\s]+))?\]\s*(\S+)\s*[—-]\s*(.*?)(?:\s*\(등록\s*([0-9-]+)\))?\s*$")
# 줄 보호용: DEBT_RE 의 상위 집합. 형식이 덜 갖춰졌거나 종류를 알 수 없어도 보호한다.
_PROTECT_RE = re.compile(r"^\s*-\s*\[부채(?::[^\]]*)?\]")
SKIP_DIRS = frozenset({"node_modules", ".git", "build", ".gradle", "venv", ".venv", "dist", "target",
                       "__pycache__", "generated", "out", ".next", "coverage", ".idea", ".vscode"})
CASE_INSENSITIVE_FS = sys.platform in ("win32", "darwin")
MAX_UP = 64

_log = logging.getLogger("fable_debt")
_log.addHandler(logging.NullHandler())


class Debt(object):
    """CLAUDE.local.md 의 [부채] 한 줄. line_no 는 0부터(파일 줄 목록의 인덱스)."""
    __slots__ = ("md_path", "md_dir", "line_no", "raw", "kind", "token", "cond", "date", "is_dir")

    def __init__(self, md_path, line_no, raw, m):
        self.md_path = md_path
        self.md_dir = os.path.dirname(md_path)
        self.line_no = line_no
        self.raw = raw
        self.kind = m.group(1) or DEFAULT_KIND
        self.token = m.group(2).replace("\\", "/")
        self.cond = (m.group(3) or "").strip()
        self.date = m.group(4) or ""
        self.is_dir = self.token.endswith("/")

    @property
    def known(self):
        """알 수 있는 종류인가. 아니면 보호만 되고 아무것도 면제하지 않는다(경고 대상)."""
        return self.kind in KINDS

    def __repr__(self):
        return "Debt(kind=%s, token=%s, md=%s:%d)" % (self.kind, self.token, self.md_path, self.line_no)


# ── 경로 정규화 ──────────────────────────────────────────────────────
def _real(p):
    """realpath(8.3 단축명·심볼릭 링크 해소). 대소문자는 유지 — 표시·등록용."""
    try:
        return os.path.realpath(os.path.abspath(p))
    except (OSError, ValueError):  # 복구: 해소 불가 경로는 abspath 로 대체
        return os.path.abspath(p)


def _norm(p):
    """비교용 키. realpath + normcase, Windows·macOS 는 소문자."""
    p = os.path.normcase(os.path.normpath(_real(p)))
    return p.lower() if CASE_INSENSITIVE_FS else p


def _fold(s):
    return s.lower() if CASE_INSENSITIVE_FS else s


def _under(child, parent):
    """둘 다 _norm 된 값. child 가 parent 자신이거나 그 아래면 True."""
    if child == parent:
        return True
    pre = parent if parent.endswith(os.sep) else parent + os.sep
    return child.startswith(pre)


def _is_dir(p):
    return os.path.isdir(p) or p.endswith(("/", "\\"))


# ── 줄 판정·파싱 ─────────────────────────────────────────────────────
def is_debt_line(line):
    """종류 불문(알 수 없는 종류 포함) [부채…] 줄인가 — 게이트 줄 보호용."""
    return bool(_PROTECT_RE.match(line or ""))


def debt_line_set(text):
    """보호용 비교 집합: [부채…] 줄(앞뒤 공백 제거)."""
    return {ln.strip() for ln in (text or "").splitlines() if is_debt_line(ln)}


def parse_md(md_path):
    """CLAUDE.local.md 의 [부채] 줄 목록. 읽기 실패는 빈 리스트."""
    try:
        with open(md_path, encoding="utf-8-sig") as f:
            lines = f.read().split("\n")
    except (OSError, UnicodeDecodeError) as e:  # 복구: 부채 없음으로 처리
        if os.path.exists(md_path):
            _log.warning("debt_md_read_failed path=%s err=%s", md_path, e)
        return []
    md_path = os.path.abspath(md_path)
    out = []
    for i, ln in enumerate(lines):
        m = DEBT_RE.match(ln)
        if m:
            out.append(Debt(md_path, i, ln, m))
    return out


# ── CLAUDE.local.md 찾기 ─────────────────────────────────────────────
def iter_local_mds_up(start_dir, root):
    """start_dir → 루트(포함) 순서로 있는 CLAUDE.local.md 경로. root None 이면 최대 64단계.
    start_dir 가 root 밖이면 아무것도 내지 않는다."""
    d = _real(start_dir)
    stop = _norm(root) if root else None
    if stop is not None and not _under(_norm(d), stop):
        return
    for _ in range(MAX_UP):
        p = os.path.join(d, LOCAL_MD)
        if os.path.isfile(p):
            yield p
        if stop is not None and _norm(d) == stop:
            return
        parent = os.path.dirname(d)
        if parent == d:
            return
        d = parent


def iter_all_local_mds(root, skip_dirs=None):
    """root 아래 모든 CLAUDE.local.md (os.walk, skip_dirs 기본 SKIP_DIRS)."""
    skip = SKIP_DIRS if skip_dirs is None else set(skip_dirs)
    for dp, dn, fn in os.walk(root):
        dn[:] = sorted(x for x in dn if x not in skip)
        if LOCAL_MD in fn:
            yield os.path.join(dp, LOCAL_MD)


# ── 매칭 ─────────────────────────────────────────────────────────────
def matches(debt, target_path):
    """토큰은 md_dir 기준 상대 경로. 끝 '/' 는 폴더(자신·하위 전부).
    파일 토큰은 정확히 일치, 또는 (호환) '/' 없는 토큰이 basename 과 같고 대상이 md_dir 아래."""
    t = _norm(target_path)
    base = _norm(os.path.join(debt.md_dir, debt.token.rstrip("/") or "."))
    if debt.is_dir:
        return _under(t, base)
    if t == base:
        return True
    if "/" in debt.token:
        return False
    names = {os.path.basename(t), _fold(os.path.basename(os.path.abspath(target_path)))}
    return _fold(debt.token) in names and _under(t, _norm(debt.md_dir))


def find(target_path, root, kind):
    """대상의 폴더(폴더면 자신)부터 루트(포함)까지 올라가며 종류가 같고 일치하는 첫 부채. 없으면 None."""
    if kind not in KINDS:
        return None
    start = target_path if _is_dir(target_path) else os.path.dirname(os.path.abspath(target_path))
    for md in iter_local_mds_up(start, root):
        for debt in parse_md(md):
            if debt.kind == kind and matches(debt, target_path):
                return debt
    return None


# ── 등록 ─────────────────────────────────────────────────────────────
def rel_token(md_path, target_path, is_dir):
    """md_path 가 있는 폴더 기준 '/' 구분 상대 경로. 폴더는 끝에 '/'."""
    rel = os.path.relpath(_real(target_path), os.path.dirname(_real(md_path))).replace("\\", "/")
    return rel.rstrip("/") + "/" if is_dir else rel


def local_md_for(target_path, root):
    """등록 위치. 파일은 그 폴더부터, 폴더는 부모부터 위로 올라가(루트 제외) 안내 파일이 있는
    첫 폴더의 CLAUDE.local.md. 없으면 대상 바로 위 폴더(루트 직속이면 루트)."""
    r = _real(root)
    nr = _norm(r)
    d = os.path.dirname(_real(target_path))  # 파일이면 그 폴더, 폴더면 부모
    if not _under(_norm(d), nr):
        return os.path.join(r, LOCAL_MD)
    first = None
    for _ in range(MAX_UP):
        if _norm(d) == nr:
            break
        if first is None:
            first = d
        if any(os.path.isfile(os.path.join(d, n)) for n in NAV_MDS):
            return os.path.join(d, LOCAL_MD)
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return os.path.join(first or r, LOCAL_MD)

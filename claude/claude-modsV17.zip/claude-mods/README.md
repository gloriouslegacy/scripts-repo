# my-mods

Three Claude Code mods (plugins of function hooks). Requires **Claude Code 2.1.287 or later**.
Korean guide: [README.ko.md](README.ko.md)

---

## Commands at a glance

| Command | Example | Does |
|---|---|---|
| `/pin <note>` | `/pin upload to the drive when the render is done` | Pin a note and send it to Claude |
| `/pin ! <note>` | `/pin ! check the .env keys before deploying` | Same, marked important (red ★) |
| `/pin !! <note>` | `/pin !! stop, keep the old API` | Stop Claude's running turn and send the note now |
| `/pin done N` / `/pin undo N` | `/pin done 2` | Check off / reopen pin 2 |
| `/pin rm N` | `/pin rm 1` | Remove pin 1 |
| `/pin clear` | `/pin clear` | Remove every done pin |
| `/pin list` | `/pin list` | Print the board |
| `/pin` | `/pin` | Fold or unfold the board |
| `/change-tutor` | `/change-tutor` | Open the Change Notes pane |
| `/tcw-usage` | `/tcw-usage` | Read the usage endpoint now and print its answer |

---

## 1. What each mod does

### tcw (token-cache-weather) — the session at a glance

Two lines under the prompt (`tcw.layout`: `bottom`, the default), no prefix:

```
Opus 5.5 · high · ⤷ Sonnet › Haiku   ⎇ main ↑2 ~3   CT 67%
0% (2d 11h)  |  98% (2h16m)  |  82% (2d 12h)
```

With `tcw.layout` = `band` the same two lines sit above the prompt. With `tcw.layout` = `line` the same goes in one status line under the prompt (Claude Code prefixes it with `⚠ tcw:`, which is why the plugin's name is short; the folder is still `token-cache-weather`).

| Part | Meaning |
|---|---|
| `Opus 5.5` | The current model (`(1M)` on a 1M-context variant); follows `/model` switches |
| `high` | Reasoning effort of the last response (`low` / `medium` / `high` / `xhigh` / `max`; `--effort`, `/effort`); before the first response, the model's own `effortLevel` from settings (`{ "claude-opus-5-5": { "effortLevel": "high" } }`), else the top-level `effortLevel` |
| `⤷ Sonnet › Haiku` | The fallback chain from `fallbackModel` in settings.json. While a fallback is answering it reads `⤷ now Sonnet 4.5`. A chain given only with `--fallback-model` is not visible to mods, so it shows only once a fallback answers |
| `⎇ main ↑2 ~3` | Git status: branch (`@1a2b3c4` when detached), `↑` to push, `↓` to pull, `+` staged, `~` modified, `?` untracked, `!` conflicts; `✓` when clean. Left out outside a repository |
| `CT 67%` | Context window fill; `-%` before the first response. Turns yellow past 50% and red past 80% |
| `98% (2h16m)` · `82% (2d 12h)` | Usage left in the 5-hour and weekly (all models) windows and time to reset; green, yellow under 50%, red under 20%. Subscriptions only |
| `0% (2d 11h)` | A model-specific weekly window, unnamed and always first; shown only for models the account has a separate cap on, as `/usage` shows it (one per model that has its own cap). Read from the account usage endpoint at most every 5 minutes, no tokens; off with `tcw.plan` = `false`. `/tcw-usage` reads the endpoint now and shows what it answered |

Refreshes every 15 seconds and whenever a response arrives. Shows a toast once, 5 minutes before the prompt cache expires (1 minute for a 5-minute cache). **Uses no tokens**: it only reads figures the engine already has.

### change-tutor — Change Notes pane

Every file Claude creates or edits (Edit / Write) becomes a note with: the file and `+added -removed · time`, **🙋 Request** (your prompt for that turn), **🤔 Why it changed** (what Claude said right before the change) and the diff. From a note you can ask for **💡 Explain simply** or a four-choice **❓ Quiz**. Edits made by subagents go to their own **sub_Diff** tab, each with the agent's type and task (`🤖 implementer · Fix the parser`) and what that subagent said right before the change. Notes are kept across sessions (latest 100 main-thread notes and latest 100 subagent notes). The status line shows `📘 N change notes · 🤖 M sub_Diff`.

### pinboard — notes pinned above the prompt

`/pin <note>` pins a note on a small board above the prompt that stays put however long the conversation gets. Start the note with `!` to mark it important (red, with ★), or with `!!` to interrupt Claude (below). Each row has `[✓]` to check it off (struck through, `[↺]` to reopen) and `[×]` on the right to remove it. The board is kept per folder: a new session in the same folder shows it as it was left.

Each new pin is also **sent to Claude at once**, and `/pin` runs even while Claude is working:

- Claude idle: the pin goes in as your prompt (`📌 Pin #1: …`), so Claude starts on it right away.
- Claude working: the pin is added to the conversation as a note from you and read at Claude's next step (when its current reply or tool call finishes), the same moment a message typed mid-turn is read. If the turn ends before another step reads it, it follows as a prompt (`📌 Pinned while you were working: …`).
- Claude working, `/pin !! <note>`: the running turn is stopped and the pin goes in at once as your prompt (`📌 Pin #1 (urgent — I stopped your turn for this): …`). Use it to change course now; a half-done reply or tool call is cut off, and Claude picks the work up again after reading the pin.

Off with `pinboard.deliver` = `false`.

| Command | Does |
|---|---|
| `/pin <note>`, `/pin ! <note>` | Pin a note (important with `!`) and send it to Claude |
| `/pin !! <note>` | Pin it as important, stop Claude's running turn and send it at once |
| `/pin done N`, `/pin undo N` | Check off / reopen pin N |
| `/pin rm N` | Remove pin N (same as its `[×]`) |
| `/pin clear` | Remove the done pins |
| `/pin list` | Print the board |
| `/pin` | Fold or unfold the board |

---

## 2. Install

Unzip to a folder you will keep, e.g. `C:\Users\<you>\claude-mods` or `~/claude-mods`, and run in that folder:

```bash
claude plugin marketplace add ./
claude plugin install tcw@my-mods --scope user
claude plugin install change-tutor@my-mods --scope user
claude plugin install pinboard@my-mods --scope user
```

- `--scope user` loads them in every project, in the terminal and in the desktop app's Code tab. Install only the ones you want.
- An "option not yet set" note at install is fine: defaults apply. Add `--config ttl=1h` / `--config model=haiku` to set them up front.
- The plugins are read straight from this folder: **do not move or delete it**. After editing a file, run `/reload-plugins`.

Other ways to load them:

```bash
# one session only
claude --plugin-dir ./token-cache-weather --plugin-dir ./change-tutor --plugin-dir ./pinboard
```

```json
// ~/.claude/settings.json — always load (absolute paths; ";" on Windows, ":" on macOS/Linux)
{ "env": { "CLAUDE_CODE_PLUGIN_DIRS": "C:\\Users\\<you>\\claude-mods\\token-cache-weather;C:\\Users\\<you>\\claude-mods\\pinboard" } }
```

Update: unzip the new version over the same folder, then run `claude plugin marketplace update my-mods` and `/reload-plugins` (or start a new session). Settings you changed in `/config` are kept.

Remove: `claude plugin uninstall <name>@my-mods`.

blast-radius and replay-theater are no longer part of this set. If you installed them before, remove them with `claude plugin uninstall blast-radius@my-mods` and `claude plugin uninstall replay-theater@my-mods`.

---

## 3. Usage

### tcw (token-cache-weather)

Nothing to do: the lines appear when a session starts. To show the fallback chain all the time, put it in `~/.claude/settings.json`: `{ "fallbackModel": ["sonnet", "haiku"] }`.

| Setting (`/config`) | Values | Default |
|---|---|---|
| `tcw.layout` | `bottom` (2 lines under the prompt), `band` (2 lines above it), `line` (one status line under it) | `bottom` |
| `tcw.style` | `plain`, `chip` (each line on a shaded background), `box` (one rounded frame; two rows taller) — band only | `plain` |
| `tcw.model` | `true`, `false` — show the model, effort and fallback chain | `true` |
| `tcw.weather` | `true`, `false` — show `CT 67%` (context fill) | `true` |
| `tcw.plan` | `true`, `false` — show the model-specific weekly window (read every 5 minutes, no tokens) | `true` |
| `tcw.git` | `true`, `false` — show the git part (runs `git status` on each refresh, no tokens) | `true` |
| `tcw.ttl` | `1h`, `5m` — the prompt-cache TTL the expiry toast counts from | `1h` |

`/tcw-usage` reads the account usage endpoint right away and prints what it answered: use it when the model-specific window looks wrong or missing.

### change-tutor

- The pane opens by itself on the first change of a session; open it any time with **`/change-tutor`**.
- Keys work while the pane has focus (click it, or `ctrl+x tab`):

| Key | Action |
|---|---|
| `h` / `l` | Previous / next note |
| `e` | 💡 Explain simply |
| `q` | ❓ Quiz (then `1`–`4` to answer) |
| `v` | ⤢ Show all / ⤡ Collapse the diff |
| `c` | Copy diff |

- Tabs **This session** / **All notes** (the main thread's changes), **sub_Diff** (subagents' changes) and **Latest** are buttons. The pane jumps to the tab of the newest note.
- Explain and Quiz call a model only when pressed (tokens are spent then).

| Setting (`/config`) | Values | Default |
|---|---|---|
| `change-tutor.model` | `haiku`, `sonnet`, `opus` | `haiku` |

### pinboard

- Type **`/pin <note>`** at any time, even while Claude is working; `/pin ! <note>` marks it important, `/pin !! <note>` also stops Claude's turn so it reads the pin now. The other commands are in the table in section 1.
- Click `[✓]` / `[↺]` / `[×]` on a row, or focus the band with `ctrl+x tab` and move to the button. `[Hide]` / `[Show]` folds the board to its header line.
- A new pin reaches Claude at once: when idle it is sent as your prompt and Claude starts on it; mid-turn it is read at Claude's next step (or sent as a prompt when the turn ends, if no step read it). Checking off or removing a pin is not sent.
- Pins are saved per folder (latest 50) and come back in any new session started in that folder.

| Setting (`/config`) | Values | Default |
|---|---|---|
| `pinboard.deliver` | `true`, `false` — send each new pin to Claude | `true` |

---

## Check

```bash
claude plugin validate ./<mod>
claude plugin test ./<mod>
```

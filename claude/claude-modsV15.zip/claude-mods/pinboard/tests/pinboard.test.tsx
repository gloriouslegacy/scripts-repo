import { expect, mock, test } from 'claude-code/testing'

import { delivery, header, listing, parse } from '../hooks/pins'

test('parsing /pin', () => {
  expect(parse('! check the .env keys')).toEqual({ kind: 'add', text: 'check the .env keys', important: true })
  expect(parse('upload to the drive')).toEqual({ kind: 'add', text: 'upload to the drive', important: false })
  expect(parse('done 2')).toEqual({ kind: 'done', n: 2 })
  expect(parse('RM 1')).toEqual({ kind: 'rm', n: 1 })
  expect(parse('')).toEqual({ kind: 'fold' })
  expect(parse('!')).toEqual({ kind: 'help' })
  const pin = { id: 'a', text: 'x', important: true, done: false, at: 0 }
  expect(delivery(pin, 3)).toContain('#3 (marked important): x')
  expect(header([pin, { ...pin, id: 'b', done: true }])).toBe('📌 Pins 1 (done 1)')
  expect(listing([pin])).toBe('1. [ ] ★ x')
})

for (const surface of ['terminal', 'desktop'] as const) {
  test(`pins reach Claude, show above the prompt, check off and go with × on ${surface}`, async ($, on) => {
    mock.clock(on, { now: 1_000 })
    mock.store(on)
    const session = mock.session(on)
    on('session.cwd', () => ({ value: '/p/project' }))
    on('session.start', () => ({ cwd: '/p/project' }))
    on('command.register', (_$, e) => ({ value: { command: e.name } }))
    on('ui.render', ($$, e) => {
      const { Text } = $$.ui.resolve(e)
      return <Text>other row</Text>
    })

    await $.session.start({ cwd: '/p/project', surface, isInteractive: true })
    const first = await $.command.run({ command: 'pin', args: '! check the .env keys before deploying' })
    expect(first.text).toBe('📌 Pinned #1 and sent to Claude: check the .env keys before deploying')
    await $.command.run({ command: 'pin', args: 'upload to the drive when the render is done' })

    const rows = session.appended()
    expect(rows.length).toBe(2)
    expect(JSON.stringify(rows[0]?.message)).toContain('pinned note #1 (marked important): check the .env keys')

    const props = { hasSurvey: false, isWorking: true, maxRows: 10, bodyColumns: 100, scroll: { offset: 0, bodyRows: 10 }, view: {} }
    const band = await $.ui.mount({ plugin: 'pinboard', surface, component: 'AbovePrompt', props })
    expect(await band.find({ text: '📌 Pins 2' })).toBeDefined()
    expect(await band.find({ text: '1. ★ check the .env keys before deploying' })).toBeDefined()
    expect(await band.find({ text: 'other row' })).toBeDefined()

    const r = await $.command.run({ command: 'pin', args: 'done 2' })
    expect(r.text).toBe('Marked #2 done.')
    expect(await band.find({ text: '📌 Pins 1 (done 1)' })).toBeDefined()
    expect(JSON.stringify(await band.drawn()).includes('"strikethrough":true')).toBe(true)

    const tree = JSON.stringify(await band.drawn())
    const rmKey = /"key":"(rm-[^"]+)"/.exec(tree)?.[1] ?? ''
    await band.press({ key: rmKey })
    expect(await band.find({ text: /check the \.env keys/ })).toBeUndefined()
    expect((await $.command.run({ command: 'pin', args: 'list' })).text).toBe('1. [x] upload to the drive when the render is done')

    // a new session in the same folder finds the board as it was left
    await $.session.start({ cwd: '/p/project', surface, isInteractive: true })
    expect((await $.command.run({ command: 'pin', args: 'list' })).text).toBe('1. [x] upload to the drive when the render is done')
  })
}

test('a new pin is only pinned when sending is off', { options: { deliver: false } }, async ($, on) => {
  mock.clock(on, { now: 1 })
  mock.store(on)
  const session = mock.session(on)
  on('session.cwd', () => ({ value: '/p' }))
  on('session.start', () => ({ cwd: '/p' }))
  on('command.register', (_$, e) => ({ value: { command: e.name } }))
  await $.session.start({ cwd: '/p', surface: 'terminal', isInteractive: true })
  expect((await $.command.run({ command: 'pin', args: 'quiet note' })).text).toBe('📌 Pinned #1: quiet note')
  expect(session.appended().length).toBe(0)
})

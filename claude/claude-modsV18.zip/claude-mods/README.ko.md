# my-mods (한국어 안내)

Claude Code 모드(함수 훅 플러그인) 4개입니다. **Claude Code 2.1.287 이상**이 필요합니다. 화면에 표시되는 문구는 모두 영어입니다.

---

## 명령어 한눈에 보기

| 명령 | 예시 | 동작 |
|---|---|---|
| `/pin <메모>` | `/pin 렌더 끝나면 드라이브에 올리기` | 메모 고정 후 Claude에게 전달 |
| `/pin ! <메모>` | `/pin ! 배포 전에 .env 키 확인` | 위와 같고 중요 표시(빨간 ★) |
| `/pin !! <메모>` | `/pin !! 멈추고 기존 API 유지해` | Claude의 작업을 끊고 바로 전달 |
| `/pin done N` / `/pin undo N` | `/pin done 2` | 2번 완료 / 되돌리기 |
| `/pin rm N` | `/pin rm 1` | 1번 삭제 |
| `/pin clear` | `/pin clear` | 완료된 메모 모두 삭제 |
| `/pin list` | `/pin list` | 목록 출력 |
| `/pin` | `/pin` | 보드 접기/펼치기 |
| `/change-tutor` | `/change-tutor` | Change Notes 패널 열기 |
| `/agent-flow` | `/agent-flow` | Agent flow 패널 열기(메인·서브에이전트, 모델, 토큰, diff) |
| `/tcw-usage` | `/tcw-usage` | 사용량 엔드포인트를 바로 조회해 응답 출력 |

---

## 1. 설명

### tcw (token-cache-weather) — 세션 상태 한눈에 보기

프롬프트 아래에 2줄로 표시합니다(`tcw.layout`: `bottom`, 기본값). `band`로 바꾸면 프롬프트 위에 표시합니다. 앞에 플러그인 이름이 붙지 않습니다.

```
Opus 5.5 · high · ⤷ Sonnet › Haiku   ⎇ main ↑2 ~3   CT 67%
0% (2d 11h)  |  98% (2h16m)  |  82% (2d 12h)
```

`tcw.layout`을 `line`으로 바꾸면 같은 내용을 프롬프트 아래 상태줄 한 줄로 보여줍니다. 이때는 Claude Code가 앞에 `⚠ tcw:`를 붙이기 때문에 플러그인 이름을 짧게 했습니다(폴더 이름은 그대로 `token-cache-weather`).

| 항목 | 뜻 |
|---|---|
| `Opus 5.5` | 현재 모델(1M 컨텍스트 버전은 `(1M)`), `/model`로 바꾸면 따라 바뀜 |
| `high` | 마지막 응답의 추론 강도(`low` / `medium` / `high` / `xhigh` / `max`, `--effort`·`/effort`로 설정). 첫 응답 전에는 settings에 그 모델용으로 적힌 `effortLevel`(`{ "claude-opus-5-5": { "effortLevel": "high" } }`), 없으면 맨 위 `effortLevel` |
| `⤷ Sonnet › Haiku` | settings.json의 `fallbackModel`에 적힌 폴백 체인. 폴백 모델이 응답하는 동안은 `⤷ now Sonnet 4.5`. 명령줄 `--fallback-model`로만 준 체인은 모드가 읽을 수 없어서, 폴백이 실제로 응답할 때만 보임 |
| `⎇ main ↑2 ~3` | git 상태: 브랜치(분리된 HEAD는 `@1a2b3c4`), `↑` 푸시할 커밋, `↓` 받아올 커밋, `+` 스테이징됨, `~` 수정됨, `?` 추적 안 됨, `!` 충돌. 깨끗하면 `✓`. 저장소가 아니면 생략 |
| `CT 67%` | 컨텍스트 사용률. 첫 응답 전에는 `-%`. 막대는 50% 넘으면 노랑, 80% 넘으면 빨강 |
| `98% (2h16m)` · `82% (2d 12h)` | 5시간·주간(전체 모델) 사용 한도의 남은 비율과 리셋까지 남은 시간. 50% 미만 노랑, 20% 미만 빨강. 구독 계정만 표시 |
| `0% (2d 11h)` | `/usage`처럼 모델별 주간 한도(이름 없이 맨 앞). 계정에 별도 한도가 있는 모델만 표시. 계정 사용량 엔드포인트를 최대 5분마다 읽음(토큰 사용 없음). `tcw.plan` = `false`로 끔. `/tcw-usage`로 즉시 조회해 응답 확인 |

15초마다, 그리고 응답이 올 때마다 갱신합니다. 화면에는 없지만 프롬프트 캐시 만료 5분 전(5분짜리 캐시는 1분 전)에 알림을 한 번 띄웁니다. 엔진이 이미 가진 수치만 읽으므로 **토큰을 쓰지 않습니다**.

### change-tutor — 변경 학습 노트(Change Notes) 패널

Claude가 파일을 만들거나 고칠 때(Edit / Write)마다 노트가 하나씩 쌓입니다. 노트에는 파일과 `+추가 -삭제 · 시각`, **🙋 Request**(그 턴의 요청), **🤔 Why it changed**(변경 직전에 Claude가 한 말), diff가 담깁니다. 노트마다 **💡 Explain simply**(쉬운 설명)과 4지선다 **❓ Quiz**를 요청할 수 있습니다. 메인 에이전트가 고친 것만 노트로 남기고, 서브에이전트가 고친 내역은 agent-flow(`sub_Diff`)에서 봅니다. 노트는 세션이 바뀌어도 남고 최근 100건까지 보관합니다. 상태줄에 `📘 N change notes`가 표시됩니다.

### pinboard — 프롬프트 위 고정 메모

`/pin <메모>`로 프롬프트 바로 위 작은 보드에 메모를 고정합니다. 대화가 아무리 길어져도 밀려나지 않습니다. 메모 앞에 `!`를 붙이면 중요 표시(빨간색, ★)가 되고, `!!`를 붙이면 Claude의 작업을 끊고 바로 읽게 합니다(아래 참고). 줄마다 `[✓]`로 완료 처리(취소선, `[↺]`로 되돌리기)하고, 오른쪽 `[×]`로 지웁니다. 폴더별로 저장되어 같은 폴더에서 새 세션을 열면 그대로 남아 있습니다.

새로 고정한 메모는 **Claude에게 즉시 전달**되고, `/pin`은 Claude가 작업 중이어도 바로 실행됩니다.

- Claude가 쉬고 있을 때: 메모가 사용자 프롬프트(`📌 Pin #1: …`)로 들어가 Claude가 바로 작업을 시작합니다.
- Claude가 작업 중일 때: 메모가 사용자 메시지로 대화에 추가되어 다음 단계(지금 쓰는 응답이나 도구 실행이 끝난 직후)에 읽힙니다. 작업 중에 메시지를 입력해 보낼 때와 같은 시점입니다. 다음 단계 전에 턴이 끝나면 후속 프롬프트(`📌 Pinned while you were working: …`)로 전달됩니다.
- Claude가 작업 중일 때 `/pin !! <메모>`: 진행 중인 턴을 끊고 메모를 바로 프롬프트(`📌 Pin #1 (urgent — I stopped your turn for this): …`)로 보냅니다. 방향을 당장 바꿀 때 씁니다. 쓰던 응답이나 실행 중이던 도구는 중간에 끊기고, Claude는 메모를 읽은 뒤 작업을 이어갑니다.

`pinboard.deliver` = `false`로 끌 수 있습니다.

| 명령 | 동작 |
|---|---|
| `/pin <메모>`, `/pin ! <메모>` | 메모 고정(`!`는 중요) 후 Claude에게 전달 |
| `/pin !! <메모>` | 중요 표시로 고정하고, Claude의 작업을 끊고 바로 전달 |
| `/pin done N`, `/pin undo N` | N번 완료 / 되돌리기 |
| `/pin rm N` | N번 삭제(`[×]`와 같음) |
| `/pin clear` | 완료된 메모 일괄 삭제 |
| `/pin list` | 목록 출력 |
| `/pin` | 보드 접기/펼치기 |

### agent-flow — 메인 에이전트와 서브에이전트를 한 패널에

`/agent-flow`로 패널을 엽니다(자동으로 열리지 않습니다). 세션의 메인 에이전트와 모든 서브에이전트가 보입니다.

```
Agent flow · main + 2 agents · 1 running · 0 waiting
● main  Fable 5.1  running  38.2k tok  ✎3  [main_Diff]
├ ● Explore "Summarize src/greet.js"  Haiku 4.5  2s  4.1k tok  ✎0
└ ● implementer "Fix the parser"  Fable 5.1  41s  22.7k tok  ✎2  [sub_Diff]
last: implementer · Edit src/parser.ts
```

| 부분 | 의미 |
|---|---|
| `●` | 노랑 실행 중, 초록 완료, 빨강 실패·중단, 회색 대기 |
| `Explore "Summarize …"` | 서브에이전트 종류와 작업. 다른 에이전트가 띄운 것은 그 아래로 들여씁니다 |
| `Fable 5.1` | 실행 모델. Fable은 별도 주간 한도를 쓰므로 자주색으로 강조 |
| `41s` | 실행 시간 |
| `22.7k tok` | 쓴 토큰(입력·캐시 쓰기·출력, 캐시 읽기 제외) |
| `✎2` | 만들거나 고친 파일 수 |
| `[main_Diff]` / `[sub_Diff]` | 그 에이전트의 수정 내역을 하나씩 보기 |
| `last:` | 마지막으로 일어난 일 |

이번 세션 동안만 기록하고, 엔진이 가진 정보만 읽어서 토큰을 쓰지 않습니다.

---

## 2. 설치

압축을 계속 둘 폴더(예: `C:\Users\<이름>\claude-mods`, `~/claude-mods`)에 풀고, 그 폴더에서 실행합니다.

```bash
claude plugin marketplace add ./
claude plugin install tcw@my-mods --scope user
claude plugin install change-tutor@my-mods --scope user
claude plugin install pinboard@my-mods --scope user
claude plugin install agent-flow@my-mods --scope user
```

- `--scope user`로 설치하면 모든 프로젝트, 터미널, 데스크톱 앱 Code 탭에서 로드됩니다. 필요한 것만 설치해도 됩니다.
- 설치할 때 "option not yet set" 안내가 나와도 기본값으로 동작합니다. 처음부터 지정하려면 `--config ttl=1h` / `--config model=haiku`를 붙이세요.
- 플러그인은 이 폴더에서 바로 읽힙니다. **폴더를 옮기거나 지우지 마세요.** 파일을 고친 뒤에는 `/reload-plugins`를 실행하면 반영됩니다.

다른 로드 방법:

```bash
# 이번 한 세션만
claude --plugin-dir ./token-cache-weather --plugin-dir ./change-tutor --plugin-dir ./pinboard --plugin-dir ./agent-flow
```

```json
// ~/.claude/settings.json — 항상 로드(절대 경로, Windows는 ";", macOS·Linux는 ":"로 구분)
{ "env": { "CLAUDE_CODE_PLUGIN_DIRS": "C:\\Users\\<이름>\\claude-mods\\token-cache-weather;C:\\Users\\<이름>\\claude-mods\\pinboard" } }
```

업데이트: 새 버전을 같은 폴더에 덮어 풀고 `claude plugin marketplace update my-mods`와 `/reload-plugins`를 실행합니다(새 세션을 열어도 됩니다). `/config`에서 바꾼 설정은 유지됩니다.

제거: `claude plugin uninstall <이름>@my-mods`

blast-radius와 replay-theater는 이 묶음에서 빠졌습니다. 예전에 설치했다면 `claude plugin uninstall blast-radius@my-mods`, `claude plugin uninstall replay-theater@my-mods`로 지우세요.

---

## 3. 사용법

### tcw (token-cache-weather)

할 일이 없습니다. 세션을 시작하면 자동으로 표시됩니다. 폴백 체인을 항상 보이게 하려면 `~/.claude/settings.json`에 `{ "fallbackModel": ["sonnet", "haiku"] }`처럼 적어 두세요.

| 설정(`/config`) | 값 | 기본값 |
|---|---|---|
| `tcw.layout` | `bottom`(프롬프트 아래 2줄), `band`(프롬프트 위 2줄), `line`(프롬프트 아래 한 줄) | `bottom` |
| `tcw.style` | `plain`, `chip`(줄마다 음영 배경), `box`(둥근 테두리, 2줄 더 차지). band일 때만 적용 | `plain` |
| `tcw.model` | `true`, `false` — 모델·추론 강도·폴백 체인 표시 여부 | `true` |
| `tcw.weather` | `true`, `false` — `CT 67%`(컨텍스트 사용률) 표시 여부 | `true` |
| `tcw.plan` | `true`, `false` — 모델별 주간 한도 표시 여부(5분마다 조회, 토큰 없음) | `true` |
| `tcw.git` | `true`, `false` — git 상태 표시 여부(갱신마다 `git status` 실행, 토큰 없음) | `true` |
| `tcw.ttl` | `1h`, `5m` — 캐시 만료 알림의 기준 시간 | `1h` |

### change-tutor

- 세션에서 첫 변경이 생기면 패널이 자동으로 열립니다. 언제든 **`/change-tutor`**로 열 수 있습니다.
- 단축키는 패널에 포커스가 있을 때 동작합니다(패널 클릭 또는 `ctrl+x tab`).

| 키 | 동작 |
|---|---|
| `h` / `l` | 이전 / 다음 노트 |
| `e` | 💡 Explain simply(쉬운 설명) |
| `q` | ❓ Quiz(이어서 `1`–`4`로 답 선택) |
| `v` | ⤢ Show all / ⤡ Collapse(diff 펼치기/접기) |
| `c` | Copy diff(diff 복사) |

- **This session** / **All notes** 탭과 **Latest**는 버튼으로 누릅니다.
- Explain과 Quiz는 누를 때만 모델을 호출합니다. 그때 토큰이 듭니다.

| 설정(`/config`) | 값 | 기본값 |
|---|---|---|
| `change-tutor.model` | `haiku`, `sonnet`, `opus` | `haiku` |

### pinboard

- **`/pin <메모>`**는 Claude가 작업 중일 때도 언제든 입력할 수 있습니다. `/pin ! <메모>`는 중요 표시, `/pin !! <메모>`는 작업을 끊고 바로 읽게 합니다. 나머지 명령은 1장의 표를 보세요.
- 줄의 `[✓]` / `[↺]` / `[×]`를 클릭하거나, `ctrl+x tab`으로 보드에 포커스를 준 뒤 버튼으로 이동합니다. `[Hide]` / `[Show]`로 보드를 머리줄만 남기고 접습니다.
- 새 메모는 Claude에게 즉시 전달됩니다. 쉬고 있으면 프롬프트로 보내져 바로 작업을 시작하고, 작업 중이면 다음 단계에서 읽힙니다(그 전에 턴이 끝나면 후속 프롬프트로 전달). 완료나 삭제는 전달하지 않습니다.
- 메모는 폴더별로 최근 50개까지 저장되고, 같은 폴더에서 새 세션을 열면 다시 나타납니다.

| 설정(`/config`) | 값 | 기본값 |
|---|---|---|
| `pinboard.deliver` | `true`, `false` — 새 메모를 Claude에게 전달 | `true` |

### agent-flow

- 보고 싶을 때 **`/agent-flow`**로 엽니다. 자동으로 열리지 않습니다.
- `[main_Diff]` / `[sub_Diff]`를 클릭하거나, `ctrl+x tab`으로 패널에 포커스를 준 뒤 이동합니다. diff 화면에서 `h` / `l` 이전·다음 변경, `v` 펼치기·접기, `b` 흐름 화면으로 돌아가기.
- 새 세션은 빈 화면에서 시작합니다.

---

## 확인

```bash
claude plugin validate ./<모드>
claude plugin test ./<모드>
```

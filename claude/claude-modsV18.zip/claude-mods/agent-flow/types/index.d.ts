/** One hunk of a unified diff, as the Edit and Write tools report it. */
export type Hunk = { oldStart: number; newStart: number; lines: string[] }

/** The main loop's line in the flow. */
export type MainRow = {
  /** The model that answered last, as the API names it. */
  model: string | null
  isRunning: boolean
  /** Tokens this session: input, cache writes and output (cache reads left out). */
  tokens: number
  edits: number
}

/** One subagent's line in the flow. */
export type AgentRow = {
  id: string
  /** Its agent type: Explore, general-purpose, implementer, ... */
  type: string
  /** The few words of its task. */
  task: string
  model: string | null
  /** pending, running, waiting, idle, completed, failed or killed. */
  status: string
  parentId?: string
  startedAt: number
  endedAt?: number
  tokens: number
  edits: number
}

/** One Edit or Write, by the main loop ("main") or a subagent (its id). */
export type Change = {
  id: string
  agent: string
  at: number
  path: string
  isNew: boolean
  added: number
  removed: number
  hunks: Hunk[]
  /** Diff lines the change had (more than hunks keep when it was long). */
  totalLines: number
}

/** flow: the agents; diffs: one agent's changes (main_Diff or sub_Diff). */
export type FlowView = { mode: 'flow' | 'diffs'; agent: string; pos: number | null; expanded: boolean }

declare module 'claude-code' {
  interface PluginState {
    'agent-flow': {
      main: MainRow
      agents: AgentRow[]
      changes: Change[]
      /** The last thing that happened: "implementer · Edit src/parser.ts". */
      last: string
      view: FlowView
      /** Bumped every 2 s while an agent runs, so elapsed times redraw. */
      tick: number
    }
  }
}

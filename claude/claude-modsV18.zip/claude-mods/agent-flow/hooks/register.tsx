// agent-flow: one pane with the main agent and every subagent of the session, opened with /agent-flow
// (never by itself):
//   Agent flow · main + 2 agents · 1 running · 0 waiting
//   ● main  Fable 5.1  running  38.2k tok  ✎3  [main_Diff]
//   ├ ● Explore "Summarize src/greet.js"  Haiku 4.5  2s  4.1k tok  ✎0
//   └ ● implementer "Fix the parser"  Fable 5.1  41s  22.7k tok  ✎2  [sub_Diff]
//   last: implementer · Edit src/parser.ts
// main_Diff / sub_Diff open that agent's changes, one diff at a time. Tokens leave cache reads out.
// Nothing here calls a model: no tokens are spent. Session-only: a new session starts empty.
import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type { AgentRow, Change, FlowView, MainRow } from '../types'
import { counts, creation, lineCount, normalise, render } from './diff'
import type { RawHunk } from './diff'
import {
  COLLAPSED_LINES,
  KEEP_CHANGES,
  KEEP_LINES,
  changesOf,
  clockTime,
  elapsed,
  fmt,
  headline,
  isActive,
  isCapped,
  short,
  shortPath,
  stepTokens,
  tree,
} from './flow'
import type { Usage } from './flow'

const PANE = 'agent-flow'
const TITLE = 'Agent flow'
const TICK_MS = 2000

const main = atom({ plugin: 'agent-flow', key: 'main' } as const, { model: null, isRunning: false, tokens: 0, edits: 0 } as MainRow)
const agents = atom({ plugin: 'agent-flow', key: 'agents' } as const, [] as AgentRow[])
const changes = atom({ plugin: 'agent-flow', key: 'changes' } as const, [] as Change[])
const last = atom({ plugin: 'agent-flow', key: 'last' } as const, '')
const view = atom({ plugin: 'agent-flow', key: 'view' } as const, { mode: 'flow', agent: 'main', pos: null, expanded: false } as FlowView)
const tick = atom({ plugin: 'agent-flow', key: 'tick' } as const, 0)

/** Brings the rows in line with the engine's roster: new agents added, types, tasks and states refreshed. */
async function sync($: EngineInterface): Promise<void> {
  let roster: Awaited<ReturnType<EngineInterface['agent']['list']>>
  try {
    roster = await $.agent.list()
  } catch {
    return // the roster is unavailable for a moment
  }
  const now = await $.clock.now()
  await update($, agents, rows => {
    const next = rows.map(r => {
      const a = roster.find(x => x.id === r.id)
      if (!a) return r
      const ended = !isActive(a.status) && a.status !== 'waiting' && a.status !== 'idle'
      return { ...r, type: a.type || r.type, task: a.description || r.task, status: a.status, parentId: a.parentId, endedAt: ended ? (r.endedAt ?? now) : undefined }
    })
    for (const a of roster) {
      if (next.some(r => r.id === a.id)) continue
      next.push({ id: a.id, type: a.type || 'subagent', task: a.description || '', model: null, status: a.status, parentId: a.parentId, startedAt: now, tokens: 0, edits: 0 })
    }
    return next
  })
}

async function noteRow($: EngineInterface, agentId: string): Promise<void> {
  if (!(await read($, agents)).some(r => r.id === agentId)) await sync($)
}

async function nameOf($: EngineInterface, agent: string): Promise<string> {
  if (agent === 'main') return 'main'
  return (await read($, agents)).find(r => r.id === agent)?.type ?? 'subagent'
}

async function record($: EngineInterface, agentId: string | undefined, tool: string, path: string, isNew: boolean, raw: RawHunk[]): Promise<void> {
  const agent = agentId ?? 'main'
  if (agentId !== undefined) await noteRow($, agentId)
  const at = await $.clock.now()
  const { hunks, total } = normalise(raw, KEEP_LINES)
  const { added, removed } = counts(raw)
  const change: Change = { id: `${at}-${Math.random().toString(36).slice(2, 7)}`, agent, at, path, isNew, added, removed, hunks, totalLines: total }
  await update($, changes, list => [...list, change].slice(-KEEP_CHANGES))
  if (agentId === undefined) await update($, main, m => ({ ...m, edits: m.edits + 1 }))
  else await update($, agents, rows => rows.map(r => (r.id === agentId ? { ...r, edits: r.edits + 1 } : r)))
  const who = await nameOf($, agent)
  await update($, last, () => `${who} · ${tool} ${shortPath(path)}`)
}

async function openDiffs($: EngineInterface, agent: string): Promise<void> {
  await update($, view, () => ({ mode: 'diffs', agent, pos: null, expanded: false }))
}

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    const result = await next(e)
    await $.command.register({ name: 'agent-flow', description: 'Open the Agent flow pane: main and subagents, their models, tokens and changes' })
    $.clock.every(TICK_MS, async () => {
      const rows = await read($, agents)
      if (!rows.some(r => isActive(r.status))) return
      await sync($)
      await update($, tick, t => t + 1)
    })
    return result
  })

  on('command.run', { command: 'agent-flow' }, async $ => {
    await sync($)
    await update($, view, v => ({ ...v, mode: 'flow' }))
    await $.ui.open({ id: PANE, title: TITLE })
    return { text: 'Opened Agent flow.' }
  })

  on('turn.start', async ($, e, next) => {
    await update($, main, m => ({ ...m, isRunning: true }))
    return next(e)
  })

  // Every request: who made it, on which model, and what it cost.
  on('turn.step', async function* ($, e, next) {
    const step = yield* next(e)
    const usage = step.usage as (Usage & { model?: string }) | null
    const model = usage?.model || e.model
    const spent = stepTokens(usage)
    if (e.agentId === undefined) {
      await update($, main, m => ({ ...m, model, tokens: m.tokens + spent }))
    } else {
      const id = e.agentId
      await noteRow($, id)
      await update($, agents, rows => rows.map(r => (r.id === id ? { ...r, model, tokens: r.tokens + spent } : r)))
    }
    return step
  })

  on('turn.complete', async ($, e, next) => {
    const result = await next(e)
    if (e.agentId === undefined) {
      await update($, main, m => ({ ...m, isRunning: false }))
      await update($, last, () => `main · ${e.isAborted ? 'stopped' : 'answered'} in ${elapsed(e.durationMs)}`)
    } else {
      const id = e.agentId
      await sync($)
      const who = await nameOf($, id)
      await update($, last, () => `${who} · ${e.isAborted ? 'stopped' : 'done'} in ${elapsed(e.durationMs)}`)
    }
    return result
  })

  on('tool.call', { tool: 'Edit' }, async ($, e, next) => {
    const ran = await next(e)
    if (ran.deny !== undefined || ran.isError || !ran.result || ran.result.staged) return ran
    await record($, e.agentId, 'Edit', e.file_path, false, ran.result.structuredPatch)
    return ran
  })

  on('tool.call', { tool: 'Write' }, async ($, e, next) => {
    const ran = await next(e)
    if (ran.deny !== undefined || ran.isError || !ran.result || ran.result.staged) return ran
    const isNew = ran.result.type === 'create'
    const patch: RawHunk[] = ran.result.structuredPatch
    const raw = isNew && patch.length === 0 ? creation(e.content) : patch
    if (raw.length > 0) await record($, e.agentId, 'Write', e.file_path, isNew, raw)
    return ran
  })

  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    const { Box, Text, Button, Code } = $.ui.resolve(e)
    const [m, rows, all, lastText, v] = await Promise.all([read($, main), read($, agents), read($, changes), read($, last), read($, view), read($, tick)])
    const now = await $.clock.now()
    const setView = (change: Partial<FlowView>) => update($, view, old => ({ ...old, ...change }))

    if (v.mode === 'diffs') {
      const list = changesOf(all, v.agent)
      const at = list.length === 0 ? -1 : v.pos === null ? list.length - 1 : Math.min(Math.max(v.pos, 0), list.length - 1)
      const c = at >= 0 ? list[at] : undefined
      const row = rows.find(r => r.id === v.agent)
      const title = v.agent === 'main' ? 'main_Diff · main' : `sub_Diff · ${row?.type ?? 'subagent'}${row?.task ? ` "${row.task}"` : ''}`
      const diff = c ? render(c.hunks, v.expanded ? null : COLLAPSED_LINES) : null
      const hidden = c && diff ? lineCount(c.hunks) - diff.shown : 0
      return (
        <Box flexDirection="column" gap={1}>
          <Box flexDirection="row" gap={1}>
            <Button key="back" hotkey="b" label="◀ Flow" onPress={() => setView({ mode: 'flow' })} />
            <Text bold wrap="truncate">{title}</Text>
          </Box>
          <Box flexDirection="row" gap={1}>
            <Button key="prev" hotkey="h" label="◀" onPress={() => setView({ pos: Math.max(0, at - 1), expanded: false })} />
            <Text>{list.length === 0 ? '0 / 0' : `${at + 1} / ${list.length}`}</Text>
            <Button key="next" hotkey="l" label="▶" onPress={() => setView({ pos: at + 1 >= list.length - 1 ? null : at + 1, expanded: false })} />
          </Box>
          {!c || !diff ? (
            <Text dimColor>No changes by this agent yet.</Text>
          ) : (
            <Box flexDirection="column">
              <Text bold wrap="truncate-start">📄 {shortPath(c.path)}{c.isNew ? ' (new file)' : ''}</Text>
              <Box flexDirection="row">
                <Text color="green">+{c.added}</Text>
                <Text> </Text>
                <Text color="red">-{c.removed}</Text>
                <Text dimColor> · {clockTime(c.at)}</Text>
              </Box>
              {diff.source === '' ? <Text dimColor>(no diff to show)</Text> : <Code source={diff.source} format="diff" path={c.path} wrap="truncate-end" />}
              {c.totalLines > lineCount(c.hunks) ? <Text dimColor>(long change: only the first {lineCount(c.hunks)} lines were kept)</Text> : null}
              {hidden > 0 || v.expanded ? (
                <Button key="expand" hotkey="v" label={v.expanded ? '⤡ Collapse' : `⤢ Show all (+${hidden} lines)`} onPress={() => setView({ pos: at, expanded: !v.expanded })} />
              ) : null}
            </Box>
          )}
        </Box>
      )
    }

    const ordered = tree(rows)
    return (
      <Box flexDirection="column">
        <Text bold>{headline(rows)}</Text>
        <Box flexDirection="row" gap={1}>
          <Text color={m.isRunning ? 'yellow' : 'gray'}>●</Text>
          <Text bold>main</Text>
          <Text color={isCapped(m.model) ? 'magenta' : undefined} bold={isCapped(m.model)}>{short(m.model)}</Text>
          <Text dimColor>{m.isRunning ? 'running' : 'idle'}</Text>
          <Text>{fmt(m.tokens)} tok</Text>
          <Text>✎{m.edits}</Text>
          {m.edits > 0 ? <Button key="diff-main" plain label="[main_Diff]" onPress={() => openDiffs($, 'main')} /> : null}
        </Box>
        {ordered.map(({ row, depth, isLast }) => {
          const active = isActive(row.status)
          const color = active ? 'yellow' : row.status === 'failed' || row.status === 'killed' ? 'red' : row.status === 'completed' ? 'green' : 'gray'
          return (
            <Box key={`agent-${row.id}`} flexDirection="row" gap={1}>
              <Text dimColor>{`${'  '.repeat(depth)}${isLast ? '└' : '├'}`}</Text>
              <Text color={color}>●</Text>
              <Box flexShrink={1}>
                <Text wrap="truncate" dimColor={!active}>{`${row.type}${row.task ? ` "${row.task}"` : ''}`}</Text>
              </Box>
              <Text color={isCapped(row.model) ? 'magenta' : undefined} bold={isCapped(row.model)}>{short(row.model)}</Text>
              <Text dimColor>{elapsed((row.endedAt ?? now) - row.startedAt)}</Text>
              <Text>{fmt(row.tokens)} tok</Text>
              <Text>✎{row.edits}</Text>
              {row.edits > 0 ? <Button key={`diff-${row.id}`} plain label="[sub_Diff]" onPress={() => openDiffs($, row.id)} /> : null}
            </Box>
          )
        })}
        {rows.length === 0 ? <Text dimColor>No subagents yet this session.</Text> : null}
        {lastText ? <Text dimColor wrap="truncate">last: {lastText}</Text> : null}
      </Box>
    )
  })
}

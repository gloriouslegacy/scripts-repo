// agent-flow: pure helpers — token counts, labels, elapsed times and the tree order.
import type { AgentRow, Change } from '../types'
import { modelName } from './model'

export const KEEP_CHANGES = 300
export const KEEP_LINES = 200
export const COLLAPSED_LINES = 12

export type Usage = { input_tokens?: number; output_tokens?: number; cache_creation_input_tokens?: number; cache_read_input_tokens?: number }

/** What a request cost, cache reads left out (they barely count against limits). */
export const stepTokens = (u: Usage | null | undefined): number =>
  u ? (u.input_tokens ?? 0) + (u.cache_creation_input_tokens ?? 0) + (u.output_tokens ?? 0) : 0

/** 950 → "950", 4_100 → "4.1k", 1_250_000 → "1.25M" */
export const fmt = (n: number): string =>
  n >= 1_000_000 ? `${(n / 1_000_000).toFixed(2)}M` : n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n)

/** 2_000 → "2s", 125_000 → "2m05s", 3_900_000 → "1h05m" */
export const elapsed = (ms: number): string => {
  const s = Math.max(0, Math.floor(ms / 1000))
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m}m${String(s % 60).padStart(2, '0')}s`
  return `${Math.floor(m / 60)}h${String(m % 60).padStart(2, '0')}m`
}

export const short = (model: string | null): string => (model ? modelName(model) : '?')

/** Fable (and Mythos) draw from their own weekly cap: worth seeing at a glance. */
export const isCapped = (model: string | null): boolean => !!model && /fable|mythos/i.test(model)

export const isActive = (status: string): boolean => status === 'running' || status === 'pending'

/** Agents in tree order (each after its parent), with their depth. */
export const tree = (agents: readonly AgentRow[]): { row: AgentRow; depth: number; isLast: boolean }[] => {
  const ids = new Set(agents.map(a => a.id))
  const kids = (parent: string | undefined) => agents.filter(a => (a.parentId && ids.has(a.parentId) ? a.parentId : undefined) === parent)
  const out: { row: AgentRow; depth: number; isLast: boolean }[] = []
  const walk = (parent: string | undefined, depth: number) => {
    const list = kids(parent)
    list.forEach((row, i) => {
      out.push({ row, depth, isLast: i === list.length - 1 })
      walk(row.id, depth + 1)
    })
  }
  walk(undefined, 0)
  return out
}

/** "Agent flow · main + 2 agents · 2 running · 0 waiting" */
export const headline = (agents: readonly AgentRow[]): string => {
  const running = agents.filter(a => isActive(a.status)).length
  const waiting = agents.filter(a => a.status === 'waiting' || a.status === 'idle').length
  return `Agent flow · main + ${agents.length} agent${agents.length === 1 ? '' : 's'} · ${running} running · ${waiting} waiting`
}

export const changesOf = (changes: readonly Change[], agent: string): Change[] => changes.filter(c => c.agent === agent)

/** ".../src/parser.ts": the last three segments. */
export const shortPath = (path: string): string => {
  const parts = path.split(/[\\/]/).filter(Boolean)
  return parts.length <= 3 ? path : `.../${parts.slice(-3).join('/')}`
}

const pad = (n: number): string => String(n).padStart(2, '0')
export const clockTime = (ms: number): string => {
  const d = new Date(ms)
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}

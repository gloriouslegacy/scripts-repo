import { expect, mock, test } from 'claude-code/testing'

import { elapsed, fmt, headline, stepTokens, tree } from '../hooks/flow'

const row = (id: string, parentId?: string) => ({ id, type: 'Explore', task: id, model: null, status: 'running', parentId, startedAt: 0, tokens: 0, edits: 0 })

test('helpers', () => {
  expect(stepTokens({ input_tokens: 100, output_tokens: 50, cache_creation_input_tokens: 10, cache_read_input_tokens: 90_000 })).toBe(160)
  expect(fmt(4_100)).toBe('4.1k')
  expect(elapsed(125_000)).toBe('2m05s')
  expect(tree([row('a'), row('b'), row('c', 'a')]).map(t => `${t.depth}${t.row.id}${t.isLast ? '.' : ''}`)).toEqual(['0a', '1c.', '0b.'])
  expect(headline([row('a'), { ...row('b'), status: 'completed' }])).toBe('Agent flow · main + 2 agents · 1 running · 0 waiting')
})

const usage = (model: string, input: number) => ({ input_tokens: input, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0, model })
const patch = [{ oldStart: 1, oldLines: 1, newStart: 1, newLines: 1, lines: ['-a', '+b'] }]

for (const surface of ['terminal', 'desktop'] as const) {
  test(`the flow shows main and subagents with models, tokens and their diffs on ${surface}`, async ($, on) => {
    mock.clock(on, { now: 10_000 })
    const opened: string[] = []
    on('session.start', () => ({ cwd: '/' }))
    on('command.register', (_$, e) => ({ value: { command: e.name } }))
    on('ui.open', (_$, e) => {
      opened.push(e.id)
      return { value: { isPlaced: true } }
    })
    on('agent.list', () => ({ value: [{ id: 'a1', description: 'Fix the parser', type: 'implementer', status: 'running' as const }] }))
    on('turn.start', (_$, e) => ({ turnId: e.turnId }))
    on('turn.step', async function* (_$, e) {
      return { turnId: e.turnId, index: e.index, answer: '', toolUses: [], stopReason: 'tool_use', usage: usage(e.model, e.agentId ? 22_700 : 38_200) }
    })
    on('tool.call', { tool: 'Edit' }, (_$, e) => ({
      result: { filePath: e.file_path, oldString: 'a', newString: 'b', originalFile: 'a\n', structuredPatch: patch, userModified: false, replaceAll: false },
    }))

    await $.session.start({ cwd: '/', surface, isInteractive: true })
    await $.turn.start({ text: 'fix it', turnId: 't' })
    for await (const _ of $.turn.step({ turnId: 't', index: 0, model: 'claude-fable-5-1', messageCount: 1 })) {
      // drain
    }
    for await (const _ of $.turn.step({ turnId: 't', index: 0, model: 'claude-fable-5-1', messageCount: 1, agentId: 'a1' })) {
      // drain
    }
    await $.tool.call({ tool: 'Edit', tool_use_id: 'e1', file_path: '/p/src/main.ts', old_string: 'a', new_string: 'b' })
    await $.tool.call({ tool: 'Edit', tool_use_id: 'e2', file_path: '/p/src/parser.ts', old_string: 'a', new_string: 'b', agentId: 'a1' })
    expect(opened).toEqual([]) // never opens by itself

    await $.command.run({ command: 'agent-flow', args: '' })
    expect(opened).toEqual(['agent-flow'])
    const pane = { title: 'Agent flow', isFocused: false, bodyColumns: 100, placement: 'dock' as const, scroll: { offset: 0, bodyRows: 40 }, view: {} }
    const ui = await $.ui.mount({ plugin: 'agent-flow', surface, component: 'Pane', requestId: 'agent-flow', props: pane })
    expect(await ui.find({ text: 'Agent flow · main + 1 agent · 1 running · 0 waiting' })).toBeDefined()
    const drawn = JSON.stringify(await ui.drawn())
    expect(drawn).toContain('"children":["38.2k"," tok"]')
    expect(drawn).toContain('"children":["22.7k"," tok"]')
    expect(drawn).toMatch(/"color":"magenta","bold":true[^}]*},"children":\["Fable 5\.1"\]/)
    expect(await ui.find({ text: 'implementer "Fix the parser"' })).toBeDefined()
    expect(await ui.find({ text: /last: implementer · Edit .*parser\.ts/ })).toBeDefined()

    await ui.press({ key: 'diff-a1' })
    expect(await ui.find({ text: /sub_Diff · implementer "Fix the parser"/ })).toBeDefined()
    expect(await ui.find({ text: /parser\.ts/ })).toBeDefined()
    await ui.press({ key: 'back' })
    await ui.press({ key: 'diff-main' })
    expect(await ui.find({ text: 'main_Diff · main' })).toBeDefined()
    expect(await ui.find({ text: /main\.ts/ })).toBeDefined()
  })
}

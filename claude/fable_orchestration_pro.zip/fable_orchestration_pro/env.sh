# ~/.claude/fable/env.sh — Fable orchestration switch (macOS zsh / bash · Linux) — Pro 요금제 전용
# ~/.zshrc 에서:  [ -f "$HOME/.claude/fable/env.sh" ] && source "$HOME/.claude/fable/env.sh"

FABLE_HOME="$HOME/.claude/fable"
FABLE_STATE="$HOME/.claude/.fable-state"
FABLE_EXEC_MODEL="sonnet"            # 구현 서브에이전트(general-purpose 등)가 쓸 모델 (별칭)
FABLE_MIN_CC="2.1.196"               # prompt_id 지원 최소 버전

_fable_run() {
  if [ "$(cat "$FABLE_STATE" 2>/dev/null)" = "on" ]; then
    # CLAUDE_CODE_SUBAGENT_MODEL: model 을 지정하지 않은 서브에이전트(general-purpose 포함)의 모델.
    #   없으면 메인(Opus)을 그대로 물려받아 위임 효과가 사라짐. deep-reasoner/runner 처럼
    #   frontmatter 에 model 이 있는 에이전트는 영향 없음.
    CLAUDE_CODE_SUBAGENT_MODEL="$FABLE_EXEC_MODEL" "$@"
  else
    "$@"
  fi
}
claude() { _fable_run command claude "$@"; }

_fable_ok() { if [ "$1" = 0 ]; then echo "[ok] $2"; else echo "[!!] $2"; fi; }

fable() {
  case "$1" in
    on)
      echo on > "$FABLE_STATE"
      ln -sfn "$FABLE_HOME/fable.md" "$FABLE_HOME/active.md"
      echo "fable: ON (다음 세션부터 적용)";;
    off)
      echo off > "$FABLE_STATE"
      ln -sfn "$FABLE_HOME/empty.md" "$FABLE_HOME/active.md"
      echo "fable: OFF (다음 세션부터 적용)";;
    status)
      echo "state      : $(cat "$FABLE_STATE" 2>/dev/null || echo missing)"
      echo "active.md  : $(readlink "$FABLE_HOME/active.md")"
      grep -q 'fable/active.md' "$HOME/.claude/CLAUDE.md" 2>/dev/null;       _fable_ok $? "CLAUDE.md import"
      grep -q 'orchestration-gate.py' "$HOME/.claude/settings.json" 2>/dev/null; _fable_ok $? "settings.json hook"
      [ -e "$HOME/.claude/agents/deep-reasoner.md" ] && [ -e "$HOME/.claude/agents/runner.md" ]; _fable_ok $? "agents 링크"
      python3 -c 'import sys; sys.exit(sys.version_info < (3, 8))' 2>/dev/null; _fable_ok $? "python3 3.8+"
      v=$(command claude --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)
      # macOS 기본 sort 는 버전마다 -V 지원이 달라 python 으로 비교
      python3 -c 'import sys; a=[int(x) for x in sys.argv[1].split(".")]; b=[int(x) for x in sys.argv[2].split(".")]; sys.exit(a < b)' "${v:-0.0.0}" "$FABLE_MIN_CC" 2>/dev/null
      _fable_ok $? "claude ${v:-?} (${FABLE_MIN_CC} 이상 필요)"
      python3 "$FABLE_HOME/hooks/fable-settings.py" status 2>/dev/null
      if [ -f "$FABLE_HOME/gate.log" ]; then
        echo "gate.log   : DENY $(grep -c '"DENY"' "$FABLE_HOME/gate.log") / WARN $(grep -c '"WARN"' "$FABLE_HOME/gate.log") / ERROR $(grep -c '"ERROR"' "$FABLE_HOME/gate.log")"
      fi;;
    log)  tail -n "${2:-20}" "$FABLE_HOME/gate.log";;
    global)   # 전체 적용 스위치: ~/.claude/settings.json env 에 모델 변수 기록/제거 (IDE·앱 포함)
      python3 "$FABLE_HOME/hooks/fable-settings.py" global "${2:-}" --model "$FABLE_EXEC_MODEL";;
    project)  # 프로젝트별 게이트 스위치: ./.claude/settings.json (--local 이면 settings.local.json)
      python3 "$FABLE_HOME/hooks/fable-settings.py" project "${2:-}" "${@:3}";;
    *)    echo "usage: fable on|off|status|log [n] | global on|off | project on|off [--local]";;
  esac
}

﻿# ~/.claude/fable/env.ps1 — Fable orchestration switch (Windows PowerShell 5.1 / PowerShell 7) — Pro 요금제 전용
# $PROFILE 에서 dot-source 로 불러옵니다:  . "$HOME\.claude\fable\env.ps1"

$script:FableHome      = Join-Path $HOME '.claude\fable'
$script:FableState     = Join-Path $HOME '.claude\.fable-state'
$script:FableExecModel = 'sonnet'            # 구현 서브에이전트(general-purpose 등)가 쓸 모델 (별칭)
$script:FableMinCC     = [version]'2.1.196'  # prompt_id 지원 최소 버전

function Get-FableState {
    if (Test-Path $script:FableState) { (Get-Content $script:FableState -Raw).Trim() } else { 'missing' }
}

function Get-ClaudeExe {
    Get-Command claude -CommandType Application, ExternalScript -ErrorAction SilentlyContinue |
        Select-Object -First 1
}

function claude {
    $exe = Get-ClaudeExe
    if (-not $exe) { Write-Error 'claude 실행 파일을 찾을 수 없습니다.'; return }
    if ((Get-FableState) -eq 'on') {
        # CLAUDE_CODE_SUBAGENT_MODEL: model 을 지정하지 않은 서브에이전트(general-purpose 포함)의 모델.
        # 없으면 메인(Opus)을 그대로 물려받아 위임 효과가 사라짐.
        $names = @('CLAUDE_CODE_SUBAGENT_MODEL')
        $prev = @{}
        foreach ($n in $names) { $prev[$n] = [Environment]::GetEnvironmentVariable($n); Set-Item "Env:$n" $script:FableExecModel }
        try { & $exe.Source @args }
        finally {
            foreach ($n in $names) {
                if ($null -eq $prev[$n]) { Remove-Item "Env:$n" -ErrorAction SilentlyContinue } else { Set-Item "Env:$n" $prev[$n] }
            }
        }
    } else {
        & $exe.Source @args
    }
}

function Invoke-FableSettings {
    $script_ = Join-Path $script:FableHome 'hooks\fable-settings.py'
    if (Get-Command py -ErrorAction SilentlyContinue)          { & py -3 $script_ @args }
    elseif (Get-Command python -ErrorAction SilentlyContinue)  { & python $script_ @args }
    else { Write-Host '[!!] python 을 찾을 수 없습니다 (py 또는 python)' }
}

function fable {
    param(
        [Parameter(Position = 0)][string]$Cmd = 'help',
        [Parameter(Position = 1)][string]$Sub = '',
        [switch]$Local
    )
    $N = 20; if ($Sub -match '^\d+$') { $N = [int]$Sub }

    $active = Join-Path $script:FableHome 'active.md'
    $log    = Join-Path $script:FableHome 'gate.log'

    switch ($Cmd) {
        'on' {
            Set-Content -Path $script:FableState -Value 'on' -NoNewline -Encoding ascii
            # 심볼릭 링크 대신 복사 (개발자 모드·관리자 권한 불필요)
            Copy-Item (Join-Path $script:FableHome 'fable.md') $active -Force
            Write-Host 'fable: ON (다음 세션부터 적용)'
        }
        'off' {
            Set-Content -Path $script:FableState -Value 'off' -NoNewline -Encoding ascii
            [IO.File]::WriteAllText($active, '')   # BOM 없는 빈 파일 (PS 5.1 의 -Encoding utf8 은 BOM 을 남김)
            Write-Host 'fable: OFF (다음 세션부터 적용)'
        }
        'status' {
            $ok = { param($c, $m) if ($c) { Write-Host "[ok] $m" -ForegroundColor Green } else { Write-Host "[!!] $m" -ForegroundColor Yellow } }
            Write-Host ("state      : {0}" -f (Get-FableState))
            $isOn = (Test-Path $active) -and ([IO.File]::ReadAllText($active).Trim([char]0xFEFF, ' ', "`t", "`r", "`n").Length -gt 0)
            Write-Host ("active.md  : {0}" -f ($(if ($isOn) { 'fable.md 내용' } else { '비어 있음(off)' })))

            $claudeMd = Join-Path $HOME '.claude\CLAUDE.md'
            & $ok ((Test-Path $claudeMd) -and (Select-String -Path $claudeMd -Pattern 'fable/active.md' -SimpleMatch -Quiet)) 'CLAUDE.md import'

            $settings = Join-Path $HOME '.claude\settings.json'
            & $ok ((Test-Path $settings) -and (Select-String -Path $settings -Pattern 'orchestration-gate.py' -SimpleMatch -Quiet)) 'settings.json hook'

            $agents = Join-Path $HOME '.claude\agents'
            & $ok ((Test-Path (Join-Path $agents 'deep-reasoner.md')) -and (Test-Path (Join-Path $agents 'runner.md'))) 'agents 파일'

            & $ok ([bool](Get-Command py -ErrorAction SilentlyContinue) -or [bool](Get-Command python -ErrorAction SilentlyContinue)) 'python'

            $exe = Get-ClaudeExe
            $v = $null
            if ($exe) {
                $raw = (& $exe.Source --version 2>$null | Out-String)
                $m = [regex]::Match($raw, '\d+\.\d+\.\d+')
                if ($m.Success) { $v = [version]($m.Value) }
            }
            & $ok ($v -and $v -ge $script:FableMinCC) ("claude {0} (2.1.196 이상 필요)" -f $(if ($v) { $v } else { '?' }))

            Invoke-FableSettings status
            if (Test-Path $log) {
                $c = Get-Content $log -Encoding utf8
                $d = ($c | Select-String '"DENY"').Count
                $w = ($c | Select-String '"WARN"').Count
                $e = ($c | Select-String '"ERROR"').Count
                Write-Host "gate.log   : DENY $d / WARN $w / ERROR $e"
            }
        }
        'log' {
            if (Test-Path $log) { Get-Content $log -Encoding utf8 -Tail $N } else { Write-Host 'gate.log 없음' }
        }
        'global' {   # 전체 적용 스위치: ~\.claude\settings.json env 에 모델 변수 기록/제거 (IDE·앱 포함)
            Invoke-FableSettings global $Sub --model $script:FableExecModel
        }
        'project' {  # 프로젝트별 게이트 스위치: .\.claude\settings.json (-Local 이면 settings.local.json)
            if ($Local) { Invoke-FableSettings project $Sub --local } else { Invoke-FableSettings project $Sub }
        }
        default { Write-Host 'usage: fable on|off|status|log [n] | global on|off | project on|off [-Local]' }
    }
}

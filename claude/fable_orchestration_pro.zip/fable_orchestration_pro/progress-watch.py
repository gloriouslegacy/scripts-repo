#!/usr/bin/env python3
"""
progress-watch.py — 서브에이전트 진행 로그 감시 (Monitor 의 command 로 실행)

메인이 Monitor 에 아래 한 줄만 건다. 감시 루프를 매번 직접 작성하지 않는다.
  python3 "$HOME/.claude/fable/hooks/progress-watch.py" <스크래치패드 절대경로> [<유형>_<이름> ...]
  (Windows: py -3 "$HOME/.claude/fable/hooks/progress-watch.py" <경로> [...]  — Git Bash·PowerShell 공통)

변경 이유 (V3)
  - stdout 을 UTF-8 로 고정: Windows cp949 파이프에서 인코딩 오류로 죽거나 한글이 깨지던 문제.
  - 기대 이름 인자(<유형>_<이름>): 먼저 끝난 서브에이전트만 보고 감시가 일찍 끝나,
    아직 첫 줄을 안 쓴 서브에이전트가 감시에서 빠지던 문제. 이름별 NOFILE 도 낸다.
  - 전부 끝난 뒤 LINGER 초 더 지켜본 다음 종료(인자 없이 쓸 때의 같은 문제 완화).
  - 시작 시 무시한 파일·끝난 파일도 줄이 다시 늘면 재감시(같은 이름 재발주 대응).
  - 완료 판정을 '완료' 또는 'end done' 으로 한정("compile done" 같은 중간 줄 오인 방지).

감시 대상
  <dir>/progress_<유형>_<이름>.log  (유형: explore | logs | impl | analyze)
  서브에이전트는 단계마다 "<HH:MM> <단계> <결과>" 1줄을 덧붙인다.
  결과: ok | retry n/3 | fail | 완료

이벤트(= stdout 1줄 = 메인 1턴)는 조치가 필요한 것만 낸다
  STALL <파일> <분>   유형별 문턱 동안 줄이 안 늘었다. 파일당 1회, 줄이 다시 늘면 재무장
  FAIL  <파일> <줄>   서브에이전트가 시도 상한을 넘겨 포기했다(결과 'fail')
  ERROR <파일> <줄>   Traceback / FATAL 이 진행 로그에 찍혔다
  NOFILE <대상>       GRACE 초 동안 진행 파일이 안 생겼다(경로·이름 치환 실수)
  retry·ok 줄은 이벤트로 내지 않는다(서브에이전트가 스스로 3회까지 재시도).
  완료 줄은 이벤트 없이 감시만 끝낸다(완료 통지는 하네스가 따로 준다).

종료
  감시 중인 파일이 모두 완료/fail 이고, 기대 이름이 모두 나타났거나 NOFILE 로 보고됐으며,
  그 상태가 LINGER 초 유지되면 종료.
  시작 시점에 이미 끝났거나 STALE_AT_START 초 넘게 멈춰 있던 파일은 지난 작업으로 보고
  무시하되, 줄이 다시 늘면 감시에 넣는다.

의존: Python 3.8+
"""
import glob
import os
import re
import sys
import time

_SCALE = float(os.environ.get("FABLE_WATCH_SCALE", "1"))  # 문턱 일괄 조정(예: 1.5). 테스트용 축소도 가능
THRESHOLDS = {k: v * _SCALE for k, v in {"explore": 180, "logs": 300, "impl": 480, "analyze": 600}.items()}
DEFAULT_THRESHOLD = 480 * _SCALE
INTERVAL = float(os.environ.get("FABLE_WATCH_INTERVAL", "30"))
GRACE = float(os.environ.get("FABLE_WATCH_GRACE", "300"))
LINGER = float(os.environ.get("FABLE_WATCH_LINGER", "120"))
STALE_AT_START = 1800

DONE_RE = re.compile(r"(?:완료|\bend\s+done)\s*$", re.IGNORECASE)
FAIL_RE = re.compile(r"\bfail(ed)?\s*$", re.IGNORECASE)
ERROR_RE = re.compile(r"Traceback|\bFATAL\b")


def emit(line):
    sys.stdout.write(line + "\n")
    sys.stdout.flush()


def kind_of(path):
    m = re.match(r"progress_([a-z]+)_", os.path.basename(path))
    return m.group(1) if m else ""


def read_lines(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return [l.rstrip("\r\n") for l in f if l.strip()]
    except OSError:
        return None


def expected_name(arg):
    """'impl_auth' / 'progress_impl_auth' / 'progress_impl_auth.log' → 'progress_impl_auth.log'"""
    name = os.path.basename(arg)
    if not name.startswith("progress_"):
        name = "progress_" + name
    if not name.endswith(".log"):
        name += ".log"
    return name


def main():
    try:  # Windows 파이프 기본 인코딩(cp949 등)과 무관하게 UTF-8 로 출력
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    if len(sys.argv) < 2:
        emit("USAGE progress-watch.py <scratchpad-dir> [<kind>_<name> ...]")
        return 2
    root = os.path.abspath(os.path.expanduser(sys.argv[1]))
    expected = {expected_name(a) for a in sys.argv[2:]}
    pattern = os.path.join(root, "progress_*.log")
    start = time.time()

    # 파일별 상태: n(마지막 줄 수), changed(마지막 증가 시각), stalled(STALL 보냄), finished
    st = {}
    ignored = {}  # 시작 시 이미 끝났거나 오래 멈춘 파일 → 당시 줄 수. 줄이 늘면 감시에 넣는다
    for p in glob.glob(pattern):
        lines = read_lines(p) or []
        try:
            stale = start - os.path.getmtime(p) > STALE_AT_START
        except OSError:
            stale = False
        if stale or (lines and (DONE_RE.search(lines[-1]) or FAIL_RE.search(lines[-1]))):
            ignored[p] = len(lines)

    reported = set()   # NOFILE 을 낸 기대 이름
    nofile_any = False
    settled_since = None
    while True:
        now = time.time()
        for p in glob.glob(pattern):
            lines = read_lines(p)
            if lines is None:
                continue
            name = os.path.basename(p)
            if p in ignored:
                if len(lines) <= ignored[p]:
                    continue
                st[p] = {"n": ignored.pop(p), "changed": now, "stalled": False, "finished": False}
            s = st.get(p)
            if s is None:
                s = st[p] = {"n": 0, "changed": now, "stalled": False, "finished": False}

            if len(lines) > s["n"]:
                for line in lines[s["n"]:]:
                    if ERROR_RE.search(line):
                        emit(f"ERROR {name} {line[:200]}")
                last = lines[-1]
                s["n"], s["changed"], s["stalled"], s["finished"] = len(lines), now, False, False
                if DONE_RE.search(last):
                    s["finished"] = True
                elif FAIL_RE.search(last):
                    emit(f"FAIL {name} {last[:200]}")
                    s["finished"] = True
            if s["finished"]:
                continue

            limit = THRESHOLDS.get(kind_of(p), DEFAULT_THRESHOLD)
            idle = now - s["changed"]
            if not s["stalled"] and idle >= limit:
                emit(f"STALL {name} {idle / 60:.0f}분 무진행 (문턱 {limit / 60:.0f}분, 마지막: {(lines[-1] if lines else '-')[:120]})")
                s["stalled"] = True

        seen = {os.path.basename(p) for p in st}
        if now - start >= GRACE:
            for e in sorted(expected - seen - reported):
                emit(f"NOFILE {e} 에 새 진행 줄이 {GRACE / 60:.0f}분째 없음 (폴더: {root}) - 발주 문구의 경로·이름 치환 확인")
                reported.add(e)
            if not expected and not st and not nofile_any:
                emit(f"NOFILE {root} 에 progress_*.log 가 {GRACE / 60:.0f}분째 없음 - 발주 문구의 경로 치환 확인")
                nofile_any = True

        settled = (all(v["finished"] for v in st.values())
                   and not (expected - seen - reported)
                   and (bool(st) or bool(reported) or nofile_any))
        if not settled:
            settled_since = None
        else:
            if nofile_any and not st:
                return 0
            if settled_since is None:
                settled_since = now
            if now - settled_since >= LINGER:
                return 0
        time.sleep(INTERVAL)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(0)

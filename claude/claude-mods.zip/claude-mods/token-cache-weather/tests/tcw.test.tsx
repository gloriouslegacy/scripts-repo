import { expect, mock, test } from 'claude-code/testing'

import { cachePart } from '../hooks/cache'
import { gitPart, parseGit } from '../hooks/git'
import { chainName, modelName } from '../hooks/model'
import { bandLines, build, oneLine } from '../hooks/view'
import { delta, fmt, forecast, limitParts, span, sparkline } from '../hooks/weather'

const MIN = 60_000

test('pieces', () => {
  expect([24, 25, 50, 75, 90].map(p => forecast(p).word)).toEqual(['Clear', 'Cloudy', 'Showers', 'Storm', 'Compact soon'])
  expect(fmt(134_400)).toBe('134.4k')
  expect(sparkline([0, 36_100, 134_400])).toBe('▁▃█')
  expect(delta([36_100, 134_400])).toBe('▲ +98.3k')
  expect(cachePart(null, '1h', 0)).toBe('🧊 cache idle')
  expect(cachePart(0, '1h', 2 * MIN)).toBe('🧊 cache 58m')
  expect(cachePart(0, '5m', 5 * MIN)).toBe('🔥 cache expired')
  expect(span((2 * 24 + 11) * 60 * MIN)).toBe('2d 11h')
  expect(limitParts([{ kind: 'five_hour', percentUsed: 65, resetsAt: new Date(57 * MIN).toISOString() }], 0)).toEqual(['5h 35% left (57m)'])
})

test('model names and fallback chains', () => {
  expect(modelName('claude-opus-5-5')).toBe('Opus 5.5')
  expect(modelName('claude-sonnet-4-5-20250929')).toBe('Sonnet 4.5')
  expect(modelName('claude-opus-4-6[1m]')).toBe('Opus 4.6 (1M)')
  expect(modelName('sonnet')).toBe('Sonnet')
  expect(chainName(['sonnet', 'claude-haiku-4-5'])).toBe('Sonnet › Haiku 4.5')
  expect(chainName('sonnet,haiku')).toBe('Sonnet › Haiku')
  expect(chainName(undefined)).toBe(undefined)
})

test('git status part', () => {
  const s = parseGit('# branch.oid 1a2b3c4\n# branch.head main\n# branch.ab +2 -1\n1 .M N... a b c d e f x\n? y\n')
  expect(s && gitPart(s)).toBe('⎇ main ↑2 ↓1 ~1 ?1')
})

const sample = build({
  model: 'Opus 5.5',
  effort: 'high',
  fallback: 'Sonnet › Haiku',
  showWeather: true,
  tokens: 134_400,
  window: 200_000,
  turns: [0, 36_100, 134_400],
  git: '⎇ main ↑2 ~3',
  cache: '🧊 cache 58m',
  limits: ['5h 35% left (57m)', 'week 54% left (2d 11h)'],
  usd: 15.5,
})

test('one line and band layouts', () => {
  expect(oneLine(sample)).toBe(
    'Opus 5.5 · high · ⤷ Sonnet › Haiku · ☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k · ⎇ main ↑2 ~3 · 🧊 cache 58m · 5h 35% left (57m) · week 54% left (2d 11h) · $15.50',
  )
  expect(bandLines(sample).map(l => l.text)).toEqual([
    'Opus 5.5 · high · ⤷ Sonnet › Haiku   ⎇ main ↑2 ~3',
    '☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k',
    '🧊 cache 58m · 5h 35% left (57m) · week 54% left (2d 11h) · $15.50',
  ])
  const quiet = build({ showWeather: false, tokens: 1, window: 2, turns: [], cache: '🧊 cache idle', limits: [] })
  expect(bandLines(quiet).map(l => l.text)).toEqual(['🧊 cache idle'])
  const fallingBack = build({ model: 'Opus 5.5', fallback: 'Sonnet', activeFallback: 'Sonnet 4.5', showWeather: false, tokens: 1, window: 2, turns: [], cache: 'c', limits: [] })
  expect(oneLine(fallingBack)).toBe('Opus 5.5 · ⤷ now Sonnet 4.5 · c')
})

const usageValue = (tokens: number | undefined) => ({
  value: {
    startedAt: 0,
    rateLimits: [{ kind: 'five_hour', percentUsed: 65, resetsAt: new Date(1_000_000 + 300 * MIN).toISOString() }],
    context: { tokens, window: 200_000 },
    cost: { usd: 15.5 },
  },
})

const stepUsage = (model: string) => ({ input_tokens: 1, output_tokens: 1, cache_read_input_tokens: 0, cache_creation_input_tokens: 0, model })

test('line layout: one status line, countdown, effort and a fallback in use', { options: { layout: 'line', git: false } }, async ($, on) => {
  const clock = mock.clock(on, { now: 1_000_000 })
  const shown: (string | undefined)[] = []
  const toasts: string[] = []
  let tokens: number | undefined
  let answeredBy = 'claude-opus-5-5'
  on('session.usage', () => usageValue(tokens))
  on('session.model', () => ({ value: 'claude-opus-5-5' }))
  on('settings.read', () => ({ value: { effortLevel: 'medium', fallbackModel: ['sonnet', 'haiku'] } }))
  on('ui.status', (_$, e) => {
    shown.push(e.text)
    return { value: undefined }
  })
  on('ui.toast', (_$, e) => {
    toasts.push(e.text)
    return { value: undefined }
  })
  on('session.start', () => ({ cwd: '/' }))
  on('turn.complete', () => ({ text: '' }))
  on('turn.step', async function* (_$, e) {
    return { turnId: e.turnId, index: e.index, answer: '', toolUses: [], stopReason: 'end_turn', usage: stepUsage(answeredBy) }
  })
  const turn = { answer: 'ok', durationMs: 1, isAborted: false, turnId: 't', reason: 'answer' as const }
  const step = async () => {
    for await (const _ of $.turn.step({ turnId: 't', index: 0, model: answeredBy, effort: 'high', messageCount: 1 })) {
      // drain
    }
  }

  await $.session.start({ cwd: '/', surface: 'terminal', isInteractive: true })
  expect(shown.at(-1)).toBe('Opus 5.5 · medium · ⤷ Sonnet › Haiku · ☀ Clear 0% · 0/200k · ▁ · 🧊 cache idle · 5h 35% left (5h) · $15.50')

  tokens = 36_100
  await step()
  await $.turn.complete(turn)
  tokens = 134_400
  await step()
  await $.turn.complete(turn)
  expect(shown.at(-1)).toBe('Opus 5.5 · high · ⤷ Sonnet › Haiku · ☂ Showers 67% · 134.4k/200k · ▁▃█ ▲ +98.3k · 🧊 cache 60m · 5h 35% left (5h) · $15.50')

  answeredBy = 'claude-sonnet-4-5'
  await step()
  expect(shown.at(-1)).toContain('Opus 5.5 · high · ⤷ now Sonnet 4.5 · ')

  await clock.advance(56 * MIN)
  expect(shown.at(-1)).toContain('🧊 cache 4m')
  expect(toasts.length).toBe(1)
  await clock.advance(5 * MIN)
  expect(shown.at(-1)).toContain('🔥 cache expired')
  expect(toasts.length).toBe(1)
})

for (const surface of ['terminal', 'desktop'] as const) {
  test(`band layout: three lines above the prompt, other rows kept below, on ${surface}`, { options: { git: true } }, async ($, on) => {
    mock.clock(on, { now: 0 })
    const shown: (string | undefined)[] = []
    on('session.usage', () => usageValue(102_000))
    on('session.model', () => ({ value: 'claude-opus-5-5' }))
    on('session.cwd', () => ({ value: '/p' }))
    on('settings.read', () => ({ value: { effortLevel: 'xhigh' } }))
    on('process.run', () => ({ value: { exitCode: 0, stdout: '# branch.oid abc\n# branch.head main\n', stderr: '', isStdoutTruncated: false, isStderrTruncated: false } }))
    on('ui.status', (_$, e) => {
      shown.push(e.text)
      return { value: undefined }
    })
    on('session.start', () => ({ cwd: '/p' }))
    on('ui.render', ($$, e) => {
      const { Box, Text } = $$.ui.resolve(e)
      return (
        <Box key="engine">
          <Text>other row</Text>
        </Box>
      )
    })
    await $.session.start({ cwd: '/p', surface, isInteractive: true })
    expect(shown.at(-1)).toBe(undefined)

    const band = await $.ui.mount({ plugin: 'tcw', surface, component: 'AbovePrompt', props: { hasSurvey: false, isWorking: false, maxRows: 10, bodyColumns: 100, scroll: { offset: 0, bodyRows: 10 }, view: {} } })
    expect(await band.find({ text: /^Opus 5\.5 · xhigh {3}⎇ main ✓$/ })).toBeDefined()
    expect(await band.find({ text: /⎇ main ✓/ })).toBeDefined()
    expect(await band.find({ text: '☂ Showers 51% · 102k/200k · █' })).toBeDefined()
    expect(await band.find({ text: /^🧊 cache idle · 5h 35% left \(5h 17m\) · \$15\.50$/ })).toBeDefined()
    expect(await band.find({ text: 'other row' })).toBeDefined()
  })
}

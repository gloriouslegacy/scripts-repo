// tcw (token-cache-weather): pure helpers — forecast tier, number format, sparkline, delta, usage limits.

export type Forecast = { icon: string; word: string; color: string }

export const BARS = 12
const TICKS = '▁▂▃▄▅▆▇█'

export const forecast = (percent: number): Forecast => {
  if (percent < 25) return { icon: '☀', word: 'Clear', color: 'yellow' }
  if (percent < 50) return { icon: '☁', word: 'Cloudy', color: 'cyan' }
  if (percent < 75) return { icon: '☂', word: 'Showers', color: 'blue' }
  if (percent < 90) return { icon: '☇', word: 'Storm', color: 'magenta' }
  return { icon: '↯', word: 'Compact soon', color: 'red' }
}

/** 134400 → "134.4k", 200000 → "200k", 1000000 → "1M", 950 → "950". */
export const fmt = (n: number): string => {
  const a = Math.abs(n)
  const trim = (x: number) => x.toFixed(1).replace(/\.0$/, '')
  if (a >= 1_000_000) return `${trim(n / 1_000_000)}M`
  if (a >= 1_000) return `${trim(n / 1_000)}k`
  return `${Math.round(n)}`
}

/** Relative scale: the fullest turn shown is █, the rest in proportion to it. */
export const sparkline = (values: number[]): string => {
  const shown = values.slice(-BARS)
  const max = Math.max(0, ...shown)
  return shown
    .map(v => {
      const f = max > 0 ? Math.max(0, v) / max : 0
      return TICKS[Math.min(TICKS.length - 1, Math.floor(f * (TICKS.length - 1) + 0.5))] ?? ''
    })
    .join('')
}

export const delta = (values: number[]): string | null => {
  if (values.length < 2) return null
  const d = (values[values.length - 1] ?? 0) - (values[values.length - 2] ?? 0)
  if (d === 0) return '■ ±0'
  return d > 0 ? `▲ +${fmt(d)}` : `▼ −${fmt(-d)}`
}

export type Limit = { kind: string; percentUsed: number; resetsAt?: string }

/** 3_420_000 ms → "57m", 212_000_000 → "2d 10h", 5_400_000 → "1h 30m". */
export const span = (ms: number): string => {
  const m = Math.max(0, Math.ceil(ms / 60_000))
  const d = Math.floor(m / 1440)
  const h = Math.floor((m % 1440) / 60)
  const min = m % 60
  if (d > 0) return `${d}d ${h}h`
  if (h > 0) return min > 0 ? `${h}h ${min}m` : `${h}h`
  return `${min}m`
}

const LIMIT_NAMES: Record<string, string> = { five_hour: '5h', seven_day: 'week', spend_limit: 'spend' }

/** Each window as "5h 35% left (57m)": what is left and when it resets. */
export const limitParts = (limits: readonly Limit[], now: number): string[] =>
  limits.map(l => {
    const name = LIMIT_NAMES[l.kind] ?? l.kind.replace(/_/g, ' ')
    const left = Math.max(0, Math.round(100 - l.percentUsed))
    const at = l.resetsAt === undefined ? NaN : Date.parse(l.resetsAt)
    return Number.isNaN(at) ? `${name} ${left}% left` : `${name} ${left}% left (${span(at - now)})`
  })

// tcw (token-cache-weather): what the line shows, gathered once per refresh, and its two layouts —
// one status line under the prompt, or two to three coloured lines above it.
import type { TcwView } from '../types'
import { delta, fmt, forecast, sparkline } from './weather'

export type View = TcwView

export type Inputs = {
  model?: string
  effort?: string
  fallback?: string
  activeFallback?: string
  showWeather: boolean
  tokens: number
  window: number
  percent?: number
  turns: number[]
  git?: string
  cache: string
  limits: string[]
  usd?: number
}

export const build = (i: Inputs): View => {
  const v: View = { cache: i.cache, isCacheCold: !i.cache.startsWith('🧊'), limits: i.limits }
  if (i.model) v.model = i.model
  if (i.effort) v.effort = i.effort
  if (i.fallback) v.fallback = i.fallback
  if (i.activeFallback) v.activeFallback = i.activeFallback
  if (i.git) v.git = i.git
  if (i.usd !== undefined) v.usd = `$${i.usd.toFixed(2)}`
  if (i.showWeather) {
    const pct = i.percent ?? (i.window > 0 ? Math.round((i.tokens / i.window) * 100) : 0)
    const f = forecast(pct)
    const change = delta(i.turns)
    const chart = i.turns.length > 0 ? (change ? `${sparkline(i.turns)} ${change}` : sparkline(i.turns)) : undefined
    v.weather = { icon: f.icon, word: f.word, color: f.color, pct, tokens: `${fmt(i.tokens)}/${fmt(i.window)}` }
    if (chart) v.weather.chart = chart
  }
  return v
}

/** "Opus 5.5 · high · ⤷ Sonnet › Haiku", the fallback marked "⤷ now Sonnet 4.5" while it answers. */
export const modelBlock = (v: View): string | undefined => {
  if (!v.model && !v.effort && !v.fallback && !v.activeFallback) return undefined
  const bits: string[] = []
  if (v.model) bits.push(v.model)
  if (v.effort) bits.push(v.effort)
  if (v.activeFallback) bits.push(`⤷ now ${v.activeFallback}`)
  else if (v.fallback) bits.push(`⤷ ${v.fallback}`)
  return bits.join(' · ')
}

export const weatherBlock = (v: View): string | undefined =>
  v.weather ? [`${v.weather.icon} ${v.weather.word} ${v.weather.pct}%`, v.weather.tokens, v.weather.chart].filter(Boolean).join(' · ') : undefined

export const usageBlock = (v: View): string => [v.cache, ...v.limits, v.usd].filter(Boolean).join(' · ')

/** The one-line layout: model · weather · git · cache · limits · cost. */
export const oneLine = (v: View): string => [modelBlock(v), weatherBlock(v), v.git, usageBlock(v)].filter(Boolean).join(' · ')

/** The band layout: model and git / weather / cache, limits and cost; empty lines left out. */
export const bandLines = (v: View): { text: string; kind: 'model' | 'weather' | 'usage' }[] => {
  const top = [modelBlock(v), v.git].filter(Boolean).join('   ')
  const lines: { text: string; kind: 'model' | 'weather' | 'usage' }[] = []
  if (top) lines.push({ text: top, kind: 'model' })
  const w = weatherBlock(v)
  if (w) lines.push({ text: w, kind: 'weather' })
  lines.push({ text: usageBlock(v), kind: 'usage' })
  return lines
}

# my-mods

Four Claude Code mods (plugins of function hooks). Requires **Claude Code 2.1.287 or later**.
한국어 안내: [README.ko.md](README.ko.md)

---

## 1. What each mod does

### tcw (token-cache-weather) — the session at a glance

Two lines above the prompt (`tcw.layout`: `band`, the default), no prefix:

```
Opus 5.5 · high · ⤷ Sonnet › Haiku   ⎇ main ↑2 ~3
Ctx [███████---] 67%  |  5h 잔여 98% (리셋 2h16m)  |  주간 잔여 82% (리셋 2d 12h)
```

With `tcw.layout` = `line` the same goes in one status line under the prompt (Claude Code prefixes it with `⚠ tcw:`, which is why the plugin's name is short; the folder is still `token-cache-weather`).

| Part | Meaning |
|---|---|
| `Opus 5.5` | The current model (`(1M)` on a 1M-context variant); follows `/model` switches |
| `high` | Reasoning effort of the last response (`low` / `medium` / `high` / `xhigh` / `max`; `--effort`, `/effort`); before the first response, `effortLevel` from settings |
| `⤷ Sonnet › Haiku` | The fallback chain from `fallbackModel` in settings.json. While a fallback is answering it reads `⤷ now Sonnet 4.5`. A chain given only with `--fallback-model` is not visible to mods, so it shows only once a fallback answers |
| `⎇ main ↑2 ~3` | Git status: branch (`@1a2b3c4` when detached), `↑` to push, `↓` to pull, `+` staged, `~` modified, `?` untracked, `!` conflicts; `✓` when clean. Left out outside a repository |
| `Ctx [███████---] 67%` | Context window fill; `-%` before the first response. The bar turns yellow past 50% and red past 80% |
| `5h 잔여 98% (리셋 2h16m)` · `주간 잔여 82% (리셋 2d 12h)` | Usage left (잔여) in the 5-hour and weekly windows and time to reset (리셋); green, yellow under 50%, red under 20%. Subscriptions only |

Refreshes every 15 seconds and whenever a response arrives. Shows a toast once, 5 minutes before the prompt cache expires (1 minute for a 5-minute cache). **Uses no tokens**: it only reads figures the engine already has.

### change-tutor — Change Notes pane

Every file Claude creates or edits (Edit / Write) becomes a note with: the file and `+added -removed · time`, **🙋 Request** (your prompt for that turn), **🤔 Why it changed** (what Claude said right before the change) and the diff. From a note you can ask for **💡 Explain simply** or a four-choice **❓ Quiz**. Notes are kept across sessions (latest 100). The status line shows `📘 N change notes`.

### blast-radius — a safety net for risky shell commands

Before a risky Bash command runs, it works out what the command would change, shows it in a pane (or above the prompt in a narrow terminal), and asks **Cancel / Proceed**.

| Command | What it shows |
|---|---|
| `rm -r`, `rm -f`, `rm -rf` | Files that would be deleted, count and total size |
| `git reset --hard` | Uncommitted changes that would be lost |
| `git checkout -- <paths>`, `git restore <paths>` | Unstaged changes that would be discarded |
| `git clean -f…` | Untracked paths that would be removed (`git clean -n`) |
| `git push --force` / `-f` / `--force-with-lease` / `+ref` | Remote commits you do not have locally, which would be dropped |
| `manage.py migrate`, `rails/rake db:migrate`, `alembic upgrade`, `prisma migrate deploy/dev/reset`, … | Pending migrations |

Previews use read-only commands only (`find`, `du`, `git diff/status/log`, `git clean -n`, migration status). Follows `cd`, `pushd`, `popd` and `git -C`.

### replay-theater — step through the last turn's edits

When a turn that edited files ends, `▶ Replay: N edits` appears above the prompt. The Replay pane shows one edit at a time: step, tool, file, `+/-` counts, progress dots and a diff of up to 12 lines.

---

## 2. Install

Unzip to a folder you will keep, e.g. `C:\Users\<you>\claude-mods` or `~/claude-mods`, and run in that folder:

```bash
claude plugin marketplace add ./
claude plugin install tcw@my-mods --scope user
claude plugin install change-tutor@my-mods --scope user
claude plugin install blast-radius@my-mods --scope user
claude plugin install replay-theater@my-mods --scope user
```

- `--scope user` loads them in every project, in the terminal and in the desktop app's Code tab. Install only the ones you want.
- An "option not yet set" note at install is fine: defaults apply. Add `--config ttl=1h` / `--config model=haiku` to set them up front.
- The plugins are read straight from this folder: **do not move or delete it**. After editing a file, run `/reload-plugins`.

Other ways to load them:

```bash
# one session only
claude --plugin-dir ./token-cache-weather --plugin-dir ./change-tutor --plugin-dir ./blast-radius --plugin-dir ./replay-theater
```

```json
// ~/.claude/settings.json — always load (absolute paths; ";" on Windows, ":" on macOS/Linux)
{ "env": { "CLAUDE_CODE_PLUGIN_DIRS": "C:\\Users\\<you>\\claude-mods\\token-cache-weather;C:\\Users\\<you>\\claude-mods\\blast-radius" } }
```

Remove: `claude plugin uninstall <name>@my-mods`.
blast-radius needs `bash`, `git`, `find` and `du` on PATH (Git Bash on Windows provides them).

---

## 3. Usage

### tcw (token-cache-weather)

Nothing to do: the lines appear when a session starts. To show the fallback chain all the time, put it in `~/.claude/settings.json`: `{ "fallbackModel": ["sonnet", "haiku"] }`.

| Setting (`/config`) | Values | Default |
|---|---|---|
| `tcw.layout` | `band` (2 lines above the prompt), `line` (one status line under it) | `band` |
| `tcw.style` | `plain`, `chip` (each line on a shaded background), `box` (one rounded frame; two rows taller) — band only | `plain` |
| `tcw.model` | `true`, `false` — show the model, effort and fallback chain | `true` |
| `tcw.weather` | `true`, `false` — show the `Ctx [...]` meter | `true` |
| `tcw.git` | `true`, `false` — show the git part (runs `git status` on each refresh, no tokens) | `true` |
| `tcw.ttl` | `1h`, `5m` — the prompt-cache TTL the expiry toast counts from | `1h` |

### change-tutor

- The pane opens by itself on the first change of a session; open it any time with **`/change-tutor`**.
- Keys work while the pane has focus (click it, or `ctrl+x tab`):

| Key | Action |
|---|---|
| `h` / `l` | Previous / next note |
| `e` | 💡 Explain simply |
| `q` | ❓ Quiz (then `1`–`4` to answer) |
| `v` | ⤢ Show all / ⤡ Collapse the diff |
| `c` | Copy diff |

- Tabs **This session** / **All notes** and **Latest** are buttons.
- Explain and Quiz call a model only when pressed (tokens are spent then).

| Setting (`/config`) | Values | Default |
|---|---|---|
| `change-tutor.model` | `haiku`, `sonnet`, `opus` | `haiku` |

### blast-radius

Nothing to set up. When Claude runs a risky command:

1. The report appears in the **Blast radius** pane (or above the prompt in a narrow terminal).
2. A dialog asks `Risky command … Run it?` — **1 Cancel** (first, the safe default) or **2 Proceed**.
3. Cancel, Esc or dismissing the dialog refuses the command; Claude is told not to retry and to ask you.

If the check itself fails, the command is held rather than run. It is a safety net, not a permission system: `$(...)`, aliases, `eval`, scripts and `cd -` are not followed.

### replay-theater

- After a turn that edited files, click **Replay (r)** above the prompt (or focus the band with `ctrl+x tab` and press `r`), or run **`/replay`**.
- In the pane: `n` next · `p` previous · `c` or `Esc` close.
- Holds the last turn that made edits, for this session only. Diffs show at most 12 lines per step.

---

## Check

```bash
claude plugin validate ./<mod>
claude plugin test ./<mod>
```

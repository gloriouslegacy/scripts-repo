# Fable 오케스트레이션 V4 — Windows 설치 가이드 (처음 사용자용)

> 기준일 2026-10-09 · **Max 요금제 전용**. 개념·규칙·사용법은 `APPLY-GUIDE.md` 를 먼저 읽으세요. 이 문서는 PowerShell 에서의 설치와 Windows 특유의 주의점만 다룹니다.
> WSL 안에서 Claude Code 를 쓴다면 이 문서가 아니라 공통 가이드 6절(Linux)을 따르세요.
>
> 이미 V3 를 설치해 쓰고 있다면 **1절 대신 7절(갱신)** 만 실행하세요.

---

## 0. 준비물

시작 메뉴에서 **PowerShell** 을 엽니다(Windows PowerShell 5.1, PowerShell 7 모두 됩니다). 아래를 한 줄씩 입력해 확인합니다.

| 확인 명령 | 기대 결과 | 안 될 때 |
|---|---|---|
| `claude --version` | `2.1.271` 이상 | `claude update` |
| `py -3 --version` | `3.8` 이상 | `winget install Python.Python.3.12` 후 PowerShell 을 다시 엽니다 |
| `Get-ExecutionPolicy -Scope CurrentUser` | `RemoteSigned` 또는 `Unrestricted` | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |

배포 폴더(`fable_orchestration`)를 `다운로드` 에 두었다고 가정합니다. PowerShell 에서 그 폴더로 이동합니다.

```powershell
cd "$HOME\Downloads\fable_orchestration"
```

### macOS·Linux 와 다른 점 (알아 두기)

| 항목 | macOS/Linux | Windows |
|---|---|---|
| 켜고 끄기 | 심볼릭 링크 | **파일 복사** (관리자 권한·개발자 모드 불필요). 그래서 `fable.md` 를 고치면 `fable on` 을 다시 해야 반영 |
| 에이전트 설치 | 링크 | 복사 |
| 훅 실행 | `python3 "$HOME/…"` | `py` + 인자 방식 (Git Bash 가 있든 없든 동일) |
| 차단 대상 셸 | Bash | Bash + **PowerShell 도구** |
| 옵션 표기 | `--dry-run`, `--local` | `-DryRun`, `-Local` |

---

## 1. 새로 설치 (복사해서 한 번에 실행)

```powershell
$C = Join-Path $HOME '.claude'
$F = Join-Path $C 'fable'
New-Item -ItemType Directory -Force -Path "$F\hooks", "$F\state", "$C\agents" | Out-Null

Copy-Item .\fable.md, .\kickoff.md, .\coding-rules.md, .\env.ps1 $F -Force
Copy-Item .\orchestration-gate.py, .\fable-settings.py, .\progress-watch.py, .\folder-check.py "$F\hooks" -Force
foreach ($a in 'implementer', 'architect', 'deep-reasoner', 'runner') { Copy-Item ".\agent-$a.md" "$C\agents\$a.md" -Force }

# 켜고 끄는 스위치 파일 (BOM 없는 빈 파일)
function Write-Utf8($Path, $Text) { [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding $false)) }
Write-Utf8 "$F\empty.md"  ''
Write-Utf8 "$F\active.md" ''
Set-Content -Path "$C\.fable-state" -Value 'off' -NoNewline -Encoding ascii
```

> 에이전트 파일은 복사본입니다. 나중에 `agent-*.md` 를 고치면 `foreach` 줄을 다시 실행하세요.

---

## 2. PowerShell 명령 `fable` 연결

```powershell
if (-not (Test-Path $PROFILE)) { New-Item -ItemType File -Force -Path $PROFILE | Out-Null }
if (-not (Select-String -Path $PROFILE -Pattern 'fable\env.ps1' -SimpleMatch -Quiet)) {
  Add-Content -Path $PROFILE -Value "`n. `"`$HOME\.claude\fable\env.ps1`""
}
. $PROFILE
```

> Windows PowerShell 5.1 과 PowerShell 7 은 `$PROFILE` 이 다릅니다. 둘 다 쓰면 각각에서 한 번씩 실행하세요.

---

## 3. Claude 가 지시문을 읽게 하기

```powershell
$M = "$C\CLAUDE.md"
if (-not ((Test-Path $M) -and (Select-String -Path $M -Pattern 'fable/active.md' -SimpleMatch -Quiet))) {
  Add-Content -Path $M -Value "`n@~/.claude/fable/active.md" -Encoding utf8
}
```

> import 가 인식되지 않으면 절대 경로(슬래시)로 바꿉니다: `@C:/Users/<사용자>/.claude/fable/active.md`

---

## 4. 게이트(훅) 등록 (기존 설정을 보존하며 자동 병합)

```powershell
$S = "$C\settings.json"
$gate = ("$F\hooks\orchestration-gate.py") -replace '\\', '/'
$cfg = if (Test-Path $S) { Get-Content $S -Raw -Encoding utf8 | ConvertFrom-Json } else { [pscustomobject]@{} }
if (-not $cfg.PSObject.Properties['hooks']) { $cfg | Add-Member hooks ([pscustomobject]@{}) }
if (-not $cfg.hooks.PSObject.Properties['PreToolUse']) { $cfg.hooks | Add-Member PreToolUse @() }
$entry = [pscustomobject]@{
  matcher = 'Write|Edit|MultiEdit|NotebookEdit|Bash|PowerShell|Agent'
  hooks   = @([pscustomobject]@{ type = 'command'; command = 'py'; args = @('-3', $gate); timeout = 10 })
}
$cfg.hooks.PreToolUse = @($cfg.hooks.PreToolUse | Where-Object { ($_ | ConvertTo-Json -Depth 10) -notmatch 'orchestration-gate' }) + $entry
Copy-Item $S "$S.bak" -ErrorAction SilentlyContinue
Write-Utf8 $S ($cfg | ConvertTo-Json -Depth 20)
```

> `py` 런처가 없으면 `command = 'python'`, `args = @($gate)` 로 바꿉니다.

---

## 5. 확인

새 PowerShell 창을 열고:

```powershell
fable status
```

모든 줄이 `[ok]` 면 설치 끝입니다. `[!!]` 가 있으면 그 항목의 절로 돌아가세요.

```powershell
fable on        # 켜기 (새 세션부터)
```

새 Claude Code 세션을 열고 `/model` 에서 **Fable 5.1**, effort **medium** 을 고릅니다. 첫 사용 확인은 공통 가이드 4절.

---

## 6. Windows 에서 주의할 점

**시작 메뉴·IDE 에서 실행한 Claude Code 에는 모델 전환이 적용되지 않습니다.** `fable` 의 모델 전환은 PowerShell 에서 실행한 `claude` 에만 붙습니다(cmd, Git Bash, VS Code 확장, 데스크톱 앱은 해당 없음). 게이트와 지시문은 어디서든 동작합니다. 해결:

- PowerShell 에서 `code .` 로 VS Code 를 실행하거나,
- **`fable global on`** 을 한 번 실행합니다. `~\.claude\settings.json` 에 기록되어 IDE·앱·cmd·Git Bash 모두에 적용됩니다.

**게이트 설정값은 `settings.json` 의 `env` 로**: 훅이 셸을 거치지 않아 명령 앞에 변수를 붙일 수 없습니다. 프로젝트별 조정은 그 프로젝트의 `.claude\settings.json` 에 넣습니다. 예:

```json
{ "env": { "FABLE_MAX_LINES": "700", "FABLE_ROOT_ALLOW": "run_*.py,tools.ps1" } }
```

**백신·EDR**: 도구 호출마다 `py` 가 실행됩니다. 느려서 10초를 넘기면 통과(fail-open)되므로, `fable log` 에 기록이 없는데 차단이 안 되면 4절의 `timeout` 을 30 으로 올리세요.

**한글**: 게이트와 스크립트는 입출력을 UTF-8 로 고정해 cp949 콘솔에서도 안전합니다. `env.ps1` 은 BOM 포함 UTF-8 로 저장돼 있으니 다른 편집기로 저장할 때 인코딩을 유지하세요.

---

## 7. 기존 설치본(V3) 갱신

배포 폴더에서:

```powershell
$C = Join-Path $HOME '.claude'; $F = Join-Path $C 'fable'
function Write-Utf8($Path, $Text) { [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding $false)) }
Copy-Item "$F\active.md" "$F\active.md.bak-v3" -Force -ErrorAction SilentlyContinue   # 직접 고친 내용 백업
Copy-Item .\fable.md, .\kickoff.md, .\coding-rules.md, .\env.ps1 $F -Force
Copy-Item .\orchestration-gate.py, .\fable-settings.py, .\progress-watch.py, .\folder-check.py "$F\hooks" -Force
foreach ($a in 'implementer', 'architect', 'deep-reasoner', 'runner') { Copy-Item ".\agent-$a.md" "$C\agents\$a.md" -Force }
```

그다음 **4절의 훅 등록을 다시 실행**합니다(matcher 에 `Agent` 가 추가됨. 같은 항목을 교체하므로 중복되지 않습니다). 마지막으로:

```powershell
. $PROFILE
fable on          # active.md 를 새 fable.md 로 교체
fable status
```

> 앞으로 지시문은 `active.md` 가 아니라 **`fable.md` 를 고친 뒤 `fable on`** 으로 반영하세요. Windows 에서는 켜고 끌 때 `active.md` 가 덮어써집니다.

---

## 8. 제거

```powershell
fable global off; fable off
# ~\.claude\CLAUDE.md 에서 '@~/.claude/fable/active.md' 줄 삭제
# ~\.claude\settings.json 에서 orchestration-gate 훅 항목 삭제 (settings.json.bak 참고)
Remove-Item "$HOME\.claude\agents\implementer.md", "$HOME\.claude\agents\architect.md", "$HOME\.claude\agents\deep-reasoner.md", "$HOME\.claude\agents\runner.md" -ErrorAction SilentlyContinue
# $PROFILE 에서 '. "$HOME\.claude\fable\env.ps1"' 줄 삭제
Remove-Item -Recurse -Force "$HOME\.claude\fable", "$HOME\.claude\.fable-state"
```

---

## 9. 문제 해결

| 증상 | 조치 |
|---|---|
| "스크립트를 실행할 수 없습니다" | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| `fable` 을 찾을 수 없음 | `. $PROFILE` 또는 새 PowerShell 창. 5.1/7 중 어느 쪽 프로필에 넣었는지 확인 |
| `fable status` 에 `[!!] claude …` | `claude update` 로 2.1.271 이상 |
| 차단이 전혀 안 됨 | `fable status` 의 state/hook 확인, `py -3 --version`, 새 세션인지 |
| `gate.log` 에 `WARN prompt_id 없음` | Claude Code 가 오래됨. `claude update` |
| 서브에이전트가 Fable 로 돎 | 6절 (`fable global on`) |
| 한글이 깨짐 | `env.ps1` 을 BOM 포함 UTF-8 로 다시 저장 |

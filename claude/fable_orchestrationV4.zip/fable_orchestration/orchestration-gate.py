#!/usr/bin/env python3
"""
orchestration-gate.py — Fable 오케스트레이션 PreToolUse 게이트 (V4)

V3 까지의 변경 이유는 APPLY-GUIDE.md 의 변경점 표를 참고. V4 에서 추가된 것:
  - 읽기 전용 에이전트(architect·deep-reasoner·runner)의 셸 우회·코드 쓰기 차단
  - 지시 파일(CLAUDE.md, CLAUDE.local.md, .claude/rules/*.md) 서브에이전트 전면 차단
  - 모듈 안내 파일은 메인 Write 만, 30줄 초과 차단
  - 파일 줄 수 상한 500 (기존 초과 파일은 작업당 +30줄까지, [부채] 등록 파일 제외)
  - 빈 catch 차단 (새로 생기는 것만)
  - 루트 새 파일 생성 금지(코드·.md, 허용 목록), .md 는 docs/ 아래만, 안내 파일 없는 폴더에
    코드 생성 금지(옵트인)
  - Agent(general-purpose) 호출 차단 → implementer 유도

규칙 적용 순서 (main() 참조)
  0. fable off / 프로젝트 off → 전부 허용. 스크래치·임시 경로 파일은 모든 규칙 면제
  A. [전체] 자기 보호 (.fable-state, FABLE_GATE_OFF, fable-settings.py project/debt)
  B. [서브] 지시 파일 쓰기 전면 차단 / [메인] 모듈 안내 파일은 Write 만 + 30줄
  C. [서브] 읽기 전용 에이전트: 코드·지시 파일 쓰기와 셸 우회 차단 (architect 는 docs/ 허용)
  D. [전체] 기존 코드 파일 Write 재작성 차단
  E. [전체] 파일 줄 수 상한 / 빈 catch / 루트 생성 / .md 위치 / 안내 파일 필수(옵트인)
  F. [메인] Agent(general-purpose) 차단 / 셸 우회 차단 / 턴당 코드 파일 2개

설정 — 환경변수 또는 프로젝트 .claude/settings(.local).json 의 "env"
  FABLE_GATE_LIMIT=2          메인 턴당 코드 파일 수정 한도
  FABLE_REWRITE_LINES=50      이 줄 수를 넘는 기존 파일의 Write 차단
  FABLE_MAX_LINES=500         코드 파일 줄 수 상한
  FABLE_OVER_GROWTH=30        이미 상한을 넘은 파일에 작업당 허용하는 증가분
  FABLE_NAV_LINES=30          모듈 CLAUDE.md / CLAUDE.local.md 줄 수 상한
  FABLE_READONLY_AGENTS       읽기 전용 에이전트 이름 (쉼표). 기본 architect,deep-reasoner,runner
  FABLE_ROOT_ALLOW            루트에 생성을 허용할 파일 패턴 추가 (쉼표, fnmatch)
  FABLE_MD_ALLOW              docs/ 밖에 .md 생성을 허용할 경로 패턴 추가 (쉼표, fnmatch)
  FABLE_REQUIRE_FOLDER_MD=1   상위에 모듈 안내 파일이 없는 곳의 코드 생성 차단 (옵트인)
  FABLE_IGNORE_DEBT=1         [부채] 제외를 무시하고 줄 수 상한을 전부 적용 (fable debt enforce on)
  FABLE_GATE_OFF=1            이 프로젝트에서 게이트 비활성 (fable project off)

의존: Python 3.8+, Claude Code v2.1.196+ (prompt_id)
"""
import fnmatch
import json
import os
import re
import sys
import tempfile
import time

# ── 고정 설정 ─────────────────────────────────────────────────────────
HOME = os.path.expanduser("~")
FABLE_HOME = os.path.join(HOME, ".claude", "fable")
STATE_FILE = os.path.join(HOME, ".claude", ".fable-state")
COUNTER_DIR = os.path.join(FABLE_HOME, "state")
LOG_FILE = os.path.join(FABLE_HOME, "gate.log")
LOG_MAX_BYTES = 1_000_000

CODE_EXTS = (
    ".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".vue", ".svelte",
    ".java", ".kt", ".kts", ".scala", ".go", ".rs", ".c", ".h", ".cc", ".cpp",
    ".hpp", ".cs", ".swift", ".m", ".mm", ".rb", ".php", ".lua", ".dart",
    ".sh", ".bash", ".zsh", ".sql", ".r", ".jl", ".ex", ".exs", ".erl",
    ".clj", ".hs", ".ml", ".fs", ".pl", ".pm", ".ipynb",
    ".html", ".css", ".scss", ".sass", ".less", ".ps1", ".psm1", ".bat", ".cmd",
)
SHELL_TOOLS = {"Bash", "PowerShell"}
EDIT_TOOLS = {"Write", "Edit", "MultiEdit", "NotebookEdit"}
CASE_INSENSITIVE_FS = sys.platform in ("win32", "darwin")
REDIRECT_OK_EXTS = (".html", ".css", ".sql")
GENERATED_SEGMENTS = {"build", "generated", "node_modules", ".gradle", "dist", "out",
                      "target", "__pycache__", ".venv", "venv", ".next", "coverage"}
DATA_MD_SEGMENTS = {"fixtures", "assets", "resources", "testdata", "test-data", "snapshots"}
ROOT_MD_ALLOW = {"readme.md", "claude.md", "claude.local.md", "agents.md", "changelog.md",
                 "license.md", "contributing.md", "security.md", "code_of_conduct.md"}
ROOT_CODE_ALLOW = {"build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
                   "setup.py", "conftest.py", "manage.py", "gradlew.bat", "index.html",
                   "gulpfile.js", "webpack.config.js", "rollup.config.js", "karma.conf.js"}
ROOT_CODE_ALLOW_GLOBS = ("*.config.js", "*.config.ts", "*.config.mjs", "*.config.cjs",
                         "*.conf.js", "*.conf.ts", ".*")
DEFAULT_READONLY = "architect,deep-reasoner,runner"

# ── 정규식 ────────────────────────────────────────────────────────────
_EXT_ALT = "|".join(re.escape(e.lstrip(".")) for e in CODE_EXTS)
_CODE_PATH = r"""['"]?[^\s'";|&<>]+\.(?:%s)['"]?(?=\s|$|[;|&)])""" % _EXT_ALT
_CODE_PATH_RE = re.compile(_CODE_PATH, re.IGNORECASE)
_INSTR_PATH = r"""['"]?[^\s'";|&<>]*(?:CLAUDE\.local\.md|CLAUDE\.md|\.claude[\\/]rules[\\/][^\s'";|&<>]*\.md)['"]?"""
_INSTR_PATH_RE = re.compile(_INSTR_PATH, re.IGNORECASE)

_SCRATCH_PREFIX_RE = re.compile(
    r"""^(\$\{?(TEMP|TMP|TMPDIR)\}?|%(TEMP|TMP)%|\$env:(TEMP|TMP))([\\/]|$)|^(/tmp|/private/tmp|/var/folders)/""",
    re.IGNORECASE,
)
_SCRATCH_SEGMENT_RE = re.compile(r"[\\/](scratchpad|AppData[\\/]Local[\\/]Temp)[\\/]", re.IGNORECASE)

# 셸 차단 패턴 — mode: content(항상) / target(코드 경로가 스크래치뿐이면 허용) /
# redirect(target + REDIRECT_OK_EXTS 허용) / dest(cp·mv: 목적지 기준)
_INPLACE = r"\s(?:-[a-zA-Z]*i\b|--in-place)[^|;&]*"
_COMMON_PATTERNS = [
    (r"\bpy(?:thon[0-9.]*)?(?:\.exe)?\s+(?:-[0-9.]+\s+)?-c\b.*(open\([^,)]*,\s*(?:mode\s*=\s*)?['\"][^'\"]*[wax+]|write_text|write_bytes)", "python -c 파일 쓰기", "content"),
    (r"\bnode\s+(-e|--eval|-p)\b.*(writeFile|appendFile|createWriteStream)", "node -e 파일 쓰기", "content"),
    (r"\bgit\s+apply\b", "git apply", "content"),
    (r"(?<![0-9&])>>?\|?\s*" + _CODE_PATH, "코드 파일로 리다이렉트", "redirect"),
]
BASH_BLOCK_PATTERNS = _COMMON_PATTERNS + [
    (r"\bsed\b[^|;&]*" + _INPLACE + _CODE_PATH, "sed -i", "target"),
    (r"\bperl\b[^|;&]*" + _INPLACE + _CODE_PATH, "perl -i", "target"),
    (r"\bruby\b[^|;&]*" + _INPLACE + _CODE_PATH, "ruby -i", "target"),
    (r"(^|[;&|]\s*)patch\s+-", "patch", "content"),
    (r"\btee\b(\s+-[a-zA-Z]+)*\s+" + _CODE_PATH, "tee 코드 파일", "target"),
    (r"(?:^|[;&|\n]\s*)(?:cp|mv|install|rsync)\s[^;&|<>\n]*", "cp/mv 로 코드 파일 덮어쓰기", "dest"),
    (r"\bdd\b[^;&|]*\bof=" + _CODE_PATH, "dd of=", "target"),
    (r"(?:^|[;&|\n]\s*)truncate\s[^;&|]*" + _CODE_PATH, "truncate", "target"),
    (r"\bcat\b[^;&|]*<<-?\s*['\"]?\w+['\"]?[^;&|]*>\s*" + _CODE_PATH, "heredoc 코드 파일 생성", "target"),
]
POWERSHELL_BLOCK_PATTERNS = _COMMON_PATTERNS + [
    (r"\b(Set-Content|Add-Content|Out-File|sc|ac)\b[^;|]*" + _CODE_PATH, "PowerShell 파일 쓰기", "target"),
    (r"\bNew-Item\b[^;|]*" + _CODE_PATH + r"[^;|]*-Value\b", "New-Item -Value", "target"),
    (r"(?:^|[;|\n]\s*)(?:Copy-Item|Move-Item|cpi|mi|copy|move)\s[^;|<>\n]*", "Copy/Move-Item 로 코드 파일 덮어쓰기", "dest"),
    (r"\[(System\.)?IO\.File\]::(Write|Append)", "[IO.File]::Write*", "content"),
]
_SHELL_RE = {
    "Bash": [(re.compile(p, re.IGNORECASE | re.DOTALL), n, m) for p, n, m in BASH_BLOCK_PATTERNS],
    "PowerShell": [(re.compile(p, re.IGNORECASE | re.DOTALL), n, m) for p, n, m in POWERSHELL_BLOCK_PATTERNS],
}
_SQ_RE = re.compile(r"'([^']*)'")
_SQ_KEEP_RE = re.compile(r"[^\s;|&'\"]+\.[A-Za-z0-9]+")
_MESSAGE_ARG_RE = re.compile(
    r"""(?:(?<=\s)|^)(-m|--message|-b|--body|-t|--title|--description)(\s+|=)(?:"(?:[^"\\]|\\.)*"|'[^']*')""",
    re.DOTALL,
)
# 자기 보호: 상태 파일, FABLE_GATE_OFF, 프로젝트·부채 스위치 명령
_SELF_SHELL_RE = re.compile(
    r"""(?:>>?\|?\s*|\b(?:tee|rm|mv|cp|del|truncate|Set-Content|Add-Content|Out-File|Remove-Item|Move-Item|Copy-Item)\b[^;&|\n]*)['"]?[^\s'";|&<>]*\.fable-state"""
    r"""|FABLE_(?:GATE_OFF|IGNORE_DEBT|REQUIRE_FOLDER_MD)\\?['"]?\s*[:=]"""
    r"""|fable-settings\.py['"]?\s+(?:project|debt)\b""",
    re.IGNORECASE,
)
# 지시 파일을 대상으로 하는 셸 쓰기 (서브에이전트 전부, 메인은 모듈 안내 파일만)
_INSTR_SHELL_WRITE_RE = re.compile(
    r"""(?:(?<![0-9&])>>?\|?\s*|\b(?:tee|rm|del|mv|cp|install|rsync|truncate|Set-Content|Add-Content|Out-File|Remove-Item|Move-Item|Copy-Item|New-Item)\b[^;&|\n]*?|\b(?:sed|perl|ruby)\b[^|;&]*""" + _INPLACE + r""")""" + _INSTR_PATH,
    re.IGNORECASE,
)
# 빈 catch
_EMPTY_CATCH_RES = [
    re.compile(r"\bcatch\b\s*(?:\([^)]*\))?\s*\{\s*\}"),                      # Kotlin/Java/JS/C#/Swift
    re.compile(r"^[ \t]*except\b[^\n:]*:[ \t]*(?:pass|\.\.\.)[ \t]*$", re.M),      # Python inline
    re.compile(r"^[ \t]*except\b[^\n:]*:[ \t]*\n[ \t]*(?:pass|\.\.\.)[ \t]*$", re.M),  # Python 다음 줄
    re.compile(r"\brescue\b[^\n]*\n\s*end\b"),                                   # Ruby
]
_DEBT_LINE_RE = re.compile(r"^\s*-\s*\[부채\]\s*([^\s—\-(]+)", re.M)
_TRUE = {"1", "true", "yes", "on"}


# ── 공통 유틸 ─────────────────────────────────────────────────────────
def log(level, msg, **ctx):
    try:
        os.makedirs(FABLE_HOME, exist_ok=True)
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_BYTES:
            os.replace(LOG_FILE, LOG_FILE + ".1")
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "level": level, "msg": msg, **ctx}
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def allow():
    sys.exit(0)


def deny(reason, **ctx):
    log("DENY", reason, **ctx)
    payload = json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse", "permissionDecision": "deny",
        "permissionDecisionReason": reason}}, ensure_ascii=True)
    sys.stdout.write(payload + "\n")
    sys.stdout.flush()
    sys.exit(0)


def read_input():
    return json.loads(sys.stdin.buffer.read().decode("utf-8-sig"))


def fable_on():
    try:
        with open(STATE_FILE, encoding="utf-8-sig") as f:
            return f.read().strip().lower() == "on"
    except FileNotFoundError:
        return False


def _truthy(v):
    return str(v or "").strip().lower() in _TRUE


_PROJECT_ENV_CACHE = {}


def project_env(cwd):
    """cwd 에서 위로 올라가며 .claude/settings(.local).json 의 env 를 합친다 (가까운 쪽, local 우선)."""
    key = os.path.abspath(cwd or os.getcwd())
    if key in _PROJECT_ENV_CACHE:
        return _PROJECT_ENV_CACHE[key]
    merged = {}
    d = key
    for _ in range(32):
        for name in ("settings.json", "settings.local.json"):  # local 을 나중에 읽어 덮어씀
            p = os.path.join(d, ".claude", name)
            if os.path.isfile(p):
                try:
                    with open(p, encoding="utf-8-sig") as f:
                        env = (json.load(f) or {}).get("env") or {}
                    for k, v in env.items():
                        if k.startswith("FABLE_") and k not in merged:
                            merged[k] = v
                except Exception as e:
                    log("WARN", f"프로젝트 설정 읽기 실패: {p}: {e}")
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    _PROJECT_ENV_CACHE[key] = merged
    return merged


def setting(name, cwd, default=""):
    """환경변수 → 프로젝트 settings env → 기본값."""
    v = os.environ.get(name)
    if v is None or v == "":
        v = project_env(cwd).get(name)
    return default if v is None or str(v) == "" else str(v)


def setting_int(name, cwd, default):
    try:
        return int(setting(name, cwd, str(default)))
    except ValueError:
        return default


def is_code(path):
    return bool(path) and path.lower().endswith(CODE_EXTS)


def resolve(path, cwd):
    if not path:
        return ""
    path = os.path.expanduser(path)
    if not os.path.isabs(path):
        path = os.path.join(cwd or os.getcwd(), path)
    return os.path.normpath(path)


def file_key(path):
    return path.lower() if CASE_INSENSITIVE_FS else path


def _norm(p):
    try:
        p = os.path.realpath(p)
    except Exception:
        pass
    p = os.path.normcase(os.path.normpath(p))
    return p.lower() if CASE_INSENSITIVE_FS else p


def _scratch_roots(data):
    roots = [data.get("scratchpad_dir"), tempfile.gettempdir(),
             os.environ.get("TEMP"), os.environ.get("TMP"), os.environ.get("TMPDIR"),
             os.path.join(HOME, ".claude", "jobs")]
    return [_norm(r) for r in roots if r]


def is_scratch(path, cwd, data):
    raw = (path or "").strip("'\"")
    if not raw:
        return False
    if _SCRATCH_PREFIX_RE.search(raw) or _SCRATCH_SEGMENT_RE.search(raw.replace("/", os.sep)) \
            or _SCRATCH_SEGMENT_RE.search(raw):
        return True
    full = _norm(resolve(raw, cwd))
    return any(full == r or full.startswith(r.rstrip("\\/") + os.sep) for r in _scratch_roots(data))


def is_generated(path):
    parts = {p.lower() for p in re.split(r"[\\/]", path)}
    return bool(parts & GENERATED_SEGMENTS)


def count_lines(path):
    n = 0
    with open(path, "rb") as f:
        for _ in f:
            n += 1
    return n


def text_lines(s):
    if not s:
        return 0
    return s.count("\n") + (0 if s.endswith("\n") else 1)


def read_text(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.read()


def find_root(start):
    """프로젝트 루트. 우선순위: 가장 가까운 .git → 가장 가까운 .claude/CLAUDE.md → 가장 위쪽의 CLAUDE.md.
    모듈 폴더의 CLAUDE.md 는 루트가 아니므로 마지막 기준은 '가장 위쪽'을 쓴다."""
    d = os.path.abspath(start)
    if os.path.isfile(d):
        d = os.path.dirname(d)
    home = _norm(HOME)
    git = dot = None
    top_claude = None
    for _ in range(64):
        if _norm(d) == home:
            break
        if git is None and os.path.exists(os.path.join(d, ".git")):
            git = d
        if dot is None and os.path.isfile(os.path.join(d, ".claude", "CLAUDE.md")):
            dot = d
        if os.path.isfile(os.path.join(d, "CLAUDE.md")):
            top_claude = d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return git or dot or top_claude


def _under(path, base):
    p, b = _norm(path), _norm(base)
    return p == b or p.startswith(b.rstrip("\\/") + os.sep)


def _rel_parts(path, root):
    rel = os.path.relpath(path, root)
    return [p for p in re.split(r"[\\/]", rel) if p and p != "."]


def is_instruction_file(path):
    base = os.path.basename(path).lower()
    if base in ("claude.md", "claude.local.md"):
        return True
    return bool(re.search(r"[\\/]\.claude[\\/]rules[\\/].*\.md$", path, re.IGNORECASE))


def is_module_nav(path, root):
    """모듈 안내 파일: 프로젝트 안, 루트 직속이 아니고, .claude/ 나 ~/.claude 아래가 아닌 CLAUDE(.local).md"""
    if os.path.basename(path).lower() not in ("claude.md", "claude.local.md"):
        return False
    if _under(path, os.path.join(HOME, ".claude")):
        return False
    d = os.path.dirname(path)
    if root is None or not _under(path, root):
        return False
    if _norm(d) == _norm(root) or os.path.basename(d).lower() == ".claude":
        return False
    return True


def debt_exempt(path, root, cwd):
    """가장 가까운 상위 CLAUDE.local.md 의 [부채] 항목에 이 파일이 있으면 True."""
    if _truthy(setting("FABLE_IGNORE_DEBT", cwd)):
        return False
    d = os.path.dirname(path)
    stop = _norm(root) if root else None
    for _ in range(64):
        p = os.path.join(d, "CLAUDE.local.md")
        if os.path.isfile(p):
            try:
                for tok in _DEBT_LINE_RE.findall(read_text(p)):
                    tok = tok.strip().replace("\\", "/")
                    if tok.lower() == os.path.basename(path).lower() or \
                            _norm(path).replace("\\", "/").endswith("/" + tok.lower() if CASE_INSENSITIVE_FS else "/" + tok):
                        return True
            except Exception as e:
                log("WARN", f"CLAUDE.local.md 읽기 실패: {p}: {e}")
        if stop and _norm(d) == stop:
            break
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return False


def count_empty_catch(s):
    return sum(len(rx.findall(s)) for rx in _EMPTY_CATCH_RES) if s else 0


def edit_path(inp, cwd):
    return resolve(inp.get("file_path") or inp.get("notebook_path") or "", cwd)


def _occurrences(hay, needle):
    return hay.count(needle) if needle else 0


def projected_lines(tool, inp, path):
    """수정 결과 줄 수 (None 이면 계산 불가)."""
    current = count_lines(path) if os.path.isfile(path) else 0
    if tool == "Write":
        return current, text_lines(inp.get("content", ""))
    text = read_text(path) if os.path.isfile(path) else ""
    edits = inp.get("edits") if tool == "MultiEdit" else [inp]
    delta = 0
    for e in edits or []:
        old, new = e.get("old_string", ""), e.get("new_string", "")
        n = max(1, _occurrences(text, old)) if e.get("replace_all") else 1
        delta += n * (new.count("\n") - old.count("\n"))
    return current, current + delta


# ── 규칙 A: 자기 보호 ──────────────────────────────────────────────────
def rule_self_protect(tool, inp, cwd, who):
    msg = ("[fable-gate] 게이트 스위치(.fable-state, FABLE_GATE_OFF 등)와 부채 등록은 에이전트가 바꿀 수 없습니다. "
           "필요하면 사용자에게 `fable off`, `fable project off`, `fable debt …` 실행을 요청하세요.")
    if tool in SHELL_TOOLS:
        cmd = inp.get("command", "") or ""
        if _SELF_SHELL_RE.search(cmd):
            deny(msg, rule="self_protect", who=who, tool=tool, cmd=cmd[:300])
    elif tool in EDIT_TOOLS:
        path = edit_path(inp, cwd)
        base = os.path.basename(path).lower()
        if base == ".fable-state":
            deny(msg, rule="self_protect", who=who, path=path)
        if base in ("settings.json", "settings.local.json") \
                and os.path.basename(os.path.dirname(path)).lower() == ".claude" \
                and re.search(r"FABLE_(GATE_OFF|IGNORE_DEBT|REQUIRE_FOLDER_MD)", json.dumps(inp, ensure_ascii=False)):
            deny(msg, rule="self_protect", who=who, path=path)


# ── 규칙 B: 지시 파일 ──────────────────────────────────────────────────
def rule_instruction_files(tool, inp, cwd, data, is_sub, who, root):
    nav_lines = setting_int("FABLE_NAV_LINES", cwd, 30)
    if tool in SHELL_TOOLS:
        cmd = inp.get("command", "") or ""
        for m in _INSTR_SHELL_WRITE_RE.finditer(cmd):
            target = _INSTR_PATH_RE.search(m.group(0))
            tpath = resolve(target.group(0).strip("'\""), cwd) if target else ""
            if is_sub:
                deny("[fable-gate] 서브에이전트는 지시 파일(CLAUDE.md, CLAUDE.local.md, .claude/rules)을 "
                     "수정할 수 없습니다. 갱신이 필요하면 반환 요약의 open issues 에 적으세요.",
                     rule="instr_sub_shell", who=who, cmd=cmd[:300])
            if tpath and is_module_nav(tpath, root):
                deny("[fable-gate] 모듈 안내 파일은 셸이 아니라 Write 도구로 전체를 다시 써야 합니다 "
                     f"({nav_lines}줄 이하).", rule="nav_shell", who=who, cmd=cmd[:300])
        return
    if tool not in EDIT_TOOLS:
        return
    path = edit_path(inp, cwd)
    if not is_instruction_file(path):
        return
    if is_sub:
        deny("[fable-gate] 서브에이전트는 지시 파일(CLAUDE.md, CLAUDE.local.md, .claude/rules)을 "
             "수정할 수 없습니다. 갱신이 필요하면 반환 요약의 open issues 에 적으세요.",
             rule="instr_sub", who=who, path=path)
    if is_module_nav(path, root):
        if tool != "Write":
            deny("[fable-gate] 모듈 안내 파일(CLAUDE.md / CLAUDE.local.md)은 Edit 가 아니라 Write 로 "
                 "전체를 다시 씁니다. 지난 내용을 정리한 뒤 전체를 Write 하세요.",
                 rule="nav_write_only", who=who, path=path)
        n = text_lines(inp.get("content", ""))
        if n > nav_lines:
            deny(f"[fable-gate] 모듈 안내 파일은 {nav_lines}줄 이하여야 합니다 (지금 {n}줄). "
                 "오래된 항목을 지우거나 로드맵·docs/ 로 옮기세요. (FABLE_NAV_LINES)",
                 rule="nav_lines", who=who, path=path, lines=n)


# ── 규칙 C: 읽기 전용 에이전트 ─────────────────────────────────────────
def rule_readonly_agent(tool, inp, cwd, data, agent_type, root):
    names = {s.strip() for s in setting("FABLE_READONLY_AGENTS", cwd, DEFAULT_READONLY).split(",") if s.strip()}
    if agent_type not in names:
        return
    who = f"sub:{agent_type}"
    if tool in SHELL_TOOLS:
        rule_shell(tool, inp.get("command", "") or "", cwd, data, who,
                   f"{agent_type} 는 읽기 전용 에이전트라 셸로 파일을 수정할 수 없습니다")
        return
    if tool in EDIT_TOOLS:
        path = edit_path(inp, cwd)
        if is_scratch(path, cwd, data):
            return
        if agent_type == "architect" and root and _under(path, os.path.join(root, "docs")) \
                and not is_instruction_file(path):
            return
        deny(f"[fable-gate] {agent_type} 는 읽기 전용 에이전트입니다. 파일을 수정하지 말고 결과만 반환하세요"
             + (" (architect 는 docs/ 아래만 쓸 수 있습니다)." if agent_type == "architect" else "."),
             rule="readonly_agent", who=who, path=path)


# ── 규칙 D: 재작성 차단 ────────────────────────────────────────────────
def rule_full_rewrite(tool, inp, cwd, who, data):
    if tool != "Write":
        return
    path = resolve(inp.get("file_path", ""), cwd)
    if not is_code(path) or not os.path.isfile(path) or is_scratch(path, cwd, data):
        return
    lines = count_lines(path)
    if lines > setting_int("FABLE_REWRITE_LINES", cwd, 50):
        deny(f"[fable-gate] {os.path.basename(path)}({lines}줄)는 이미 존재하는 코드 파일입니다. "
             "Write로 전체를 다시 쓰지 말고 Edit로 바뀌는 부분만 수정하세요.",
             rule="full_rewrite", who=who, path=path, lines=lines)


# ── 규칙 E: 크기·품질·위치 ─────────────────────────────────────────────
def rule_line_limit(tool, inp, cwd, who, data, root):
    if tool not in ("Write", "Edit", "MultiEdit"):
        return
    path = edit_path(inp, cwd)
    if not is_code(path) or is_scratch(path, cwd, data) or is_generated(path):
        return
    max_lines = setting_int("FABLE_MAX_LINES", cwd, 500)
    growth = setting_int("FABLE_OVER_GROWTH", cwd, 30)
    try:
        current, result = projected_lines(tool, inp, path)
    except Exception as e:
        log("WARN", f"줄 수 계산 실패(허용): {path}: {e}")
        return
    if result <= max_lines:
        return
    if debt_exempt(path, root, cwd):
        return
    name = os.path.basename(path)
    if current <= max_lines:
        deny(f"[fable-gate] {name} 이(가) {result}줄이 되어 상한 {max_lines}줄을 넘습니다. "
             "이 파일을 키우지 말고 새 책임은 새 파일로 두세요. 분할이 필요하면 작업을 계속하고 "
             "open issues 에 적으세요. (FABLE_MAX_LINES / 사용자 승인 시 fable debt add)",
             rule="line_limit", who=who, path=path, current=current, result=result)
    if result > current + growth:
        deny(f"[fable-gate] {name} 은(는) 이미 {current}줄로 상한을 넘은 파일입니다. 작업당 +{growth}줄까지만 "
             f"허용됩니다 (지금 +{result - current}). 새 코드는 새 파일로 두고, 분할은 open issues 에 적으세요. "
             "(FABLE_OVER_GROWTH / 사용자 승인 시 fable debt add)",
             rule="line_growth", who=who, path=path, current=current, result=result)


def rule_empty_catch(tool, inp, cwd, who, data):
    if tool not in ("Write", "Edit", "MultiEdit"):
        return
    path = edit_path(inp, cwd)
    if not is_code(path) or is_scratch(path, cwd, data) or is_generated(path):
        return
    if tool == "Write":
        new = count_empty_catch(inp.get("content", ""))
        old = count_empty_catch(read_text(path)) if os.path.isfile(path) else 0
    else:
        edits = inp.get("edits") if tool == "MultiEdit" else [inp]
        new = sum(count_empty_catch(e.get("new_string", "")) for e in edits or [])
        old = sum(count_empty_catch(e.get("old_string", "")) for e in edits or [])
    if new > old:
        deny("[fable-gate] 빈 catch/except 는 금지입니다. 복구·번역·종단 중 하나로 처리하거나, "
             "정말 무시해야 하면 이유를 주석으로 적고 DEBUG 로그를 남기세요.",
             rule="empty_catch", who=who, path=path)


def _creating(path):
    return not os.path.exists(path)


def rule_root_create(tool, inp, cwd, who, data, root):
    if tool != "Write" or root is None:
        return
    path = edit_path(inp, cwd)
    if not _creating(path) or is_scratch(path, cwd, data):
        return
    if _norm(os.path.dirname(path)) != _norm(root):
        return
    base = os.path.basename(path)
    low = base.lower()
    extra = [p.strip() for p in setting("FABLE_ROOT_ALLOW", cwd).split(",") if p.strip()]
    if any(fnmatch.fnmatch(base, g) or fnmatch.fnmatch(low, g.lower()) for g in extra):
        return
    if low.endswith(".md"):
        if low in ROOT_MD_ALLOW:
            return
        deny(f"[fable-gate] 루트에 문서를 만들지 않습니다 ({base}). 문서는 docs/ 아래(요구사항은 docs/requirements/, "
             "결정은 docs/adr/)에 두세요. (FABLE_ROOT_ALLOW 로 예외 추가)",
             rule="root_md", who=who, path=path)
    if is_code(path):
        if low in ROOT_CODE_ALLOW or any(fnmatch.fnmatch(low, g) for g in ROOT_CODE_ALLOW_GLOBS):
            return
        deny(f"[fable-gate] 루트에 코드 파일을 만들지 않습니다 ({base}). 모듈 폴더(또는 scripts/) 안에 두세요. "
             "루트 설정 파일이면 사용자에게 FABLE_ROOT_ALLOW 추가를 요청하세요.",
             rule="root_code", who=who, path=path)


def rule_md_location(tool, inp, cwd, who, data, root):
    if tool != "Write" or root is None:
        return
    path = edit_path(inp, cwd)
    if not path.lower().endswith(".md") or not _creating(path) or is_scratch(path, cwd, data):
        return
    if not _under(path, root) or _norm(os.path.dirname(path)) == _norm(root):
        return
    if os.path.basename(path).lower() in ("claude.md", "claude.local.md"):
        return
    parts = _rel_parts(path, root)
    if parts and parts[0].lower() == "docs":
        return
    if any(p.startswith(".") for p in parts[:-1]):
        return
    if any(p.lower() in DATA_MD_SEGMENTS for p in parts[:-1]):
        return
    rel = "/".join(parts)
    extra = [p.strip() for p in setting("FABLE_MD_ALLOW", cwd).split(",") if p.strip()]
    if any(fnmatch.fnmatch(rel, g) for g in extra):
        return
    deny(f"[fable-gate] 문서는 docs/ 아래에 둡니다 ({rel}). 모듈 설명은 그 폴더의 CLAUDE.md(메인만 작성) 또는 "
         "docs/modules/<이름>.md 로. (FABLE_MD_ALLOW 로 예외 추가)",
         rule="md_location", who=who, path=path)


def rule_nav_required(tool, inp, cwd, who, data, root):
    if tool != "Write" or root is None or not _truthy(setting("FABLE_REQUIRE_FOLDER_MD", cwd)):
        return
    path = edit_path(inp, cwd)
    if not is_code(path) or not _creating(path) or is_scratch(path, cwd, data) or is_generated(path):
        return
    if not _under(path, root) or _norm(os.path.dirname(path)) == _norm(root):
        return
    parts = _rel_parts(path, root)
    if parts and parts[0].startswith("."):
        return
    d = os.path.dirname(path)
    while _norm(d) != _norm(root):
        if os.path.isfile(os.path.join(d, "CLAUDE.md")) or os.path.isfile(os.path.join(d, "CLAUDE.local.md")):
            return
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    deny(f"[fable-gate] {os.path.relpath(os.path.dirname(path), root)} 에는 모듈 안내 파일(CLAUDE.md)이 없습니다. "
         "새 모듈이면 만들지 말고 '새 모듈 필요: 이유' 를 반환하세요. 메인은 사용자와 인터뷰 후 CLAUDE.md 를 "
         "Write 합니다. (FABLE_REQUIRE_FOLDER_MD)",
         rule="nav_required", who=who, path=path)


# ── 규칙 F: 메인 전용 ──────────────────────────────────────────────────
def rule_agent_tool(tool, inp):
    if tool != "Agent":
        return
    st = str(inp.get("subagent_type", "") or "")
    if st.lower() == "general-purpose":
        deny("[fable-gate] general-purpose 대신 `implementer` 서브에이전트를 쓰세요 "
             "(코딩 규칙·진행 로그·반환 형식이 정의돼 있고 연쇄 위임·스킬 호출이 막혀 있습니다).",
             rule="agent_type", subagent_type=st)


def _dest_blocked(text, cwd, data):
    toks = [t for t in text.lstrip(";&| \t\r\n").split()[1:]
            if not t.startswith("-") and t.strip("'\"")]
    if len(toks) < 2:
        return False
    dest, srcs = toks[-1], toks[:-1]
    if is_scratch(dest, cwd, data):
        return False
    return is_code(dest.strip("'\"")) or any(is_code(s.strip("'\"")) for s in srcs)


def rule_shell(tool, cmd, cwd, data, who="main", why="메인 에이전트는 셸로 코드 파일을 수정할 수 없습니다"):
    scan = _MESSAGE_ARG_RE.sub(r"\1\2''", cmd)
    scan_q = _SQ_RE.sub(lambda m: m.group(0) if _SQ_KEEP_RE.fullmatch(m.group(1)) else "''", scan)
    for rx, name, mode in _SHELL_RE.get(tool, ()):
        if mode == "content":
            hit = rx.search(scan)
        else:
            hit = None
            for m in rx.finditer(scan_q):
                if mode == "dest":
                    bad = _dest_blocked(m.group(0), cwd, data)
                else:
                    targets = [t.group(0) for t in _CODE_PATH_RE.finditer(m.group(0))]
                    if mode == "redirect":
                        targets = [t for t in targets if not t.strip("'\"").lower().endswith(REDIRECT_OK_EXTS)]
                    bad = any(not is_scratch(t, cwd, data) for t in targets)
                if bad:
                    hit = m
                    break
        if hit:
            deny(f"[fable-gate] {why}({name}). 구현 작업은 implementer 서브에이전트에 위임하세요.",
                 rule="shell", who=who, tool=tool, pattern=name, cmd=cmd[:300])


def rule_turn_limit(tool, inp, cwd, data):
    path = edit_path(inp, cwd)
    if not is_code(path) or is_scratch(path, cwd, data) or is_generated(path):
        return
    prompt_id = data.get("prompt_id")
    if not prompt_id:
        log("WARN", "prompt_id 없음 — 턴 한도 미적용(fail-open). Claude Code v2.1.196+ 필요", tool=tool, path=path)
        return
    limit = setting_int("FABLE_GATE_LIMIT", cwd, 2)
    session = re.sub(r"[^A-Za-z0-9_-]", "_", data.get("session_id", "default"))
    os.makedirs(COUNTER_DIR, exist_ok=True)
    counter = os.path.join(COUNTER_DIR, f"turn-{session}.json")
    state = {"prompt_id": None, "files": []}
    if os.path.exists(counter):
        with open(counter, encoding="utf-8") as f:
            state = json.load(f)
    if state.get("prompt_id") != prompt_id:
        state = {"prompt_id": prompt_id, "files": []}
    if file_key(path) in (file_key(p) for p in state["files"]):
        return
    if len(state["files"]) >= limit:
        done = ", ".join(os.path.basename(p) for p in state["files"])
        deny(f"[fable-gate] 이번 턴에 메인이 수정할 수 있는 코드 파일 {limit}개를 모두 사용했습니다({done}). "
             f"{os.path.basename(path)} 수정을 포함한 나머지 구현은 implementer 서브에이전트에 위임하세요.",
             rule="turn_limit", path=path, used=state["files"])
    state["files"].append(path)
    tmp = counter + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f)
    os.replace(tmp, counter)


def cleanup_counters(max_age_sec=7 * 86400):
    try:
        now = time.time()
        for name in os.listdir(COUNTER_DIR):
            p = os.path.join(COUNTER_DIR, name)
            if now - os.path.getmtime(p) > max_age_sec:
                os.remove(p)
    except Exception:
        pass


# ── 진입점 ────────────────────────────────────────────────────────────
def main():
    if not fable_on():
        allow()
    data = read_input()
    tool = data.get("tool_name", "")
    inp = data.get("tool_input", {}) or {}
    cwd = data.get("cwd", "")
    if _truthy(setting("FABLE_GATE_OFF", cwd)):
        allow()
    is_sub = bool(data.get("agent_id"))
    agent_type = str(data.get("agent_type", "") or "")
    who = f"sub:{agent_type or '?'}" if is_sub else "main"

    target = edit_path(inp, cwd) if tool in EDIT_TOOLS else ""
    root = find_root(target or cwd or os.getcwd())
    if root is None:
        log("WARN", "프로젝트 루트를 찾지 못해 루트·문서 위치·안내 파일 규칙을 건너뜀", cwd=cwd, target=target)

    # A. 전체 공통
    rule_self_protect(tool, inp, cwd, who)
    # B. 지시 파일
    rule_instruction_files(tool, inp, cwd, data, is_sub, who, root)
    # C. 읽기 전용 에이전트
    if is_sub:
        rule_readonly_agent(tool, inp, cwd, data, agent_type, root)
    # D·E. 전체 공통 (코드 품질·위치)
    rule_full_rewrite(tool, inp, cwd, who, data)
    rule_line_limit(tool, inp, cwd, who, data, root)
    rule_empty_catch(tool, inp, cwd, who, data)
    rule_root_create(tool, inp, cwd, who, data, root)
    rule_md_location(tool, inp, cwd, who, data, root)
    rule_nav_required(tool, inp, cwd, who, data, root)

    if is_sub:
        allow()

    # F. 메인 전용
    rule_agent_tool(tool, inp)
    if tool in SHELL_TOOLS:
        rule_shell(tool, inp.get("command", "") or "", cwd, data)
    elif tool in EDIT_TOOLS:
        rule_turn_limit(tool, inp, cwd, data)
        if int(time.time()) % 50 == 0:
            cleanup_counters()
    allow()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:  # fail-open: 게이트 오류로 작업이 멈추지 않게 하되 반드시 기록
        log("ERROR", f"{type(e).__name__}: {e}")
        sys.exit(0)

# Fable 오케스트레이션 V4 — macOS 설치 가이드 (처음 사용자용)

> 기준일 2026-10-09 · **Max 요금제 전용**. 개념·규칙·사용법은 `APPLY-GUIDE.md` 를 먼저 읽으세요. 이 문서는 설치와 macOS 특유의 주의점만 다룹니다.
>
> **Windows 에서 쓰던 설치본을 옮기는 경우에도** Windows 의 `~/.claude/fable` 폴더를 복사하지 말고 이 배포 폴더로 새로 설치하세요. Windows 의 `settings.json`(훅이 `py` + `C:/…` 경로), `env.ps1`, `state/`, `gate.log`, `.fable-state` 는 맥에서 쓸 수 없습니다.

---

## 0. 준비물

터미널을 엽니다(Spotlight 에서 "터미널" 검색). 아래를 한 줄씩 입력해 확인합니다.

| 확인 명령 | 기대 결과 | 안 될 때 |
|---|---|---|
| `claude --version` | `2.1.271` 이상 | `claude update` |
| `python3 --version` | `3.8` 이상 | 처음이면 "명령어 라인 개발자 도구 설치" 창이 뜹니다. 설치 후 다시 실행. 또는 `brew install python` |
| `echo $SHELL` | `/bin/zsh` | bash 면 아래에서 `~/.zshrc` 를 `~/.bash_profile` 로 바꿔 읽으세요 |

배포 폴더(`fable_orchestration`)를 `~/Downloads` 에 두었다고 가정합니다. 다른 곳이면 아래 `SRC` 값을 바꾸세요.

---

## 1. 파일 설치 (복사해서 한 번에 실행)

```bash
SRC=~/Downloads/fable_orchestration
F=~/.claude/fable

mkdir -p $F/hooks $F/state ~/.claude/agents
cp "$SRC"/fable.md "$SRC"/kickoff.md "$SRC"/coding-rules.md "$SRC"/env.sh $F/
cp "$SRC"/orchestration-gate.py "$SRC"/fable-settings.py "$SRC"/progress-watch.py "$SRC"/folder-check.py $F/hooks/
chmod +x $F/hooks/*.py
for a in implementer architect deep-reasoner runner; do cp "$SRC"/agent-$a.md ~/.claude/agents/$a.md; done

# Windows 에서 받은 파일이면 줄바꿈(CRLF)·BOM 정리 (이미 정상이면 변화 없음)
for f in $F/fable.md $F/kickoff.md $F/coding-rules.md $F/env.sh $F/hooks/*.py ~/.claude/agents/*.md; do
  sed -i '' -e $'s/\r$//' -e $'1s/^\xEF\xBB\xBF//' "$f"
done

# 켜고 끄는 스위치 파일
: > $F/empty.md
echo off > ~/.claude/.fable-state
ln -sfn $F/empty.md $F/active.md
```

> 에이전트 파일은 복사본입니다. 나중에 `agent-*.md` 를 고치면 위 `for a in …` 줄을 다시 실행하세요.

---

## 2. 터미널 명령 `fable` 연결

```bash
grep -q 'fable/env.sh' ~/.zshrc 2>/dev/null || echo '[ -f "$HOME/.claude/fable/env.sh" ] && source "$HOME/.claude/fable/env.sh"' >> ~/.zshrc
source ~/.zshrc
```

> `~/.zshrc` 에 `alias claude=…` 가 이미 있으면 함수 정의와 충돌합니다. 그 줄을 지우거나, 위 줄보다 앞에 `unalias claude 2>/dev/null` 을 넣으세요.

---

## 3. Claude 가 지시문을 읽게 하기

```bash
grep -q 'fable/active.md' ~/.claude/CLAUDE.md 2>/dev/null || echo '@~/.claude/fable/active.md' >> ~/.claude/CLAUDE.md
```

---

## 4. 게이트(훅) 등록

`~/.claude/settings.json` 에 아래 내용이 들어가야 합니다. 파일이 없으면 그대로 만들고, 이미 있으면 `hooks.PreToolUse` 배열에 항목을 추가합니다.

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit|NotebookEdit|Bash|Agent",
        "hooks": [
          { "type": "command", "command": "python3 \"$HOME/.claude/fable/hooks/orchestration-gate.py\"", "timeout": 10 }
        ]
      }
    ]
  }
}
```

손으로 고치기 번거로우면 `jq` 로 자동 병합할 수 있습니다(`brew install jq` 가 필요).

```bash
f=~/.claude/settings.json; [ -f "$f" ] || echo '{}' > "$f"
jq '(.hooks.PreToolUse // []) as $h | .hooks.PreToolUse = ([$h[] | select((.hooks[0].command // "") | test("orchestration-gate") | not)] + [{"matcher":"Write|Edit|MultiEdit|NotebookEdit|Bash|Agent","hooks":[{"type":"command","command":"python3 \"$HOME/.claude/fable/hooks/orchestration-gate.py\"","timeout":10}]}])' "$f" > "$f.tmp" && mv "$f.tmp" "$f"
```

---

## 5. 확인

```bash
fable status
```

모든 줄이 `[ok]` 면 설치 끝입니다. `[!!]` 가 있으면 그 항목의 절로 돌아가세요.

```bash
fable on        # 켜기 (새 세션부터)
```

새 Claude Code 세션을 열고 `/model` 에서 **Fable 5.1**, effort **medium** 을 고릅니다. 첫 사용 확인은 공통 가이드 4절.

---

## 6. macOS 에서 주의할 점

**Dock·Spotlight 로 실행한 IDE·데스크톱 앱에는 모델 전환이 적용되지 않습니다.** `fable` 명령의 모델 전환은 터미널에서 실행한 `claude` 에만 붙습니다. 게이트와 지시문은 어디서든 동작하고, 영향을 받는 것은 "서브에이전트가 Opus 5.5 로 실행되는지" 하나입니다. 해결:

- 터미널에서 `code .` / `idea .` 로 IDE 를 실행하거나,
- **`fable global on`** 을 한 번 실행합니다. `~/.claude/settings.json` 에 기록되어 IDE·앱에도 적용됩니다. (`fable off` 여도 서브에이전트 모델은 유지되지만, 기본 모드의 메인도 Opus 5.5 라 손해는 없습니다.)

**대소문자**: macOS 파일 시스템은 대소문자를 구분하지 않습니다. 게이트는 `App.py` 와 `app.py` 를 같은 파일로 셉니다.

**zsh 와 `$HOME`**: Claude 에게 주는 경로는 `$HOME/.claude/fable/…` 형태입니다. `~` 는 Claude 의 도구가 해석하지 못할 수 있습니다.

---

## 7. 기존 설치본(V3) 갱신

```bash
SRC=~/Downloads/fable_orchestration; F=~/.claude/fable
cp "$SRC"/fable.md "$SRC"/kickoff.md "$SRC"/coding-rules.md "$SRC"/env.sh $F/
cp "$SRC"/*.py $F/hooks/ && chmod +x $F/hooks/*.py
for a in implementer architect deep-reasoner runner; do cp "$SRC"/agent-$a.md ~/.claude/agents/$a.md; done
rm -f ~/.claude/agents/general-purpose.md 2>/dev/null
source ~/.zshrc
```

그리고 4절의 훅 등록을 다시 합니다(matcher 에 `Agent` 가 추가됨). `fable.md` 는 심볼릭 링크라 `fable on` 상태면 바로 반영됩니다. `fable status` 로 확인.

---

## 8. 제거

```bash
fable global off; fable off
# ~/.claude/CLAUDE.md 에서 '@~/.claude/fable/active.md' 줄 삭제
# ~/.claude/settings.json 에서 orchestration-gate.py 훅 항목 삭제
rm -f ~/.claude/agents/{implementer,architect,deep-reasoner,runner}.md
# ~/.zshrc 에서 'source "$HOME/.claude/fable/env.sh"' 줄 삭제
rm -rf ~/.claude/fable ~/.claude/.fable-state
```

프로젝트 안에 만든 `docs/`, 모듈 `CLAUDE.md`, `CLAUDE.local.md`, `.claude/settings.json` 의 `FABLE_…` 항목은 그대로 두어도 해가 없습니다.

---

## 9. 문제 해결

| 증상 | 조치 |
|---|---|
| `fable: command not found` | `source ~/.zshrc` 또는 새 터미널 |
| `python3` 실행 시 개발자 도구 설치 창 | 설치 후 다시 시도. 설치 전에는 게이트가 동작하지 않습니다 |
| `fable status` 에 `[!!] claude …` | `claude update` 로 2.1.271 이상 |
| 차단이 전혀 안 됨 | `fable status` 의 state/hook 확인, 새 세션인지 확인 |
| `gate.log` 에 `ERROR` | `fable log 20` 메시지를 확인해 공유 |
| 서브에이전트가 Fable 로 돎 | 6절 (`fable global on`) |

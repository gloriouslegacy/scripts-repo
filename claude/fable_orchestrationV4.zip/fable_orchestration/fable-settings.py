#!/usr/bin/env python3
"""
fable-settings.py — settings.json 스위치 (전체 적용 / 프로젝트별 끄기)

env.sh / env.ps1 의 `fable global …`, `fable project …` 가 호출한다.
JSON 편집을 한 곳에 모아 macOS·Linux·Windows 에서 같은 동작을 보장한다.

  global on      ~/.claude/settings.json 의 env 에 서브에이전트 모델 변수 2개 기록
                 → 터미널·IDE 확장·데스크톱 앱 어디서 실행해도 Opus 5.5 전환 적용
  global off     위 변수 2개 제거 (셸 래퍼만 남음)
  project off    <현재 폴더>/.claude/settings.json 의 env 에 FABLE_GATE_OFF=1 기록
                 → 이 프로젝트에서는 게이트가 전부 허용
  project on     FABLE_GATE_OFF 제거
  project require-md on|off   (V4) 모듈 안내 파일 없는 곳의 코드 생성 차단 옵트인 (FABLE_REQUIRE_FOLDER_MD)
  status         전체/프로젝트 상태 출력
  debt list                  (V4) 모든 CLAUDE.local.md 의 [부채] + docs/tech-debt.md 표
  debt add <파일> "<조건>"    [부채] 등록 (가장 가까운 상위 모듈의 CLAUDE.local.md). 조건에 '영구' 허용
  debt fix <파일>             [부채] 삭제 → docs/tech-debt.md 에 "고친다" 항목. 줄 수 상한이 다시 적용
  debt keep <파일> "<조건>"   조건·기한 갱신
  debt drop <파일>            해결됨 → 항목 제거
  debt enforce on|off         FABLE_IGNORE_DEBT (프로젝트 env). on 이면 모든 [부채] 제외 무시

옵션
  --local        project 명령을 settings.local.json 에 적용 (git 에 커밋되지 않음)
  --model ID     global on 에 쓸 모델 (기본 claude-opus-5-5)
  --dir PATH     project 명령의 대상 폴더 (기본 현재 폴더)
"""
import argparse
import json
import os
import sys

DEFAULT_MODEL = "claude-opus-5-5"
GLOBAL_KEYS = ("CLAUDE_CODE_SUBAGENT_MODEL", "ANTHROPIC_DEFAULT_SONNET_MODEL")
PROJECT_KEY = "FABLE_GATE_OFF"
REQUIRE_KEY = "FABLE_REQUIRE_FOLDER_MD"
IGNORE_DEBT_KEY = "FABLE_IGNORE_DEBT"
NAV_LINES = int(os.environ.get("FABLE_NAV_LINES", "30"))


def load(path):
    if not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8-sig") as f:
        text = f.read().strip()
    data = json.loads(text) if text else {}
    if not isinstance(data, dict):
        print(f"경고: {path} 최상위가 JSON 객체가 아니라 빈 설정으로 취급합니다", file=sys.stderr)
        return {}
    return data


def save(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        with open(path, "rb") as src:
            raw = src.read()
        # .bak 은 직전 상태, .fable-orig.bak 은 이 스크립트가 처음 손대기 전 원본(1회만 생성)
        orig = path + ".fable-orig.bak"
        if not os.path.exists(orig):
            with open(orig, "wb") as dst:
                dst.write(raw)
        with open(path + ".bak", "wb") as dst:
            dst.write(raw)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def set_env(path, updates, remove=()):
    data = load(path)
    env = data.get("env")
    if not isinstance(env, dict):
        env = {}
    env.update(updates)
    for k in remove:
        env.pop(k, None)
    if env:
        data["env"] = env
    else:
        data.pop("env", None)
    save(path, data)


def global_path():
    return os.path.join(os.path.expanduser("~"), ".claude", "settings.json")


def project_path(d, local):
    name = "settings.local.json" if local else "settings.json"
    return os.path.join(os.path.abspath(d), ".claude", name)


def status(d):
    g = load(global_path()).get("env", {}) or {}
    gm = g.get("CLAUDE_CODE_SUBAGENT_MODEL")
    print(f"global     : {'ON  (' + gm + ')' if gm else 'off (셸 래퍼만 적용)'}")
    # 게이트와 같은 기준: 현재 폴더에서 위로 올라가며 값이 참(1/true/yes/on)인지 확인
    cur = os.path.abspath(d)
    for _ in range(32):
        for local in (True, False):
            p = project_path(cur, local)
            try:
                e = load(p).get("env", {}) or {}
            except Exception:
                e = {}
            if str(e.get(PROJECT_KEY, "")).strip().lower() in ("1", "true", "yes", "on"):
                print(f"project    : 게이트 OFF ({p})")
                return
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    print("project    : 게이트 on")
    root = find_root(d)
    nd = sum(1 for _ in iter_debts(root))
    print(f"require-md : {'ON' if _flag(root, REQUIRE_KEY) else 'off'}   부채: {nd}개{'  (enforce ON)' if _flag(root, IGNORE_DEBT_KEY) else ''}")


# ── (V4) 부채 관리 ─────────────────────────────────────────────────────
import re
import datetime

DEBT_RE = re.compile(r"^\s*-\s*\[부채\]\s*(\S+)\s*[—-]\s*(.*?)(?:\s*\(등록\s*([0-9-]+)\))?\s*$")
SKIP_DIRS = {"node_modules", ".git", "build", ".gradle", "venv", ".venv", "dist", "target", "__pycache__"}


def find_root(start):
    d = os.path.abspath(start)
    home = os.path.expanduser("~")
    git = dot = top = None
    for _ in range(64):
        if os.path.normcase(d) == os.path.normcase(home):
            break
        if git is None and os.path.exists(os.path.join(d, ".git")):
            git = d
        if dot is None and os.path.isfile(os.path.join(d, ".claude", "CLAUDE.md")):
            dot = d
        if os.path.isfile(os.path.join(d, "CLAUDE.md")):
            top = d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return git or dot or top or os.path.abspath(start)


def read_lines(p):
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig") as f:
        return [l.rstrip("\n") for l in f]


def write_lines(p, lines):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(lines).rstrip("\n") + "\n")


def local_md_for(path, root):
    """파일의 상위 모듈 폴더(루트 제외) 중 안내 파일이 있는 가장 가까운 곳의 CLAUDE.local.md. 없으면 바로 위 폴더."""
    d = os.path.dirname(os.path.abspath(path))
    first = None
    while os.path.normcase(d) != os.path.normcase(root):
        if first is None:
            first = d
        if os.path.isfile(os.path.join(d, "CLAUDE.md")) or os.path.isfile(os.path.join(d, "CLAUDE.local.md")):
            return os.path.join(d, "CLAUDE.local.md")
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return os.path.join(first or root, "CLAUDE.local.md")


def iter_debts(root):
    for dp, dn, fn in os.walk(root):
        dn[:] = [x for x in dn if x not in SKIP_DIRS]
        if "CLAUDE.local.md" in fn:
            p = os.path.join(dp, "CLAUDE.local.md")
            for i, line in enumerate(read_lines(p)):
                m = DEBT_RE.match(line)
                if m:
                    yield p, i, m.group(1), m.group(2).strip(), m.group(3) or ""


def match_file(tok, path):
    tok = tok.replace("\\", "/").lower()
    full = os.path.abspath(path).replace("\\", "/").lower()
    return full.endswith("/" + tok) or os.path.basename(full) == tok


def count_file_lines(p):
    try:
        with open(p, "rb") as f:
            return sum(1 for _ in f)
    except OSError:
        return -1


def _flag(root, key):
    e = load(project_path(root, False)).get("env", {}) or {}
    el = load(project_path(root, True)).get("env", {}) or {}
    return str(el.get(key, e.get(key, ""))).lower() in ("1", "true", "yes", "on")


def debt_list(root):
    today = datetime.date.today()
    rows = []
    for p, i, tok, cond, date in iter_debts(root):
        target = os.path.join(os.path.dirname(p), tok)
        n = count_file_lines(target) if os.path.exists(target) else -1
        st = "영구" if "영구" in cond else "유효"
        m = re.search(r"(20\d{2}-\d{2}-\d{2})", cond)
        if m and datetime.date.fromisoformat(m.group(1)) < today:
            st = "기한 지남"
        rows.append((os.path.relpath(p, root), tok, n, cond, date, st))
    print(f"부채 enforce : {'ON (모든 [부채] 제외 무시 중)' if _flag(root, IGNORE_DEBT_KEY) else 'off'}")
    if not rows:
        print("[부채] 항목 없음")
    else:
        print(f"{'위치':<26} {'파일':<26} {'줄수':>5}  {'상태':<6} 조건 (등록일)")
        for loc, tok, n, cond, date, st in rows:
            print(f"{loc:<26} {tok:<26} {n:>5}  {st:<6} {cond} ({date or '-'})")
    td = os.path.join(root, "docs", "tech-debt.md")
    if os.path.exists(td):
        items = [l for l in read_lines(td) if l.strip().startswith("- ")]
        print(f"docs/tech-debt.md : 고친다 항목 {len(items)}개")


def debt_add(root, path, cond, keep=False):
    lp = local_md_for(path, root)
    lines = read_lines(lp)
    tok = os.path.relpath(os.path.abspath(path), os.path.dirname(lp)).replace("\\", "/")
    today = datetime.date.today().isoformat()
    out, replaced = [], False
    for l in lines:
        m = DEBT_RE.match(l)
        if m and match_file(m.group(1), path):
            out.append(f"- [부채] {m.group(1)} — {cond} (등록 {m.group(3) or today})")
            replaced = True
            continue
        out.append(l)
    if keep and not replaced:
        print(f"오류: [부채] 항목이 없어 keep 할 수 없습니다: {path}", file=sys.stderr)
        sys.exit(1)
    if not replaced:
        if not out:
            out.append(f"# {os.path.basename(os.path.dirname(lp))}/ 예외·임시 (CLAUDE.local.md)")
        out.append(f"- [부채] {tok} — {cond} (등록 {today})")
    if len([l for l in out if l.strip()]) > NAV_LINES:
        print(f"오류: {lp} 가 {NAV_LINES}줄을 넘습니다. 지난 부채를 fix/drop 으로 정리한 뒤 다시 등록하세요.", file=sys.stderr)
        sys.exit(1)
    write_lines(lp, out)
    print(f"{'keep' if keep else 'add'}: {lp}")
    print(f"  - [부채] {tok} — {cond}")


def debt_remove(root, path, to_fix):
    found = None
    for p, i, tok, cond, date in iter_debts(root):
        if match_file(tok, path):
            found = (p, i, tok, cond)
            break
    if not found:
        print(f"오류: [부채] 항목을 찾지 못했습니다: {path}", file=sys.stderr)
        sys.exit(1)
    p, i, tok, cond = found
    lines = read_lines(p)
    del lines[i]
    if all(l.strip().startswith("#") or not l.strip() for l in lines):
        os.remove(p)
        print(f"{os.path.relpath(p, root)} 에 남은 항목이 없어 파일을 삭제했습니다")
    else:
        write_lines(p, lines)
    if to_fix:
        td = os.path.join(root, "docs", "tech-debt.md")
        tl = read_lines(td) or ["# 기술 부채 (고친다로 결정된 항목)", "",
                                "로드맵이 생기면 단계로 흡수한다. 형식: - <파일> — <이전 조건> (결정 YYYY-MM-DD)", ""]
        rel = os.path.relpath(os.path.join(os.path.dirname(p), tok), root).replace(os.sep, "/")
        tl.append(f"- {rel} — {cond} (결정 {datetime.date.today().isoformat()})")
        write_lines(td, tl)
        print("fix : [부채] 제거 → docs/tech-debt.md 에 추가. 줄 수 상한이 다시 적용됩니다 "
              f"(+{os.environ.get('FABLE_OVER_GROWTH', '30')}줄까지만).")
    else:
        print(f"drop: [부채] 제거 ({tok})")


def debt_enforce(root, on):
    p = project_path(root, True)
    if on:
        set_env(p, {IGNORE_DEBT_KEY: "1"})
        print(f"enforce ON : {p} 에 {IGNORE_DEBT_KEY}=1 — 모든 [부채] 제외를 무시합니다 (새 세션부터)")
    else:
        for lp in (project_path(root, False), project_path(root, True)):
            if os.path.exists(lp) and IGNORE_DEBT_KEY in (load(lp).get("env") or {}):
                set_env(lp, {}, remove=(IGNORE_DEBT_KEY,))
        print("enforce off: [부채] 제외가 다시 적용됩니다 (새 세션부터)")


def debt_main(argv):
    ap = argparse.ArgumentParser(prog="fable debt")
    ap.add_argument("cmd", choices=["list", "add", "fix", "keep", "drop", "enforce"])
    ap.add_argument("target", nargs="?")
    ap.add_argument("cond", nargs="?")
    ap.add_argument("--dir", default=os.getcwd())
    a = ap.parse_args(argv)
    root = find_root(a.dir)
    if a.cmd == "list":
        debt_list(root)
    elif a.cmd == "enforce":
        if a.target not in ("on", "off"):
            ap.error("enforce 에는 on|off 가 필요합니다")
        debt_enforce(root, a.target == "on")
    else:
        if not a.target:
            ap.error(f"{a.cmd} 에는 파일 경로가 필요합니다")
        path = a.target if os.path.isabs(a.target) else os.path.abspath(os.path.join(a.dir, a.target))
        if a.cmd in ("add", "keep"):
            if not a.cond:
                ap.error(f"{a.cmd} 에는 조건(또는 '영구')이 필요합니다")
            debt_add(root, path, a.cond, keep=(a.cmd == "keep"))
        else:
            debt_remove(root, path, to_fix=(a.cmd == "fix"))


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "debt":
        return debt_main(sys.argv[2:])
    ap = argparse.ArgumentParser()
    ap.add_argument("scope", choices=["global", "project", "status"])
    ap.add_argument("action", nargs="?", choices=["on", "off", "require-md"])
    ap.add_argument("value", nargs="?", choices=["on", "off"])
    ap.add_argument("--local", action="store_true")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--dir", default=os.getcwd())
    a = ap.parse_args()

    if a.scope == "status":
        status(a.dir)
        return
    if not a.action:
        ap.error(f"{a.scope} 에는 on|off 가 필요합니다")

    if a.scope == "global":
        p = global_path()
        if a.action == "on":
            set_env(p, {k: a.model for k in GLOBAL_KEYS})
            print(f"global ON : {p} 에 서브에이전트 모델={a.model} 기록 (새 세션부터, IDE·앱 포함)")
        else:
            set_env(p, {}, remove=GLOBAL_KEYS)
            print(f"global off: {p} 에서 모델 변수 제거 (셸 래퍼만 적용)")
    elif a.action == "require-md":
        if not a.value:
            ap.error("require-md 에는 on|off 가 필요합니다")
        p = project_path(a.dir, a.local)
        if a.value == "on":
            set_env(p, {REQUIRE_KEY: "1"})
            print(f"require-md ON : {p} 에 {REQUIRE_KEY}=1 — 안내 파일 없는 폴더의 코드 생성 차단 (새 세션부터)")
        else:
            for lp in (project_path(a.dir, False), project_path(a.dir, True)):
                if os.path.exists(lp) and REQUIRE_KEY in (load(lp).get("env") or {}):
                    set_env(lp, {}, remove=(REQUIRE_KEY,))
            print("require-md off")
    else:
        p = project_path(a.dir, a.local)
        if a.action == "off":
            set_env(p, {PROJECT_KEY: "1"})
            print(f"project OFF: {p} 에 {PROJECT_KEY}=1 기록 — 이 프로젝트에서 게이트 비활성 (새 세션부터)")
        else:
            for lp in (project_path(a.dir, False), project_path(a.dir, True)):
                if os.path.exists(lp) and PROJECT_KEY in (load(lp).get("env") or {}):
                    set_env(lp, {}, remove=(PROJECT_KEY,))
                    print(f"project on : {lp} 에서 {PROJECT_KEY} 제거")
            print("project on : 게이트 활성 (새 세션부터)")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"오류: {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)

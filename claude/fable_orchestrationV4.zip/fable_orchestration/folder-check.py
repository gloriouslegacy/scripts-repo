#!/usr/bin/env python3
"""
folder-check.py — 프로젝트 구조 점검 (V4). 메인은 이 결과만 읽는다.

  python3 "$HOME/.claude/fable/hooks/folder-check.py" [프로젝트 경로] [--dry-run] [--json]

검사 항목
  1. 안내 파일 없는 모듈 폴더  (코드 파일이 있는데 상위 어디에도 CLAUDE.md / CLAUDE.local.md 가 없음)
  2. 안내 파일 줄 수 초과        (모듈 CLAUDE.md / CLAUDE.local.md > FABLE_NAV_LINES, 루트 .claude/CLAUDE.md > 200)
  3. .local.md 만 있는 폴더       (정식 CLAUDE.md 로 승격 필요)
  4. 루트 위반                    (루트 직속의 코드 파일·허용 목록 밖 .md)
  5. 문서 위치 위반               (docs/·점 폴더·fixtures 류 밖의 .md)
  6. 부채                         (기한 지난 항목 / 영구 항목 / 조건 없는 항목)
  7. 큰 파일                      (FABLE_MAX_LINES 초과, [부채] 미등록) — --dry-run 에서는 변경 빈도(git) 함께
  8. 빈 catch                     (--dry-run 전용: V4 에서 "새로 생기는 것만" 막으므로 참고용)

--dry-run : V4 도입 전 영향 조사. 7·8 을 포함해 전부 보고하고, 각 항목에 처리 선택지(고친다/부채/허용)를 표시
--json    : 기계용 출력
아무것도 바꾸지 않는다. 게이트와 같은 기준(루트 판정, 허용 목록)을 쓴다.
"""
import datetime
import fnmatch
import json
import os
import re
import subprocess
import sys

CODE_EXTS = (".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".vue", ".svelte", ".java", ".kt", ".kts",
             ".scala", ".go", ".rs", ".c", ".h", ".cc", ".cpp", ".hpp", ".cs", ".swift", ".m", ".mm", ".rb",
             ".php", ".lua", ".dart", ".sh", ".bash", ".zsh", ".sql", ".r", ".jl", ".ex", ".exs", ".erl",
             ".clj", ".hs", ".ml", ".fs", ".pl", ".pm", ".ipynb", ".html", ".css", ".scss", ".sass", ".less",
             ".ps1", ".psm1", ".bat", ".cmd")
SKIP_DIRS = {"node_modules", ".git", "build", ".gradle", "venv", ".venv", "dist", "target", "__pycache__",
             "generated", "out", ".next", "coverage", ".idea", ".vscode"}
DATA_MD_SEGMENTS = {"fixtures", "assets", "resources", "testdata", "test-data", "snapshots"}
ROOT_MD_ALLOW = {"readme.md", "claude.md", "claude.local.md", "agents.md", "changelog.md", "license.md",
                 "contributing.md", "security.md", "code_of_conduct.md"}
ROOT_CODE_ALLOW = {"build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "setup.py",
                   "conftest.py", "manage.py", "gradlew.bat", "index.html", "gulpfile.js", "webpack.config.js",
                   "rollup.config.js", "karma.conf.js"}
ROOT_CODE_ALLOW_GLOBS = ("*.config.js", "*.config.ts", "*.config.mjs", "*.config.cjs", "*.conf.js", "*.conf.ts", ".*")
DEBT_RE = re.compile(r"^\s*-\s*\[부채\]\s*(\S+)\s*[—-]\s*(.*?)(?:\s*\(등록\s*([0-9-]+)\))?\s*$")
EMPTY_CATCH_RES = [
    re.compile(r"\bcatch\b\s*(?:\([^)]*\))?\s*\{\s*\}"),
    re.compile(r"^[ \t]*except\b[^\n:]*:[ \t]*(?:pass|\.\.\.)[ \t]*$", re.M),
    re.compile(r"^[ \t]*except\b[^\n:]*:[ \t]*\n[ \t]*(?:pass|\.\.\.)[ \t]*$", re.M),
]


def find_root(start):
    d = os.path.abspath(start)
    home = os.path.expanduser("~")
    git = dot = top = None
    for _ in range(64):
        if os.path.normcase(d) == os.path.normcase(home):
            break
        if git is None and os.path.exists(os.path.join(d, ".git")):
            git = d
        if dot is None and os.path.isfile(os.path.join(d, ".claude", "CLAUDE.md")):
            dot = d
        if os.path.isfile(os.path.join(d, "CLAUDE.md")):
            top = d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return git or dot or top


def project_env(root):
    env = {}
    for name in ("settings.json", "settings.local.json"):
        p = os.path.join(root, ".claude", name)
        if os.path.isfile(p):
            try:
                with open(p, encoding="utf-8-sig") as f:
                    env.update((json.load(f) or {}).get("env") or {})
            except Exception:
                pass
    for k, v in os.environ.items():
        if k.startswith("FABLE_"):
            env[k] = v
    return env


def count_lines(p):
    try:
        with open(p, "rb") as f:
            return sum(1 for _ in f)
    except OSError:
        return -1


def read_text(p):
    try:
        with open(p, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


def rel(p, root):
    return os.path.relpath(p, root).replace(os.sep, "/")


def git_change_counts(root):
    try:
        out = subprocess.run(["git", "log", "--format=", "--name-only", "-n", "500"], cwd=root,
                             capture_output=True, text=True, timeout=20).stdout
    except Exception:
        return {}
    counts = {}
    for line in out.splitlines():
        line = line.strip()
        if line:
            counts[line] = counts.get(line, 0) + 1
    return counts


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    dry = "--dry-run" in sys.argv
    as_json = "--json" in sys.argv
    start = args[0] if args else os.getcwd()
    root = find_root(start)
    if not root:
        print("프로젝트 루트(.git / CLAUDE.md / .claude/CLAUDE.md)를 찾지 못했습니다:", start)
        return 2
    env = project_env(root)
    nav_lines = int(env.get("FABLE_NAV_LINES", 30))
    max_lines = int(env.get("FABLE_MAX_LINES", 500))
    root_allow = [g.strip() for g in str(env.get("FABLE_ROOT_ALLOW", "")).split(",") if g.strip()]
    md_allow = [g.strip() for g in str(env.get("FABLE_MD_ALLOW", "")).split(",") if g.strip()]

    rep = {"root": root, "no_nav": [], "nav_lines": [], "local_only": [], "root_violation": [],
           "md_location": [], "debt": [], "big_files": [], "empty_catch": []}
    today = datetime.date.today()
    changes = git_change_counts(root) if dry else {}

    # 루트 .claude/CLAUDE.md 줄 수
    for rc in (os.path.join(root, ".claude", "CLAUDE.md"), os.path.join(root, "CLAUDE.md")):
        if os.path.isfile(rc) and count_lines(rc) > 200:
            rep["nav_lines"].append((rel(rc, root), count_lines(rc), 200))

    nav_dirs = set()
    for dp, dn, fn in os.walk(root):
        dn[:] = [x for x in dn if x not in SKIP_DIRS and not x.startswith(".")] if dp != root else \
                [x for x in dn if x not in SKIP_DIRS and x != ".claude" and not x.startswith(".")]
        is_root = os.path.normcase(dp) == os.path.normcase(root)
        has_nav = "CLAUDE.md" in fn
        has_local = "CLAUDE.local.md" in fn
        if not is_root and (has_nav or has_local):
            nav_dirs.add(dp)
            for name in ("CLAUDE.md", "CLAUDE.local.md"):
                p = os.path.join(dp, name)
                if os.path.isfile(p) and count_lines(p) > nav_lines:
                    rep["nav_lines"].append((rel(p, root), count_lines(p), nav_lines))
            if has_local and not has_nav:
                rep["local_only"].append(rel(dp, root))
            if has_local:
                for line in read_text(os.path.join(dp, "CLAUDE.local.md")).splitlines():
                    m = DEBT_RE.match(line)
                    if m:
                        tok, cond = m.group(1), m.group(2).strip()
                        st = "유효"
                        d = re.search(r"(20\d{2}-\d{2}-\d{2})", cond)
                        if "영구" in cond:
                            st = "영구"
                        elif not cond:
                            st = "조건 없음"
                        elif d and datetime.date.fromisoformat(d.group(1)) < today:
                            st = "기한 지남"
                        rep["debt"].append((rel(dp, root), tok, cond, st))
        code_files = [f for f in fn if f.lower().endswith(CODE_EXTS)]
        for f in fn:
            p = os.path.join(dp, f)
            low = f.lower()
            if is_root:
                if low.endswith(".md") and low not in ROOT_MD_ALLOW and not any(fnmatch.fnmatch(low, g.lower()) for g in root_allow):
                    rep["root_violation"].append((f, "문서 → docs/"))
                elif low.endswith(CODE_EXTS) and low not in ROOT_CODE_ALLOW \
                        and not any(fnmatch.fnmatch(low, g) for g in ROOT_CODE_ALLOW_GLOBS) \
                        and not any(fnmatch.fnmatch(low, g.lower()) for g in root_allow):
                    rep["root_violation"].append((f, "코드 → 모듈/scripts 폴더 또는 FABLE_ROOT_ALLOW"))
                continue
            parts = rel(p, root).split("/")
            if low.endswith(".md") and low not in ("claude.md", "claude.local.md"):
                if parts[0] != "docs" and not any(x.startswith(".") for x in parts[:-1]) \
                        and not any(x.lower() in DATA_MD_SEGMENTS for x in parts[:-1]) \
                        and not any(fnmatch.fnmatch("/".join(parts), g) for g in md_allow):
                    rep["md_location"].append(rel(p, root))
            if low.endswith(CODE_EXTS):
                n = count_lines(p)
                if n > max_lines:
                    rep["big_files"].append((rel(p, root), n, changes.get(rel(p, root), 0)))
                if dry:
                    c = sum(len(rx.findall(read_text(p))) for rx in EMPTY_CATCH_RES)
                    if c:
                        rep["empty_catch"].append((rel(p, root), c))
        if not is_root and code_files:
            d = dp
            covered = False
            while os.path.normcase(d) != os.path.normcase(root):
                if os.path.isfile(os.path.join(d, "CLAUDE.md")) or os.path.isfile(os.path.join(d, "CLAUDE.local.md")):
                    covered = True
                    break
                d = os.path.dirname(d)
            if not covered:
                rep["no_nav"].append((rel(dp, root), len(code_files)))

    # 모듈 단위로 묶기: 상위가 이미 보고됐으면 하위는 생략
    no_nav = []
    for d, n in sorted(rep["no_nav"]):
        if not any(d.startswith(x + "/") for x, _ in no_nav):
            no_nav.append((d, n))
    rep["no_nav"] = no_nav
    debt_files = {t.lower() for _, t, _, _ in rep["debt"]}
    rep["big_files"] = [b for b in rep["big_files"] if os.path.basename(b[0]).lower() not in debt_files]

    if as_json:
        print(json.dumps(rep, ensure_ascii=False, indent=1))
        return 0

    print(f"# folder-check {'(dry-run: V4 도입 영향 조사)' if dry else ''} — {root}")
    def section(title, rows, fmt, hint=""):
        print(f"\n## {title}: {len(rows)}건" + (f"  — {hint}" if hint and rows else ""))
        for r in rows[:40]:
            print("  " + fmt(r))
        if len(rows) > 40:
            print(f"  … 외 {len(rows) - 40}건")
    section("안내 파일 없는 모듈 폴더", rep["no_nav"], lambda r: f"{r[0]}  (코드 {r[1]}개)",
            "메인이 인터뷰 후 CLAUDE.md Write, 당장 어려우면 CLAUDE.local.md [임시 안내]")
    section("안내 파일 줄 수 초과", rep["nav_lines"], lambda r: f"{r[0]}  {r[1]}줄 > {r[2]}", "정리해서 상한 이하로")
    section(".local.md 만 있는 폴더", rep["local_only"], lambda r: r, "정식 CLAUDE.md 로 승격")
    section("루트 위반", rep["root_violation"], lambda r: f"{r[0]}  → {r[1]}",
            "옮기거나 FABLE_ROOT_ALLOW 에 추가 (기존 파일 수정은 막히지 않음)")
    section("문서 위치 위반", rep["md_location"], lambda r: r, "docs/ 로 옮기거나 FABLE_MD_ALLOW 에 추가")
    section("부채", rep["debt"], lambda r: f"{r[0]}  {r[1]}  [{r[3]}]  {r[2]}",
            "기한 지남 → fix/keep/drop, 조건 없음 → keep 으로 조건 추가")
    section(f"{max_lines}줄 초과 파일 (부채 미등록)", rep["big_files"],
            lambda r: f"{r[0]}  {r[1]}줄" + (f"  변경 {r[2]}회/최근 500커밋" if dry else ""),
            "선택: 고친다(docs/tech-debt.md) / 부채(fable debt add) / 그대로(+30줄까지만 허용)")
    if dry:
        section("빈 catch (참고)", rep["empty_catch"], lambda r: f"{r[0]}  {r[1]}개",
                "V4 는 새로 생기는 것만 막음. 기존 것은 고칠 때 함께 정리")
    total = sum(len(v) for k, v in rep.items() if isinstance(v, list))
    print(f"\n합계 {total}건. {'항목별로 고친다/부채/허용을 정한 뒤 설치하세요.' if dry else ''}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

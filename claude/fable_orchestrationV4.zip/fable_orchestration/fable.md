# Fable Orchestration Mode (ON · Max 요금제 · V4)

> **적용 범위**: 이 파일은 **메인 대화에만** 적용된다. 지금 서브에이전트(Agent 도구로 실행된 implementer·architect·deep-reasoner·runner)로 실행 중이라면 §0~§3 을 무시하고, 발주 프롬프트와 자기 에이전트 정의를 따른다. 이 파일이 보인다는 이유로 위임하거나 파일 수를 제한하지 않는다.
>
> **우선 관계**: 작업 방식(위임·한도·감시·발주)은 이 파일이, 프로젝트의 사실·규약(빌드 명령, 구조, 코딩 규약)은 프로젝트 `.claude/CLAUDE.md` 와 모듈 `CLAUDE.md` 가 우선한다.

이 세션의 메인 에이전트는 **지휘자(conductor)** 다. 역할은 계획·분배·진행 추적·결과 종합·사용자 인터뷰·안내 파일 작성이며, 구현은 서브에이전트에게 위임한다.

## 0. Max 한도 원칙

- 메인은 Fable 5.1(effort **medium**)이다. Fable 은 공유 주간 한도의 **최대 50%** 까지만 쓸 수 있고, 턴마다 쌓인 맥락 전체를 다시 읽는다. **이 세션에서 가장 비싼 자원은 메인의 턴과 메인이 읽는 양**이다.
- 메인은 ① 일찍 위임하고 ② 적게 읽고 ③ 조치가 필요한 이벤트에만 깨어난다. 무거운 판단도 Fable 이 길게 생각하기보다 `deep-reasoner`/`architect`(Opus 5.5)에 맡기는 쪽을 먼저 고려한다.
- 작업 단위가 끝날 때마다, 또는 맥락이 길어졌다고 판단되면 사용자에게 `/compact` 를 제안한다.

## 1. 역할 분담

| 작업 | 담당 |
|---|---|
| 요구사항 해석, 작업 분해, 순서·의존성 결정, 결과 종합·검수, 사용자 인터뷰, 안내 파일(`CLAUDE.md`·`CLAUDE.local.md`) 작성 | 메인(나, Fable 5.1 medium) |
| 코드 작성·수정, 리팩터링, 테스트 작성, 디버깅 | `implementer` (Opus 5.5) — **`general-purpose` 는 쓰지 않는다(게이트가 막음)** |
| 구조안·ADR 초안·모듈 안내 초안(`docs/nav-drafts/`), 로드맵 단계 끝 구조 점검 | `architect` (Opus 5.5 high) |
| 원인 불명 버그 분석, 단일 결정의 트레이드오프 (좁은 질문) | `deep-reasoner` (Opus 5.5 high) |
| 여러 단계의 탐색, 테스트·빌드 실행과 로그 확인, `folder-check` 실행 | `runner` (Haiku 4.5) |

## 2. 메인이 직접 해도 되는 일

- 코드 파일 수정은 **한 턴(사용자 프롬프트)당 최대 2개 파일**까지. 그 이상은 게이트가 물리적으로 차단한다. 3개 이상이면 처음부터 위임한다.
- 문서(`docs/`), 설정(json/yaml/toml), 안내 파일 수정은 제한 없음. 단 모듈 안내 파일은 **Write 로 전체 재작성**만 가능하고 30줄 이하다(§5).
- 계획을 세울 때는 `docs/structure.md`·`docs/roadmap.md`·ADR 을 읽는다. **코드 파일은 읽지 않는다.** 코드를 봐야 하면 `runner`/`implementer` 에게 요약을 시킨다.
- Bash 로 코드 파일을 고치는 우회(`sed -i`, 리다이렉트, `tee`, `python -c` 쓰기 등)는 시도하지 않는다.
- 스킬의 지시(예: 문서를 Claude Docs 로 만들라)와 이 패키지의 규칙이 충돌하면 임의로 고르지 말고 사용자에게 묻는다. 프로젝트 산출물은 항상 레포 안 파일이다.

## 3. 위임 규칙

- 발주 프롬프트에는 **목표, 대상 파일, 완료 기준, 반환 형식, 진행 로그 경로**를 반드시 적는다. 코딩 규칙·진행 로그 형식·반환 형식의 고정 부분은 `implementer` 정의에 이미 있으므로 반복하지 않는다.
- **발주 1건 = 완료 기준 1개, 수정 파일 5개 이하**를 목표로 한다. 넘으면 나눠서 발주한다. 발주가 작을수록 타임아웃과 재발주가 줄어든다.
- 반환은 항상 **요약**(변경 파일, 3~5줄, 테스트 결과, open issues)만 받는다. 코드 전문이나 긴 로그를 돌려받지 않는다.
- 병렬 서브에이전트는 **동시에 3개 이하**. 같은 파일을 두 서브에이전트에 동시에 맡기지 않는다. 의존 관계가 있으면 순차로.
- 탐색을 맡길 때는 "먼저 그 폴더의 `CLAUDE.md` 를 읽어라"를 넣는다(Grep·Glob 만으로는 안내 파일이 로드되지 않는다).
- 명령 실행·확인 경로: 출력이 짧은 단일 확인은 메인이 직접 / 긴 출력은 Bash 안에서 `grep`·`awk`·`wc` 로 걸러 결과만 / 여러 단계는 `runner`.
- `docs/` 안의 ADR·구조 문서가 있으면 발주에 "따를 ADR 번호"만 적는다. 설계를 발주마다 다시 설명하지 않는다.

### 3-1. 멈춤 감시

- **진행 파일**: 백그라운드 서브에이전트는 `<scratchpad>/progress_<kind>_<name>.log` 에 단계마다 `<HH:MM> <단계> <결과>` 1줄을 쓴다.
  - `<kind>`(문턱): `explore`(3분) · `logs`(5분) · `impl`(8분) · `analyze`(10분)
  - 결과: `ok` · `retry n/3` · `fail` · `conflict` · `완료`
  - 발주할 때 `<scratchpad>`·`<kind>`·`<name>` 을 **실제 절대 경로와 값으로 치환**한다.
- **감시 걸기**: 백그라운드 발주 직후 `Monitor` 하나를 건다(`timeout_ms` 1800000). 감시 루프를 직접 쓰지 않는다.
  - macOS·Linux: `python3 "$HOME/.claude/fable/hooks/progress-watch.py" <scratchpad 절대경로> <kind>_<name> [...]`
  - Windows: `py -3 "$HOME/.claude/fable/hooks/progress-watch.py" <scratchpad 절대경로> <kind>_<name> [...]`
  - 경로 뒤에 이번에 발주한 `<kind>_<name>` 을 모두 적는다. 스크립트는 조치가 필요한 줄만 낸다: `STALL` · `FAIL` · `ERROR` · `CONFLICT` · `NOFILE`. 모두 끝나면 스스로 종료한다.
  - 같은 폴더에 추가 발주하면 자동으로 잡힌다. Monitor 만료 통지가 오면 **진행 중인 서브에이전트가 있을 때만** 다시 건다.
- **이벤트 처리**: 해당 진행 로그의 **마지막 3~5줄만** 읽고 판단한다. 로그 전체·서브에이전트 출력 전문을 읽지 않는다.
  - `STALL`: `SendMessage` 로 "현재 상태 보고 후 종료". 같은 문턱 안에 진행이 없으면 `TaskStop`(긴 명령 안에서 멈춘 경우 메시지가 닿지 않는다).
  - `FAIL`·`ERROR`: 돌아오기를 기다렸다가 §3-2 로. 돌아오지 않으면 `STALL` 과 같게.
  - `CONFLICT`: §3-3 으로.
  - `NOFILE`: 발주 문구의 경로 치환을 확인하고 감시 경로를 고쳐 다시 건다.

### 3-2. 복귀 뒤 처리

타임아웃·무한루프·시도 상한 초과·오류로 작업이 돌아오면 **바로 재할당하지 않는다.**

1. `TaskStop` (아직 돌고 있으면)
2. 진행 파일·반환 요약에서 멈춘 단계와 원인을 확인한다.
3. 메인의 계획을 먼저 고친다: 작업 분해(더 작게), 순서·의존성, 담당 에이전트, 완료 기준·시도 상한 중 무엇이 틀렸는지 적는다.
4. 고친 계획으로 지시서를 다시 써서 재발주한다. `<name>` 은 새로 짓는다(`auth` → `auth_r2`).

같은 지시서 그대로 재발주하거나 자동 재시도 루프를 두지 않는다. 원인을 모르면 `deep-reasoner` 에 분석을 맡기거나 사용자에게 보고한다.

### 3-3. 충돌 처리

서브에이전트가 `conflict` 로 중단하면(게이트가 발주를 막음 / 같은 순위 지시가 양립 불가 / 어느 쪽도 ADR 경계 위반) 메인은:

1. 반환 요약의 **충돌한 지시 2개·출처·선택지**를 읽는다. 코드는 읽지 않는다.
2. 사용자에게 선택지와 권장안을 **한 번에** 제시한다.
3. 결정을 **기록**한다 — 모듈만의 예외: `CLAUDE.local.md` `[예외]` / 구조 변경: 새 ADR(이전 것 "대체됨") / 발주 오류: 지시서 수정 / 패키지 규칙 문제: `fable.md`·`coding-rules.md` 수정 제안.
4. 재발주한다. 같은 충돌이 다시 보고되면 기록이 빠진 것이다.

### 3-4. 새 모듈·새 프로젝트

- `implementer` 가 "새 모듈 필요: 이유"를 반환하면 만들지 않은 것이 맞다. 메인이 사용자와 1라운드 인터뷰(역할, 공개 진입점, 의존, 테스트 명령) 후 `<모듈>/CLAUDE.md` 를 Write 하고 재발주한다.
- 새 프로젝트, 새 모듈 여러 개, 기존 경계를 바꾸는 큰 기능은 구현을 발주하기 **전에** `$HOME/.claude/fable/kickoff.md` 절차를 따른다. 버그 수정·기존 경계 안의 기능 추가는 제외. 애매하면 사용자에게 한 번 묻는다. (`$HOME` 을 모르면 Bash 로 `echo $HOME` 먼저.)
- 기존 레포에 V4 를 처음 적용할 때도 `kickoff.md` 의 "기존 레포 적용" 절차를 따른다.

## 4. 발주 프롬프트에 넣을 작업별 항목

```
Goal: <완료 기준 1개>
Files: <대상 파일, 5개 이하>
Follow: docs/adr/NNNN (있으면), <모듈>/CLAUDE.md
Progress log: <scratchpad 절대경로>/progress_<kind>_<name>.log
Return: changed files, 3-5 line summary, test result, open issues
```

고정 규칙(수정 최소화, 범위 확장 금지, 로그·예외, 크기, 게이트 거부 처리, 충돌 보고)은 `implementer` 정의에 있다.

## 5. 안내 파일 (메인만 작성)

| | 루트 `.claude/CLAUDE.md` | 모듈 `CLAUDE.md` | 모듈 `CLAUDE.local.md` |
|---|---|---|---|
| 내용 | 프로젝트 전체 규칙 | 역할·공개 진입점·의존(허용·금지)·파일 표·테스트 명령·ADR 링크 | `[예외]`·`[부채]`·`[임시 안내]` — 이유·조건·등록일 필수 |
| 줄 수 | 200 (경고) | **30 (게이트)** | **30 (게이트)** |
| 쓰기 | 메인 Edit·Write | **메인 Write 만** (지난 내용 정리 후 전체 재작성) | 메인 Write 만, 부채는 사용자가 `fable debt` 로도 |
| 바꿀 때 | — | 역할·경계·의존·금지가 바뀌면 **인터뷰** / 파일 표·명령 동기화는 재작성 후 **보고만** | 짧은 확인 1회 |

- 모듈 단위로만 둔다. 하위 폴더에는 두지 않는다. 서브에이전트가 "CLAUDE.md 갱신 필요"를 open issues 로 보고하면 메인이 처리한다.
- 구조 점검은 `runner` 에게 `python3 "$HOME/.claude/fable/hooks/folder-check.py"` 를 실행시키고 **결과만** 읽는다. kickoff 때와 로드맵 단계가 끝날 때 한다.
- 지시 우선순위(충돌 판단 기준): 게이트 > 발주 프롬프트 > `CLAUDE.local.md` > 모듈 `CLAUDE.md` > ADR·`docs/structure.md` > 루트 `.claude/CLAUDE.md` > 에이전트 정의·`coding-rules.md`.

## 6. 맥락 관리

- 큰 파일은 메인이 통째로 읽지 않는다. 필요한 범위만 읽거나 Bash 안에서 `grep`·`awk` 로 줄인다.
- 하나의 작업 단위가 끝나면 결과를 3~5줄로 정리하고 다음 단계로 넘어간다.

## 7. Token efficiency (Fable 5.1 official guidance)

Everything produced in one reply, including any reasoning or drafting done before the reply, counts toward a single output limit. Composing an entire output or deliverable in full as reasoning and then again as a reply would double the length of the turn without improving the result, so don't do that. Use the reasoning space to reason and the output space to write an output. Usually it is not needed to draft an output multiple times.

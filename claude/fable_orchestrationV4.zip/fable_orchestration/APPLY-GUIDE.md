# Fable 오케스트레이션 V4 — 처음 사용자 가이드 (공통)

> 기준일 2026-10-09 · **Max 요금제 전용** (Pro 요금제에서는 Fable 5.1 이 첫 요청부터 사용 크레딧으로 과금되므로 이 구성을 쓰지 마세요)
>
> 설치 명령은 운영체제별 문서를 따르세요: **macOS → `APPLY-GUIDE-macOS.md`**, **Windows → `APPLY-GUIDE-Windows.md`**, Linux·WSL → 이 문서 6절.
> 이 문서는 "무엇을, 왜" 와 설치 후 사용법을 다룹니다.

---

## 1. 이것이 무엇인가 (3분 설명)

Claude Code 에서 가장 비싼 모델인 **Fable 5.1** 을 "지휘자"로만 쓰고, 실제 코드 작성은 더 싼 **Opus 5.5** 에게, 단순 명령 실행은 **Haiku 4.5** 에게 맡기는 구성입니다. Max 요금제에서 Fable 은 주간 한도의 절반까지만 쓸 수 있기 때문에, Fable 이 직접 코드를 고치면 한도가 금방 바닥납니다.

"맡겨라"라고 지시문에 쓰는 것만으로는 모델이 지키지 않기 때문에, 이 구성은 **게이트**(Claude Code 의 훅)로 물리적으로 막습니다. 예를 들어 Fable 이 한 번에 코드 파일 3개를 고치려 하면 3번째는 거부되고 "implementer 에게 맡기라"는 메시지를 받습니다.

### 구성 요소

| 이름 | 역할 | 비유 |
|---|---|---|
| `fable.md` | Fable(메인)이 읽는 작업 방식 지시문 | 지휘자의 업무 수칙 |
| 에이전트 4개 | `implementer`(코드 작성), `architect`(설계), `deep-reasoner`(분석), `runner`(명령 실행) | 팀원 |
| `orchestration-gate.py` | 규칙을 물리적으로 강제하는 훅 | 출입 통제 |
| `progress-watch.py` | 백그라운드 작업이 멈췄는지 감시 | 타이머 |
| `folder-check.py` | 프로젝트 구조 점검 보고서 | 정기 점검 |
| `fable-settings.py` | 설정 스위치·부채 관리 | 제어판 |
| `kickoff.md` | 새 프로젝트·새 모듈을 시작하는 절차 | 착수 회의 |
| `coding-rules.md` | 구현 에이전트의 로그·예외·크기 규칙 | 코딩 표준 |
| `env.sh` / `env.ps1` | 터미널 명령 `fable …` | 리모컨 |

### 용어

- **메인**: 사용자가 대화하는 Claude. 이 구성에서는 Fable 5.1.
- **서브에이전트**: 메인이 일을 맡기는 별도 Claude. 각자 자기 맥락을 갖고, 끝나면 요약만 돌려줍니다.
- **게이트 / 훅**: Claude 가 도구(파일 쓰기, 셸 실행)를 쓰기 직전에 실행되는 검사 스크립트. 거부하면 그 도구 호출은 일어나지 않습니다.
- **안내 파일**: 폴더마다 두는 `CLAUDE.md`. Claude 가 그 폴더의 파일을 건드릴 때 자동으로 읽습니다.
- **부채**: 규칙(예: 파일 500줄)을 당장 못 지키는 파일을 사용자가 승인해 등록한 것. 등록된 동안 그 규칙이 적용되지 않습니다.

---

## 2. 설치 전에 확인할 것

| 항목 | 확인 | 없을 때 |
|---|---|---|
| Claude Code **2.1.271 이상** | `claude --version` | `claude update` |
| Python 3.8 이상 | `python3 --version` (Windows 는 `py -3 --version`) | OS 가이드 참고 |
| Max 요금제 | `/model` 에서 Fable 5.1 이 보이는지 | — |
| 스킬 3개 비활성화 권장 | `architecture-review`, `lean-scaffolding`, `code-conventions` | 켜 두면 구현 에이전트와 규칙이 충돌할 수 있음 (3절) |

Windows 는 PowerShell, macOS 는 터미널(zsh)에서 작업합니다. "터미널에 입력"이라고 쓰인 명령은 그곳에 붙여 넣으면 됩니다.

---

## 3. 이 구성이 바꾸는 것 (설치 전에 알아 둘 규칙)

| 규칙 | 내용 | 걸리면 |
|---|---|---|
| 메인 턴당 코드 2파일 | Fable 이 한 번의 요청에서 직접 고칠 수 있는 코드 파일은 2개 | 3번째부터 거부 → 메인이 `implementer` 에게 맡김 |
| 기존 코드 Write 금지 | 50줄 넘는 기존 코드 파일을 통째로 다시 쓰지 못함 | Edit 로 부분 수정 |
| 파일 500줄 상한 | 수정 결과가 500줄을 넘으면 거부. 이미 넘은 파일은 작업당 +30줄까지 | 새 책임은 새 파일로 / 사용자가 부채 등록 |
| 빈 catch 금지 | `catch (e) {}` 같은 빈 예외 처리가 **새로** 생기면 거부 | 복구·번역·종단 중 하나로 |
| 루트에 새 파일 금지 | 프로젝트 루트에 코드·문서를 새로 만들지 못함 (설정 파일·README 등은 허용) | 모듈 폴더 / `docs/` 로 |
| 문서는 `docs/` 아래 | 새 `.md` 는 `docs/`, 점 폴더, 모듈 `CLAUDE.md` 만 | `docs/` 로 |
| 안내 파일은 메인만 | 모듈 `CLAUDE.md`·`CLAUDE.local.md` 는 메인이 Write 로만, 30줄 이하. 서브에이전트는 읽기만 | — |
| 읽기 전용 에이전트 | `architect`·`deep-reasoner`·`runner` 는 코드를 못 고침 | — |
| `general-purpose` 금지 | 메인은 `implementer` 를 써야 함 | — |
| (옵트인) 안내 파일 필수 | `fable project require-md on` 이면 안내 파일 없는 폴더에 코드 생성 금지 | 메인이 인터뷰 후 `CLAUDE.md` 작성 |

거부 메시지에는 "왜 막혔는지"와 "풀려면 어느 설정(`FABLE_…`)을 바꾸는지"가 들어 있습니다. 모든 규칙은 **스크래치·임시 폴더에는 적용되지 않습니다.**

---

## 4. 설치 후 첫 사용 (OS 가이드의 설치를 마친 뒤)

```
fable on          # 켜기 (새 세션부터)
fable status      # 전부 [ok] 인지 확인
```

1. 새 Claude Code 세션을 엽니다. `/model` 에서 **Fable 5.1** 을 고르고 effort 를 **medium** 으로 둡니다.
2. 간단한 요청으로 확인합니다: "a.py 와 b.py 에 주석 한 줄씩 추가하고, c.py 도 추가해줘" → 두 파일은 Fable 이 직접, 세 번째에서 거부 메시지와 함께 `implementer` 에게 맡기는 것을 보면 정상입니다.
3. IDE(VS Code 등)나 데스크톱 앱에서도 쓰려면 `fable global on` 을 한 번 실행합니다(모델 전환이 IDE·앱까지 적용).
4. 평소에는 `fable off` 로 두고 큰 작업 때만 `fable on` 을 권합니다. 꺼 두면 메인은 Opus 5.5 로 평소처럼 일합니다.

---

## 5. 자주 쓰는 명령

```
fable on | off              켜기/끄기 (다음 세션부터)
fable status                설치·상태·부채 요약
fable log [n]               게이트가 막은 기록 최근 n줄
fable global on | off       IDE·앱에도 모델 전환 적용
fable project on | off      이 프로젝트에서만 게이트 끄기/켜기
fable project require-md on | off   안내 파일 없는 폴더의 코드 생성 차단 (옵트인)
fable check [경로] [--dry-run]       구조 점검 보고서 (--dry-run: 도입 영향 조사)
fable debt list                      부채 목록
fable debt add <파일> "<조건>"        부채 등록 (조건에 '영구' 가능)
fable debt fix <파일>                부채 해제 → docs/tech-debt.md 에 "고친다"
fable debt keep <파일> "<조건>"       조건 갱신
fable debt drop <파일>               해결됨
fable debt enforce on | off          모든 부채를 무시하고 상한 적용 (정리 모드)
```

Windows 에서는 `--dry-run` 대신 `-DryRun`, `--local` 대신 `-Local` 입니다.

---

## 6. Linux · WSL 설치

macOS 가이드의 2절과 같습니다(zsh 대신 bash 면 `~/.bashrc`). 배포 폴더에서:

```bash
F=~/.claude/fable
mkdir -p $F/hooks $F/state ~/.claude/agents
cp fable.md kickoff.md coding-rules.md env.sh $F/
cp orchestration-gate.py fable-settings.py progress-watch.py folder-check.py $F/hooks/
chmod +x $F/hooks/*.py
for a in implementer architect deep-reasoner runner; do cp agent-$a.md ~/.claude/agents/$a.md; done
: > $F/empty.md; echo off > ~/.claude/.fable-state; ln -sfn $F/empty.md $F/active.md
echo '[ -f "$HOME/.claude/fable/env.sh" ] && source "$HOME/.claude/fable/env.sh"' >> ~/.bashrc
grep -q 'fable/active.md' ~/.claude/CLAUDE.md 2>/dev/null || echo '@~/.claude/fable/active.md' >> ~/.claude/CLAUDE.md
```

`~/.claude/settings.json` 에 훅을 넣습니다(기존 설정이 있으면 `hooks.PreToolUse` 배열에 항목만 추가):

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit|NotebookEdit|Bash|Agent",
        "hooks": [
          { "type": "command", "command": "python3 \"$HOME/.claude/fable/hooks/orchestration-gate.py\"", "timeout": 10 }
        ]
      }
    ]
  }
}
```

`source ~/.bashrc` 후 `fable status`.

---

## 7. 기존 프로젝트에 처음 적용하기

이미 코드가 있는 레포는 규칙과 부딪히는 곳이 있습니다(루트의 스크립트, 500줄 넘는 파일 등). 순서:

1. 터미널에서 `fable check <레포 경로> --dry-run` 을 실행합니다. **아무것도 바꾸지 않고** 걸릴 항목을 표로 보여 줍니다.
2. 항목마다 셋 중 하나를 정합니다.
   - **고친다**: 나중에 리팩터링. (Claude 에게 "kickoff 기존 레포 적용" 을 요청하면 `docs/tech-debt.md` 에 정리해 줍니다)
   - **부채**: `fable debt add <파일> "<조건>"` — 그 파일은 500줄 규칙에서 제외됩니다.
   - **허용**: 레포의 `.claude/settings.json` 에 예외를 적습니다. 예: `{ "env": { "FABLE_ROOT_ALLOW": "run_*.py,tools.ps1" } }`
3. `fable on` 으로 켜고 Claude 에게 "kickoff.md 의 기존 레포 적용 절차를 진행해줘" 라고 하면 기준선 ADR 과 모듈 안내 파일을 만들어 줍니다.

조사를 건너뛰어도 됩니다. 그 경우 작업 중 막히는 시점마다 Claude 가 그 항목만 물어봅니다.

---

## 8. 부채 운영

- 부채는 **사용자가 등록**합니다(`fable debt add`). Claude 는 사용자 확인을 받은 뒤 `CLAUDE.local.md` 에 쓰는 것만 가능합니다.
- 조건이나 기한을 꼭 적습니다. `영구` 도 조건입니다. `fable check` 가 기한 지난 항목을 알려 줍니다.
- 마음이 바뀌면 `fable debt fix <파일>` → 등록이 풀리고 `docs/tech-debt.md` 에 "고친다" 로 남습니다.
- 한꺼번에 정리할 때는 `fable debt enforce on` → 모든 부채가 무시되어 상한이 전부 적용됩니다. 끝나면 `off`.
- `CLAUDE.local.md` 는 이 구성에서 **커밋**합니다(두 기기에서 같은 예외를 보기 위해). `.gitignore` 에 넣지 마세요.

---

## 9. 폴더 안내 파일 (`CLAUDE.md`)

Claude Code 는 하위 폴더의 `CLAUDE.md` 를 그 폴더의 파일을 건드릴 때 자동으로 읽습니다. 이 구성은 모듈마다 30줄짜리 안내 파일을 두어 서브에이전트가 폴더 규칙(역할, 진입점, 의존 방향, 테스트 명령)을 바로 알게 합니다.

- 작성은 **메인(Fable)만**, 사용자와 짧은 인터뷰 후 합니다. 새 프로젝트는 kickoff 때 한꺼번에, 진행 중 새 모듈은 그때 한 번.
- `CLAUDE.local.md` 는 같은 폴더의 예외·부채·임시 안내입니다. `CLAUDE.md` 뒤에 읽혀 규약을 덮어씁니다.
- 루트 규칙은 `.claude/CLAUDE.md` 에 둡니다(루트 폴더를 깨끗이 유지).

---

## 10. 문제가 생기면

| 증상 | 확인 |
|---|---|
| 아무것도 막히지 않음 | `fable status` 가 `state: on` 인지, 훅이 `[ok]` 인지. 새 세션을 열었는지 |
| 정상 작업이 막힘 | `fable log 5` 로 어떤 규칙인지 확인 → 메시지의 `FABLE_…` 설정으로 예외 추가, 또는 `fable project off` |
| Claude 가 `general-purpose` 를 쓰려다 막힘 | 정상. `implementer` 를 쓰게 됨 |
| 서브에이전트가 Fable 로 실행됨 | `fable global on` (IDE·앱) 또는 터미널에서 `claude` 로 실행했는지 |
| 멈춘 서브에이전트에 메시지가 안 닿음 | `TaskStop` 후 새 이름으로 재발주 (Claude 가 자동으로 함) |
| Cowork 데스크톱 세션 | 사용자 CLAUDE.md 의 외부 import 를 건너뛰므로 지시문은 적용되지 않고 게이트만 동작 |

---

## 11. 설치 후 한 번 직접 확인할 것

- `/model` 에서 Fable 5.1 · Opus 5.5 · Haiku 4.5 의 정확한 모델 ID (다르면 `env.sh`/`env.ps1` 의 `FABLE_EXEC_MODEL` 과 `agent-*.md` 의 `model:` 을 맞추세요)
- 서브에이전트가 Opus 5.5 로 실행되는지 (서브에이전트 출력의 모델 표시)
- 하위 폴더 `CLAUDE.md` 가 서브에이전트에서도 읽히는지

---

## 12. 변경점 (V3 → V4)

| 항목 | V3 | V4 |
|---|---|---|
| 구현 에이전트 | 내장 `general-purpose` | 커스텀 `implementer` (코딩 규칙 내장, 연쇄 위임·스킬 금지) |
| 에이전트 | 2개 | 4개 (`architect` 추가, 파일로 배포) |
| 지시문 범위 | 서브에이전트에도 그대로 주입됨 | 범위 선언으로 메인 전용 명시 |
| 게이트 | 자기 보호·재작성·셸·턴 한도 | + 읽기 전용 에이전트, 지시 파일 보호, 안내 파일 30줄, 500줄 상한(+30·부채), 빈 catch, 루트·문서 위치, 안내 파일 필수(옵트인), `Agent(general-purpose)` 차단 |
| 절차 | 없음 | `kickoff.md` (인터뷰 → 요구사항 → ADR → 로드맵 → 구현), 기존 레포 적용 |
| 안내 파일 | 없음 | 모듈 `CLAUDE.md`·`CLAUDE.local.md` (메인만 작성) |
| 부채 | 없음 | `fable debt …`, `docs/tech-debt.md` |
| 점검 | 없음 | `folder-check.py`, `fable check` |
| 충돌 | 없음 | 서브에이전트 `conflict` 보고 → 메인이 사용자와 결정·기록 |
| 스킬 | 참조 | `architecture-review`·`lean-scaffolding`·`code-conventions` 삭제 전제. 기준은 패키지 안에 |

#Requires AutoHotkey v2.0
#SingleInstance Force

; 왼쪽 Alt + Space → 한/영 전환
<!Space::Send "{vk15}"

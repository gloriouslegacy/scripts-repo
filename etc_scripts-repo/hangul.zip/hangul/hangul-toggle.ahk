#Requires AutoHotkey v2.0
#SingleInstance Force

; Ctrl + Space → 한/영 전환
^Space::Send "{vk15}"
